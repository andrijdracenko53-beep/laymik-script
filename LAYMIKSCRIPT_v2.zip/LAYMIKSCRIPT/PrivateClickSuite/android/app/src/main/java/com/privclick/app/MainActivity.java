package com.privclick.app;

import android.app.*;
import android.os.Bundle;
import android.content.*;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.provider.Settings;
import android.view.View;
import android.view.inputmethod.InputMethodInfo;
import android.view.inputmethod.InputMethodManager;
import android.widget.*;
import java.util.*;

public class MainActivity extends Activity {
    private TextView keyboardStatus;
    private android.content.SharedPreferences prefs;

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        setContentView(com.privclick.app.R.layout.activity_main);
        prefs = getSharedPreferences("laymikscript", MODE_PRIVATE);
        keyboardStatus = findViewById(R.id.keyboardStatus);
        updateKeyboardStatus();

        findViewById(R.id.eyedropper).setOnClickListener(v -> showMessage("Пипетка", "Следующим этапом сюда подключается плавающая пипетка для выбора координат."));
        findViewById(R.id.start).setOnClickListener(v -> showMessage("Запуск", "Перед запуском включи службу специальных возможностей LAYMIKSCRIPT."));
        findViewById(R.id.keyboard).setOnClickListener(v -> showKeyboardMenu());
        findViewById(R.id.settings).setOnClickListener(v -> startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)));
    }

    private void showKeyboardMenu() {
        final String[] items = {"Выбрать клавиатуру приложения", "Открыть настройки клавиатур Android"};
        new AlertDialog.Builder(this).setTitle("КЛАВИАТУРА").setItems(items, (d, which) -> {
            if (which == 0) chooseKeyboardApp();
            else startActivity(new Intent(Settings.ACTION_INPUT_METHOD_SETTINGS));
        }).show();
    }

    private void chooseKeyboardApp() {
        InputMethodManager imm = (InputMethodManager)getSystemService(INPUT_METHOD_SERVICE);
        List<InputMethodInfo> enabled = imm.getEnabledInputMethodList();
        if (enabled == null || enabled.isEmpty()) {
            showMessage("Нет клавиатур", "Сначала включи нужную клавиатуру в системных настройках Android.");
            startActivity(new Intent(Settings.ACTION_INPUT_METHOD_SETTINGS));
            return;
        }
        String[] names = new String[enabled.size()];
        for (int i = 0; i < enabled.size(); i++) names[i] = enabled.get(i).getServiceInfo().applicationInfo.loadLabel(getPackageManager()).toString();
        new AlertDialog.Builder(this).setTitle("Выбери клавиатуру").setItems(names, (dialog, which) -> {
            InputMethodInfo info = enabled.get(which);
            prefs.edit().putString("keyboard_ime_id", info.getId()).putString("keyboard_name", names[which]).apply();
            updateKeyboardStatus();
        }).setNegativeButton("Отмена", null).show();
    }

    private void updateKeyboardStatus() {
        String name = prefs.getString("keyboard_name", null);
        keyboardStatus.setText(name == null ? "Клавиатура: не выбрана" : "Клавиатура: " + name);
    }

    private void showMessage(String title, String msg) {
        new AlertDialog.Builder(this).setTitle(title).setMessage(msg).setPositiveButton("OK", null).show();
    }
}
