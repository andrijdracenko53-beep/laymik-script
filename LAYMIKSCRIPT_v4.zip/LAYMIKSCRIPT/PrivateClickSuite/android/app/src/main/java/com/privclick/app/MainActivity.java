package com.privclick.app;

import android.app.*;import android.os.*;import android.content.*;import android.graphics.Color;import android.graphics.PixelFormat;import android.provider.Settings;import android.view.*;import android.view.inputmethod.*;import android.widget.*;import java.util.*;

public class MainActivity extends Activity {
    static final int OVERLAY_REQ=901;
    android.content.SharedPreferences prefs; TextView status, statusBadge;
    @Override public void onCreate(Bundle b){super.onCreate(b);setContentView(R.layout.activity_main);prefs=getSharedPreferences("laymikscript",MODE_PRIVATE);status=findViewById(R.id.status); statusBadge=findViewById(R.id.status_badge); refresh();
        findViewById(R.id.eyedropper).setOnClickListener(v->openPipette());
        findViewById(R.id.start).setOnClickListener(v->toggleClicker());
        findViewById(R.id.keyboard).setOnClickListener(v->keyboardMenu());
        findViewById(R.id.settings).setOnClickListener(v->settings()); }
    void refresh(){
    String kb=prefs.getString("keyboard_name",null);
    status.setText("Точек: "+prefs.getInt("point_count",0)+"   •   "+(kb==null?"Клавиатура не выбрана":kb));
    boolean ready=ClickAccessibilityService.instance!=null;
    statusBadge.setText(ready?"● READY":"● SERVICE OFF");
    statusBadge.setTextColor(android.graphics.Color.parseColor(ready?"#6FE3A1":"#FFB86B"));
}
    void openPipette(){ if(!Settings.canDrawOverlays(this)){new AlertDialog.Builder(this).setTitle("Разрешение пипетки").setMessage("Разреши LAYMIKSCRIPT показывать элементы поверх других приложений.").setPositiveButton("Открыть",(d,w)->startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,android.net.Uri.parse("package:"+getPackageName())))).setNegativeButton("Отмена",null).show();return;} new PipetteOverlay(this).show(); }
    void toggleClicker(){ if(ClickAccessibilityService.instance==null){new AlertDialog.Builder(this).setTitle("Служба выключена").setMessage("Включи LAYMIKSCRIPT в Настройки → Специальные возможности.").setPositiveButton("Открыть",(d,w)->startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))).setNegativeButton("Отмена",null).show();return;} ArrayList<android.graphics.Point> pts=new ArrayList<>();int n=prefs.getInt("point_count",0);for(int i=0;i<n;i++)pts.add(new android.graphics.Point(prefs.getInt("x"+i,0),prefs.getInt("y"+i,0)));if(pts.isEmpty()){Toast.makeText(this,"Сначала добавь точку через Пипетку",Toast.LENGTH_SHORT).show();return;} ClickAccessibilityService.instance.toggle(pts,prefs.getLong("interval",150)); }
    void keyboardMenu(){InputMethodManager imm=(InputMethodManager)getSystemService(INPUT_METHOD_SERVICE);List<InputMethodInfo> list=imm.getEnabledInputMethodList();String[] names=new String[list.size()+1];names[0]="Открыть настройки клавиатур Android";for(int i=0;i<list.size();i++)names[i+1]=list.get(i).loadLabel(getPackageManager()).toString();new AlertDialog.Builder(this).setTitle("⌨ КЛАВИАТУРА").setItems(names,(d,w)->{if(w==0)startActivity(new Intent(Settings.ACTION_INPUT_METHOD_SETTINGS));else{InputMethodInfo x=list.get(w-1);prefs.edit().putString("keyboard_ime_id",x.getId()).putString("keyboard_name",names[w]).apply();refresh();Toast.makeText(this,"Выбрана: "+names[w],Toast.LENGTH_SHORT).show();}}).show();}
    void settings(){String[] a={"Интервал кликов","Очистить точки","Служба специальных возможностей","Разрешение пипетки"};new AlertDialog.Builder(this).setTitle("⚙ НАСТРОЙКИ").setItems(a,(d,w)->{if(w==0){final EditText e=new EditText(this);e.setInputType(2);e.setText(String.valueOf(prefs.getLong("interval",150)));new AlertDialog.Builder(this).setTitle("Интервал, мс").setView(e).setPositiveButton("Сохранить",(x,z)->{try{prefs.edit().putLong("interval",Math.max(20,Long.parseLong(e.getText().toString()))).apply();}catch(Exception ignored){}}).setNegativeButton("Отмена",null).show();}else if(w==1){prefs.edit().putInt("point_count",0).apply();refresh();}else if(w==2)startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS));else if(w==3)startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,android.net.Uri.parse("package:"+getPackageName())));}).show();}
}
