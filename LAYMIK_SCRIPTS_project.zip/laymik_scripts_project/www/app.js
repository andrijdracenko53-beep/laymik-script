const $ = (id) => document.getElementById(id);
const loginScreen = $("loginScreen"), adminScreen = $("adminScreen");
let users = JSON.parse(localStorage.getItem("laymik_demo_users") || "null") || [
  {id:1, login:"demo_user", status:"active", expires:Date.now()+30*86400000},
  {id:2, login:"test_account", status:"frozen", expires:Date.now()+7*86400000}
];
function save(){localStorage.setItem("laymik_demo_users",JSON.stringify(users));render()}
function dateText(ts){return new Date(ts).toLocaleDateString("ru-RU")}
function render(){
  $("totalCount").textContent=users.length;
  $("activeCount").textContent=users.filter(u=>u.status==="active").length;
  $("restrictedCount").textContent=users.filter(u=>u.status!=="active").length;
  const list=$("userList"); list.innerHTML="";
  if(!users.length){list.innerHTML='<div class="empty">Аккаунтов пока нет</div>';return}
  users.forEach(u=>{
    const card=document.createElement("article");card.className="user-card";
    const head=document.createElement("div");head.className="user-head";
    const name=document.createElement("span");name.className="user-name";name.textContent=u.login;
    const badge=document.createElement("span");badge.className="status "+(u.status==="active"?"":u.status);badge.textContent=u.status==="active"?"АКТИВЕН":u.status==="frozen"?"ЗАМОРОЖЕН":"ЗАБЛОКИРОВАН";
    head.append(name,badge);
    const meta=document.createElement("div");meta.className="user-meta";meta.textContent="Демо-доступ до: "+dateText(u.expires);
    const actions=document.createElement("div");actions.className="actions";
    const toggle=document.createElement("button");toggle.textContent=u.status==="frozen"?"Разморозить":"Заморозить";toggle.onclick=()=>{u.status=u.status==="frozen"?"active":"frozen";save()};
    const block=document.createElement("button");block.textContent=u.status==="blocked"?"Разблокировать":"Блокировать";block.onclick=()=>{u.status=u.status==="blocked"?"active":"blocked";save()};
    const remove=document.createElement("button");remove.className="danger";remove.textContent="Удалить";remove.onclick=()=>{if(confirm("Удалить демо-аккаунт "+u.login+"?")){users=users.filter(x=>x.id!==u.id);save()}};
    actions.append(toggle,block,remove);card.append(head,meta,actions);list.append(card);
  });
}
$("previewAdmin").addEventListener("click",()=>{loginScreen.classList.add("hidden");adminScreen.classList.remove("hidden");render()});
$("logout").addEventListener("click",()=>{adminScreen.classList.add("hidden");loginScreen.classList.remove("hidden")});
$("loginForm").addEventListener("submit",e=>{e.preventDefault();$("loginMessage").textContent="Авторизация пока не подключена. Это демонстрационный макет.";});
$("addToggle").addEventListener("click",()=>$("addForm").classList.toggle("hidden"));
$("addForm").addEventListener("submit",e=>{
  e.preventDefault();const login=$("newLogin").value.trim();
  if(!login)return;if(users.some(u=>u.login.toLowerCase()===login.toLowerCase())){alert("Такой логин уже есть");return}
  const days=Number($("newExpiry").value);users.push({id:Date.now(),login,status:"active",expires:Date.now()+days*86400000});$("newLogin").value="";$("addForm").classList.add("hidden");save();
});
