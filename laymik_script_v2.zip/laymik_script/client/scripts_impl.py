"""Реестр скриптов клиента.

Ключ — это key скрипта на сервере. Значение — функция run(stop_event, cfg, log)
или None, если скрипт ещё не добавлен.

Скрипт 0.03 добавим позже: напиши функцию и поставь её сюда.

Настройки раздела «Площадка» лежат в cfg["market"]. Читай их так:

    from market import resolved, target_cents, cents, fmt
    m = resolved(cfg["market"])          # числа вместо строк из полей ввода
    price = target_cents(m, m["mode"], top_cents, sell_cents)
    # m["antifull"], m["autosell"], m["undercut"], m["telegram"], m["refresh_ms"] ...
"""


def run_script_0_03(stop_event, cfg, log):
    # TODO: код скрипта 0.03
    raise NotImplementedError


SCRIPTS = {
    "0.03": None,  # заменить на run_script_0_03, когда будет готов
}
