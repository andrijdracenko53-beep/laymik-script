"""Своя экранная клавиатура приложения.

Появляется внизу окна, когда нажимаешь на любое поле ввода, и печатает кликами мыши.
Физическая клавиатура продолжает работать как обычно.
Поля бывают трёх видов: "num" (число с точкой), "int" (целое), "text" (буквы, цифры, знаки).
Для чисел показывается цифровая панель, для текста полная раскладка EN / РУС / знаки.
"""
import re
import tkinter as tk
from collections import namedtuple

from theme import (ACCENT, ACCENT_FG, FG, BG, KEY, KEY2, KEY_DOWN, LINE, MONO, FONT, MUTED, PANEL)

ROW_H = 46
NUM_RE = re.compile(r"^\d{0,7}([.,]\d{0,4})?$")
INT_RE = re.compile(r"^\d{0,6}$")

Key = namedtuple("Key", "label action weight style letter")


def K(c, letter=False):
    return Key(c, "ch", 1, "k", letter)


def F(label, action, weight=1):
    return Key(label, action, weight, "f", False)


def G(label, action, weight=1):
    return Key(label, action, weight, "g", False)


NUM_LAYOUT = [
    [K("7"), K("8"), K("9"), F("Удал.", "bs")],
    [K("4"), K("5"), K("6"), F("Очист.", "clr")],
    [K("1"), K("2"), K("3"), F("Далее", "next")],
    [K("."), K("0"), G("Готово", "done", 2)],
]


def _text_layers():
    digits = [K(c) for c in "1234567890"] + [F("Удал.", "bs", 1.5)]
    langs = {
        "en": ("qwertyuiop", "asdfghjkl", "zxcvbnm", "РУС", "ru"),
        "ru": ("йцукенгшщзхъ", "фывапролджэ", "ячсмитьбю", "EN", "en"),
    }
    layers = {}
    for name, (r1, r2, r3, other_label, other) in langs.items():
        layers[name] = [
            digits,
            [K(c, True) for c in r1],
            [K(c, True) for c in r2],
            [F("Aa", "shift", 1.5)] + [K(c, True) for c in r3] + [K(".")],
            [F("123", "layer:sym", 2), F(other_label, "layer:" + other, 2), F("Пробел", "space", 4),
             F("Далее", "next", 2), G("Готово", "done", 2)],
        ]
    layers["sym"] = [
        digits,
        [K(c) for c in "!@#$%^&*()"],
        [K(c) for c in "-_=+[]{};:"],
        [K(c) for c in "'\",./?\\|<>"],
        [F("abc", "layer:en", 2), F("РУС", "layer:ru", 2), F("Пробел", "space", 4),
         F("Далее", "next", 2), G("Готово", "done", 2)],
    ]
    return layers


TEXT_LAYERS = _text_layers()


class VirtualKeyboard:
    def __init__(self, host, root):
        self.root = root
        self.host = host
        self.registry = {}          # поле -> (вид, заголовок)
        self.target = None
        self.shift = False
        self.text_layer = "en"
        self.current = None         # какая раскладка нарисована сейчас
        self.letter_keys = []
        self.shift_label = None
        self._repeat = None

        host.config(height=1)
        self.frame = tk.Frame(host, bg=PANEL, highlightthickness=1, highlightbackground=LINE)
        head = tk.Frame(self.frame, bg=PANEL)
        head.pack(fill="x", padx=10, pady=(6, 2))
        self.lbl_title = tk.Label(head, text="", bg=PANEL, fg=ACCENT, font=(MONO, 10, "bold"))
        self.lbl_title.pack(side="left")
        self.lbl_hint = tk.Label(head, text="", bg=PANEL, fg=MUTED, font=(MONO, 9))
        self.lbl_hint.pack(side="left", padx=12)
        close = tk.Label(head, text="✕", bg=PANEL, fg=MUTED, font=(FONT, 11), cursor="hand2")
        close.pack(side="right")
        close.bind("<Button-1>", lambda e: self.hide())
        self.rows_frame = tk.Frame(self.frame, bg=PANEL)
        self.rows_frame.pack(fill="x", padx=6, pady=(0, 6))

        self.root.bind("<Button-1>", self._maybe_hide, add="+")
        self.root.bind("<Escape>", lambda e: self.hide(), add="+")

    # ---------- поля ----------
    def register(self, entry, kind="text", title=""):
        self.registry[entry] = (kind, title)
        regex = {"num": NUM_RE, "int": INT_RE}.get(kind)
        if regex:
            check = self.root.register(lambda value: bool(regex.match(value)))
            entry.configure(validate="key", validatecommand=(check, "%P"))
        entry.bind("<FocusIn>", lambda e, w=entry: self.show(w), add="+")
        entry.bind("<Button-1>", lambda e, w=entry: self.show(w), add="+")

    def prune(self):
        for w in list(self.registry):
            try:
                alive = w.winfo_exists()
            except tk.TclError:
                alive = False
            if not alive:
                del self.registry[w]

    # ---------- показать и скрыть ----------
    def show(self, entry):
        if entry not in self.registry:
            return
        kind, title = self.registry[entry]
        self.target = entry
        self.lbl_title.config(text=title)
        self.lbl_hint.config(text={"num": "число", "int": "целое число"}.get(kind, "текст"))
        if kind in ("num", "int"):
            self._build("num")
            pad = max(6, int(self.root.winfo_width() * 0.27))
        else:
            self._build(self.text_layer)
            pad = 6
        self.rows_frame.pack_configure(padx=pad)
        if not self.frame.winfo_ismapped():
            self.frame.pack(fill="x")
        if kind in ("num", "int"):
            self.root.after(15, lambda: self._select_all(entry))

    def _select_all(self, entry):
        try:
            if entry is self.target and str(entry.cget("state")) != "disabled":
                entry.selection_range(0, "end")
                entry.icursor("end")
        except tk.TclError:
            pass

    def hide(self):
        self.target = None
        self.frame.pack_forget()
        self.host.config(height=1)   # без этого пустая панель остаётся прежней высоты

    def _inside(self, widget):
        return str(widget).startswith(str(self.frame))

    def _maybe_hide(self, event):
        w = event.widget
        if w in self.registry or self._inside(w):
            return
        if self.frame.winfo_ismapped():
            self.hide()

    # ---------- рисование раскладки ----------
    def _build(self, name):
        if name == self.current:
            return
        self.current = name
        rows = NUM_LAYOUT if name == "num" else TEXT_LAYERS[name]
        total_units = 4 if name == "num" else 12
        for w in self.rows_frame.winfo_children():
            w.destroy()
        self.letter_keys = []
        self.shift_label = None
        for row in rows:
            rf = tk.Frame(self.rows_frame, bg=PANEL, height=ROW_H)
            rf.pack(fill="x")
            units = sum(k.weight for k in row)
            x = (total_units - units) / 2
            for k in row:
                cell = tk.Frame(rf, bg=PANEL)
                cell.place(relx=x / total_units, rely=0, relwidth=k.weight / total_units, relheight=1)
                bg, fg, font = self._style(k)
                lab = tk.Label(cell, text=k.label, bg=bg, fg=fg, font=font, cursor="hand2")
                lab.place(x=2, y=2, relwidth=1, relheight=1, width=-4, height=-4)
                lab.bind("<ButtonPress-1>", lambda e, k=k, l=lab: self._down(k, l))
                lab.bind("<ButtonRelease-1>", lambda e, k=k, l=lab: self._up(k, l))
                if k.letter:
                    self.letter_keys.append((k, lab))
                if k.action == "shift":
                    self.shift_label = lab
                x += k.weight
        self._paint_shift()

    def _style(self, k):
        if k.style == "g":
            return ACCENT, ACCENT_FG, (FONT, 11, "bold")
        if k.style == "f":
            return KEY2, FG, (FONT, 10, "bold")
        return KEY, FG, (MONO, 14)

    def _paint_shift(self):
        for k, lab in self.letter_keys:
            lab.config(text=k.label.upper() if self.shift else k.label)
        if self.shift_label is not None:
            self.shift_label.config(bg=FG if self.shift else KEY2, fg=BG if self.shift else FG)

    # ---------- нажатия ----------
    def _down(self, k, lab):
        lab.config(bg=KEY_DOWN)
        self._press(k)
        if k.action == "bs":
            self._repeat = self.root.after(380, self._repeat_bs)

    def _up(self, k, lab):
        if self._repeat:
            self.root.after_cancel(self._repeat)
            self._repeat = None
        if k.action == "shift":
            self._paint_shift()
        else:
            bg, _, _ = self._style(k)
            try:
                lab.config(bg=bg)
            except tk.TclError:
                pass

    def _repeat_bs(self):
        self._backspace()
        self._repeat = self.root.after(60, self._repeat_bs)

    def _entry(self):
        e = self.target
        try:
            if e is None or not e.winfo_exists() or str(e.cget("state")) == "disabled":
                return None
        except tk.TclError:
            return None
        return e

    def _insert(self, text):
        e = self._entry()
        if not e:
            return
        try:
            if e.selection_present():
                e.delete("sel.first", "sel.last")
        except tk.TclError:
            pass
        e.insert(e.index("insert"), text)

    def _backspace(self):
        e = self._entry()
        if not e:
            return
        try:
            if e.selection_present():
                e.delete("sel.first", "sel.last")
                return
        except tk.TclError:
            pass
        i = e.index("insert")
        if i > 0:
            e.delete(i - 1)

    def _press(self, k):
        a = k.action
        if a == "ch":
            ch = k.label.upper() if (k.letter and self.shift) else k.label
            if k.letter and self.shift:
                self.shift = False
                self._paint_shift()
            self._insert(ch)
        elif a == "space":
            self._insert(" ")
        elif a == "bs":
            self._backspace()
        elif a == "clr":
            e = self._entry()
            if e:
                e.delete(0, "end")
        elif a == "shift":
            self.shift = not self.shift
        elif a.startswith("layer:"):
            self.text_layer = a.split(":", 1)[1]
            self.shift = False
            self._build(self.text_layer)
        elif a == "next":
            self._next()
        elif a == "done":
            self.hide()
            self.root.focus_set()

    def _next(self):
        self.prune()
        fields = [w for w in self.registry
                  if w.winfo_ismapped() and str(w.cget("state")) != "disabled"]
        fields.sort(key=lambda w: (w.winfo_rooty(), w.winfo_rootx()))
        if self.target in fields:
            i = fields.index(self.target)
            if i + 1 < len(fields):
                fields[i + 1].focus_set()
                self.show(fields[i + 1])
                return
        self.hide()
        self.root.focus_set()
