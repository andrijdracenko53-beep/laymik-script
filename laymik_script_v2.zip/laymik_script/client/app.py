"""Клиент: вход по логину/паролю, главное меню с плитками, раздел «Площадка», свои экранные клавиши."""
import ctypes
import hashlib
import json
import os
import platform
import sys
import threading
import time
import tkinter as tk
import uuid
from tkinter import messagebox, simpledialog, ttk

import requests
from PIL import ImageGrab
from pynput import keyboard, mouse

import market
from scripts_impl import SCRIPTS
from theme import (ACCENT, ACCENT_FG, ACCENT_HOVER, BG, FG, FONT, GOOD, LINE, MONO, MUTED, PANEL, PANEL2, WARN)
from vkeyboard import VirtualKeyboard
from widgets import ChoiceCards, Switch, draw_icon

try:
    ctypes.windll.shcore.SetProcessDpiAwareness(2)  # точные координаты на Windows
except Exception:
    pass

APP_DIR = os.path.dirname(os.path.abspath(sys.argv[0]))
CONFIG_PATH = os.path.join(APP_DIR, "config.json")
DEFAULT_CFG = {
    "server": "http://127.0.0.1:5000",
    "username": "",
    "start_stop_key": "f6",
    "pipette_key": "f8",
    "click_delay_ms": 100,
    "click_button": "left",
    "market": dict(market.DEFAULT_MARKET),
}

PAGE_TITLES = {
    "home": "laymik_script",
    "scripts": "Скрипты",
    "market": "Площадка",
    "mods": "Моды",
    "settings": "Настройка",
    "pipette": "Пипетка",
    "keys": "Горячие клавиши",
    "admin": "Аккаунты",
}


def load_cfg():
    cfg = json.loads(json.dumps(DEFAULT_CFG))
    try:
        with open(CONFIG_PATH, encoding="utf-8") as f:
            saved = json.load(f)
        saved_market = saved.pop("market", {})
        cfg.update(saved)
        cfg["market"].update({k: v for k, v in saved_market.items() if k in market.DEFAULT_MARKET})
    except Exception:
        pass
    return cfg


def save_cfg(cfg):
    try:
        with open(CONFIG_PATH, "w", encoding="utf-8") as f:
            json.dump(cfg, f, ensure_ascii=False, indent=2)
    except Exception:
        pass


def get_hwid():
    raw = f"{uuid.getnode()}|{platform.node()}|{platform.machine()}"
    return hashlib.sha256(raw.encode()).hexdigest()[:32]


def key_name(key):
    if hasattr(key, "char") and key.char:
        return key.char.lower()
    return getattr(key, "name", str(key)).lower()


class ApiError(Exception):
    def __init__(self, msg, status=0):
        super().__init__(msg)
        self.status = status


class Api:
    def __init__(self, base):
        self.base = base.rstrip("/")
        self.token = None

    def call(self, method, path, **kw):
        headers = {"Authorization": f"Bearer {self.token}"} if self.token else {}
        try:
            r = requests.request(method, self.base + path, headers=headers, timeout=10, **kw)
        except requests.RequestException:
            raise ApiError("Нет связи с сервером")
        try:
            data = r.json()
        except ValueError:
            data = {}
        if r.status_code >= 400:
            raise ApiError(data.get("error", f"Ошибка {r.status_code}"), r.status_code)
        return data


def style_app(root):
    root.configure(bg=BG)
    s = ttk.Style(root)
    s.theme_use("clam")
    s.configure(".", background=BG, foreground=FG, fieldbackground=PANEL, bordercolor=LINE, font=(FONT, 10))
    s.configure("TFrame", background=BG)
    s.configure("Card.TFrame", background=PANEL)
    s.configure("TLabel", background=BG, foreground=FG)
    s.configure("Card.TLabel", background=PANEL, foreground=FG)
    s.configure("Muted.TLabel", foreground=MUTED)
    s.configure("CardMuted.TLabel", background=PANEL, foreground=MUTED)
    s.configure("Section.TLabel", background=PANEL, foreground=MUTED, font=(FONT, 8, "bold"))
    s.configure("Title.TLabel", font=(FONT, 18, "bold"))
    s.configure("Head.TLabel", font=(FONT, 14, "bold"))
    s.configure("TButton", background=PANEL2, foreground=FG, padding=8, borderwidth=0)
    s.map("TButton", background=[("active", "#2a3440")])
    s.configure("Accent.TButton", background=ACCENT, foreground=ACCENT_FG, font=(FONT, 10, "bold"))
    s.map("Accent.TButton", background=[("active", ACCENT_HOVER)])
    s.configure("TEntry", fieldbackground=BG, foreground=FG, insertcolor=ACCENT, padding=7,
                bordercolor=LINE, lightcolor=LINE, darkcolor=LINE)
    s.map("TEntry", fieldbackground=[("disabled", PANEL)], foreground=[("disabled", MUTED)],
          bordercolor=[("focus", ACCENT)], lightcolor=[("focus", ACCENT)], darkcolor=[("focus", ACCENT)])
    s.configure("TCombobox", fieldbackground=BG, foreground=FG, arrowcolor=FG, padding=6)
    s.configure("Treeview", background=PANEL, fieldbackground=PANEL, foreground=FG, rowheight=30, borderwidth=0)
    s.configure("Treeview.Heading", background=PANEL2, foreground=MUTED, borderwidth=0, font=(FONT, 9))
    s.map("Treeview", background=[("selected", ACCENT)], foreground=[("selected", ACCENT_FG)])


class App:
    def __init__(self):
        self.cfg = load_cfg()
        self.root = tk.Tk()
        self.root.title("laymik_script")
        self.root.minsize(900, 640)
        style_app(self.root)
        # клавиатура создаётся первой и занимает низ окна, поэтому ей всегда хватает места
        self.kb_host = tk.Frame(self.root, bg=PANEL)
        self.kb_host.pack(side="bottom", fill="x")
        self.body = ttk.Frame(self.root)
        self.body.pack(fill="both", expand=True)
        self.kb = VirtualKeyboard(self.kb_host, self.root)

        self.api = None
        self.user = None
        self.runner = None
        self.current_key = None
        self.current_page = "home"
        self.stop_event = threading.Event()
        self.capture = None  # "start_stop_key" / "pipette_key" при назначении клавиши
        self._building = False
        self.mouse = mouse.Controller()
        self.listener = keyboard.Listener(on_press=self._on_key)
        self.listener.daemon = True
        self.listener.start()
        self.show_login()

    def run(self):
        self.root.mainloop()

    # ---------- вспомогательное ----------
    def clear(self):
        self.kb.hide()
        for w in self.body.winfo_children():
            w.destroy()
        self.kb.prune()

    def entry(self, parent, kind="text", title="", width=None, show=None, textvariable=None):
        """Поле ввода, которое открывает экранную клавиатуру."""
        kw = {}
        if width:
            kw["width"] = width
        if show:
            kw["show"] = show
        if textvariable is not None:
            kw["textvariable"] = textvariable
        e = ttk.Entry(parent, **kw)
        self.kb.register(e, kind, title)
        return e

    def card(self, parent, title=None):
        outer = tk.Frame(parent, bg=PANEL, highlightthickness=1, highlightbackground=LINE)
        inner = ttk.Frame(outer, style="Card.TFrame", padding=14)
        inner.pack(fill="both", expand=True)
        if title:
            ttk.Label(inner, text=title.upper(), style="Section.TLabel").pack(anchor="w", pady=(0, 10))
        return outer, inner

    # ---------- вход ----------
    def show_login(self):
        self.clear()
        self.root.geometry("640x720")
        wrap = ttk.Frame(self.body)
        wrap.pack(expand=True)
        logo = tk.Canvas(wrap, width=52, height=52, bg=BG, highlightthickness=0)
        logo.create_rectangle(0, 0, 52, 52, fill=ACCENT, outline=ACCENT)
        logo.create_text(26, 26, text="Л", font=(FONT, 22, "bold"), fill=ACCENT_FG)
        logo.pack(pady=(0, 10))
        ttk.Label(wrap, text="laymik_script", style="Title.TLabel").pack(pady=(0, 18))
        f = ttk.Frame(wrap)
        f.pack()
        ttk.Label(f, text="Сервер", style="Muted.TLabel").pack(anchor="w")
        self.e_server = self.entry(f, "text", "Сервер", width=34)
        self.e_server.insert(0, self.cfg["server"])
        self.e_server.pack(pady=(0, 10), fill="x")
        ttk.Label(f, text="Логин", style="Muted.TLabel").pack(anchor="w")
        self.e_user = self.entry(f, "text", "Логин", width=34)
        self.e_user.insert(0, self.cfg["username"])
        self.e_user.pack(pady=(0, 10), fill="x")
        ttk.Label(f, text="Пароль", style="Muted.TLabel").pack(anchor="w")
        self.e_pass = self.entry(f, "text", "Пароль", width=34, show="•")
        self.e_pass.pack(pady=(0, 16), fill="x")
        self.btn_login = ttk.Button(f, text="Войти", style="Accent.TButton", command=self.do_login)
        self.btn_login.pack(fill="x")
        self.lbl_err = ttk.Label(f, text="", foreground=WARN, wraplength=320)
        self.lbl_err.pack(pady=10)
        self.root.bind("<Return>", lambda e: self.do_login())
        (self.e_pass if self.cfg["username"] else self.e_user).focus()

    def do_login(self):
        server, username, password = self.e_server.get().strip(), self.e_user.get().strip(), self.e_pass.get()
        if not username or not password:
            self.lbl_err.config(text="Введи логин и пароль")
            return
        self.btn_login.config(state="disabled")
        self.lbl_err.config(text="")
        self.root.update_idletasks()
        api = Api(server)
        try:
            data = api.call("POST", "/api/login", json={"username": username, "password": password, "hwid": get_hwid()})
        except ApiError as e:
            self.lbl_err.config(text=str(e))
            self.btn_login.config(state="normal")
            return
        api.token = data["token"]
        self.api, self.user = api, data["user"]
        self.cfg.update(server=server, username=username)
        save_cfg(self.cfg)
        self.root.unbind("<Return>")
        self.show_main()

    def logout(self):
        self.stop_script()
        try:
            self.api.call("POST", "/api/logout")
        except ApiError:
            pass
        self.api = self.user = None
        self.show_login()

    def handle_error(self, e):
        if e.status in (401, 403):
            messagebox.showwarning("Доступ", str(e))
            self.stop_script()
            self.api = self.user = None
            self.show_login()
        else:
            messagebox.showerror("Ошибка", str(e))

    # ---------- главное окно ----------
    def show_main(self):
        self.clear()
        self.root.geometry("1000x760")
        self.current_page = "home"

        top = tk.Frame(self.body, bg=BG)
        top.pack(fill="x", padx=18, pady=(14, 8))
        self.btn_back = ttk.Button(top, text="←  Меню", command=lambda: self.open_page("home"))
        logo = tk.Canvas(top, width=36, height=36, bg=BG, highlightthickness=0)
        logo.create_rectangle(0, 0, 36, 36, fill=ACCENT, outline=ACCENT)
        logo.create_text(18, 18, text="Л", font=(FONT, 15, "bold"), fill=ACCENT_FG)
        logo.pack(side="left", padx=(0, 12))
        self.lbl_title = ttk.Label(top, text="laymik_script", style="Head.TLabel")
        self.lbl_title.pack(side="left")
        ttk.Button(top, text="Выйти", command=self.logout).pack(side="right")
        role = "админ" if self.user["is_admin"] else "пользователь"
        ttk.Label(top, text=f"{self.user['username']} · {role}", style="Muted.TLabel").pack(side="right", padx=12)
        if self.user["expires"] and not self.user["is_admin"]:
            left = max(0, int((self.user["expires"] - time.time()) // 86400))
            ttk.Label(top, text=f"Доступ: ещё {left} дн.", style="Muted.TLabel").pack(side="right")
        self.top_logo = logo

        self.area = ttk.Frame(self.body)
        self.area.pack(fill="both", expand=True, padx=18, pady=(0, 14))
        self.page_frames = {}
        names = ["home", "scripts", "market", "mods", "settings", "pipette", "keys"]
        if self.user["is_admin"]:
            names.append("admin")
        for n in names:
            self.page_frames[n] = ttk.Frame(self.area)

        self.tab_scripts = self.page_frames["scripts"]
        self.tab_settings = self.page_frames["settings"]
        self.tab_pipette = self.page_frames["pipette"]
        self.tab_keys = self.page_frames["keys"]

        self._building = True
        self.build_home(self.page_frames["home"])
        self.build_scripts()
        self.build_market(self.page_frames["market"])
        self.build_mods(self.page_frames["mods"])
        self.build_settings()
        self.build_pipette()
        self.build_keys()
        if self.user["is_admin"]:
            self.tab_admin = self.page_frames["admin"]
            self.build_admin()
        self._building = False
        self.refresh_market_ui()
        self.open_page("home")

    def open_page(self, name):
        self.kb.hide()
        for f in self.page_frames.values():
            f.pack_forget()
        self.page_frames[name].pack(fill="both", expand=True)
        self.current_page = name
        self.lbl_title.config(text=PAGE_TITLES[name])
        if name == "home":
            self.btn_back.pack_forget()
            self.refresh_home()
        else:
            self.btn_back.pack(side="left", padx=(0, 12), before=self.top_logo)

    # ---------- главное меню ----------
    HOME_TILES = [
        ("market", "Площадка", "Режим перебива, шаг, отступ от лота, потолок цены и проверка", "sliders"),
        ("mods", "Моды", "Анти-фулл, автопродажа, Telegram", "toggle"),
        ("settings", "Настройка", "Задержка кликов, кнопка мыши, сервер, обновление", "gear"),
        ("pipette", "Пипетка", "Цвет и координаты пикселя под курсором", "pipette"),
        ("keys", "Горячие клавиши", "Старт/стоп скрипта и сохранение цвета", "keys"),
        ("admin", "Аккаунты", "Выдача и управление доступом покупателей", "users"),
    ]

    def build_home(self, f):
        self.chip_row = ttk.Frame(f)
        self.chip_row.pack(fill="x", pady=(2, 14))
        grid = ttk.Frame(f)
        grid.pack(fill="both", expand=True)
        for c in range(3):
            grid.columnconfigure(c, weight=1, uniform="tiles")
        self._tile(grid, 0, 0, 3, "scripts", "Скрипты", "Запуск и остановка скриптов. Старт и стоп также по горячей клавише.",
                   "play", primary=True)
        i = 0
        for key, title, desc, icon in self.HOME_TILES:
            if key == "admin" and not self.user["is_admin"]:
                continue
            self._tile(grid, 1 + i // 3, i % 3, 1, key, title, desc, icon)
            i += 1
        for r in range(1, 3):
            grid.rowconfigure(r, weight=1, uniform="rows")

    def _tile(self, parent, row, col, span, key, title, desc, icon, primary=False):
        bg = ACCENT if primary else PANEL
        fg = ACCENT_FG if primary else FG
        sub = ACCENT_FG if primary else MUTED
        edge = ACCENT if primary else LINE
        t = tk.Frame(parent, bg=bg, highlightthickness=1, highlightbackground=edge, cursor="hand2")
        t.grid(row=row, column=col, columnspan=span, sticky="nsew", padx=5, pady=5, ipady=6)
        cv = tk.Canvas(t, width=36, height=36, bg=bg, highlightthickness=0, cursor="hand2")
        draw_icon(cv, icon, ACCENT_FG if primary else ACCENT)
        cv.pack(anchor="w", padx=16, pady=(14, 8))
        lt = tk.Label(t, text=title, bg=bg, fg=fg, font=(FONT, 14, "bold"), anchor="w", cursor="hand2")
        lt.pack(fill="x", padx=16)
        ld = tk.Label(t, text=desc, bg=bg, fg=sub, font=(FONT, 9), anchor="w", justify="left",
                      wraplength=520 if primary else 240, cursor="hand2")
        ld.pack(fill="x", padx=16, pady=(2, 12))

        def enter(_):
            t.config(highlightbackground=ACCENT_HOVER if primary else ACCENT)

        def leave(_):
            t.config(highlightbackground=edge)

        for w in (t, cv, lt, ld):
            w.bind("<Button-1>", lambda e, k=key: self.open_page(k))
            w.bind("<Enter>", enter)
            w.bind("<Leave>", leave)

    def _chip(self, text, state):
        chip = tk.Frame(self.chip_row, bg=PANEL, highlightthickness=1,
                        highlightbackground=ACCENT if state == "hot" else LINE)
        dot_color = {"on": GOOD, "off": MUTED, "hot": ACCENT}[state]
        dot = tk.Canvas(chip, width=10, height=10, bg=PANEL, highlightthickness=0)
        dot.create_oval(1, 1, 9, 9, fill=dot_color, outline=dot_color)
        dot.pack(side="left", padx=(10, 4), pady=6)
        tk.Label(chip, text=text, bg=PANEL, fg=ACCENT if state == "hot" else FG,
                 font=(MONO, 9)).pack(side="left", padx=(0, 10))
        chip.pack(side="left", padx=(0, 8))

    def refresh_home(self):
        for w in self.chip_row.winfo_children():
            w.destroy()
        m = market.resolved(self.cfg["market"])
        mode = {1: f"Режим 1 · шаг {m['step']:g}", 2: "Режим 2 · под фулл", 3: f"Режим 3 · отступ {m['offset']:g}"}[m["mode"]]
        running = bool(self.runner and self.runner.is_alive())
        self._chip(f"Скрипт: {self.current_key}" if running else "Скрипт остановлен", "on" if running else "off")
        self._chip(mode, "hot")
        self._chip("Анти-фулл", "on" if m["antifull"] else "off")
        self._chip("Автопродажа", "on" if m["autosell"] else "off")
        self._chip("Telegram", "on" if m["telegram"] else "off")

    # ---------- Скрипты ----------
    def build_scripts(self):
        f = self.tab_scripts
        self.tree_scripts = ttk.Treeview(f, columns=("name", "desc", "status"), show="headings", height=8)
        for c, t, w in (("name", "Скрипт", 180), ("desc", "Описание", 340), ("status", "Статус", 120)):
            self.tree_scripts.heading(c, text=t)
            self.tree_scripts.column(c, width=w)
        self.tree_scripts.pack(fill="both", expand=True)
        bar = ttk.Frame(f)
        bar.pack(fill="x", pady=(10, 0))
        ttk.Button(bar, text="Запустить", style="Accent.TButton", command=self.start_script).pack(side="left")
        ttk.Button(bar, text="Остановить", command=self.stop_script).pack(side="left", padx=8)
        ttk.Button(bar, text="Обновить список", command=self.load_scripts).pack(side="left")
        self.lbl_run = ttk.Label(bar, text="", style="Muted.TLabel")
        self.lbl_run.pack(side="right")
        self.log_box = tk.Text(f, height=6, bg=PANEL, fg=FG, bd=0, state="disabled", font=(MONO, 9))
        self.log_box.pack(fill="x", pady=(10, 0))
        self.script_rows = {}
        self.load_scripts()

    def load_scripts(self):
        try:
            items = self.api.call("GET", "/api/scripts")
        except ApiError as e:
            return self.handle_error(e)
        self.tree_scripts.delete(*self.tree_scripts.get_children())
        self.script_rows = {}
        for s in items:
            ready = s["enabled"] and SCRIPTS.get(s["key"]) is not None
            status = "готов" if ready else "скоро"
            iid = self.tree_scripts.insert("", "end", values=(s["name"], s["description"], status))
            self.script_rows[iid] = (s["key"], ready)

    def log(self, text):
        def w():
            self.log_box.config(state="normal")
            self.log_box.insert("end", time.strftime("%H:%M:%S ") + text + "\n")
            self.log_box.see("end")
            self.log_box.config(state="disabled")
        self.root.after(0, w)

    def start_script(self):
        if self.runner and self.runner.is_alive():
            return self.log("Скрипт уже запущен")
        sel = self.tree_scripts.selection()
        if not sel:
            return messagebox.showinfo("Скрипты", "Выбери скрипт в списке")
        key, ready = self.script_rows[sel[0]]
        if not ready:
            return messagebox.showinfo("Скрипты", "Этот скрипт скоро будет добавлен")
        self.stop_event.clear()
        self.current_key = key
        self.runner = threading.Thread(target=self._run, args=(key,), daemon=True)
        self.runner.start()
        self.lbl_run.config(text=f"Работает: {key}")

    def _run(self, key):
        try:
            SCRIPTS[key](self.stop_event, self.cfg, self.log)
        except Exception as e:
            self.log(f"Ошибка скрипта: {e}")
        self.log("Скрипт остановлен")
        self.root.after(0, lambda: self.lbl_run.config(text=""))

    def stop_script(self):
        self.stop_event.set()

    def toggle_script(self):
        if self.runner and self.runner.is_alive():
            self.stop_script()
        elif self.api:
            self.start_script()

    # ---------- Площадка ----------
    def _mvar(self, key, kind="str"):
        m = self.cfg["market"]
        if kind == "bool":
            v = tk.BooleanVar(value=bool(m[key]))
        elif kind == "int":
            v = tk.IntVar(value=int(m[key]))
        else:
            v = tk.StringVar(value=str(m[key]))
        v.trace_add("write", lambda *_: self.market_changed())
        self.mv[key] = v
        return v

    def _field(self, parent, col, label, key, kind, hint="", width=14):
        box = ttk.Frame(parent, style="Card.TFrame")
        box.grid(row=0, column=col, sticky="we", padx=(0 if col == 0 else 14, 0))
        parent.columnconfigure(col, weight=1, uniform="fields")
        ttk.Label(box, text=label, style="CardMuted.TLabel").pack(anchor="w")
        e = self.entry(box, kind, label.rstrip(", G"), textvariable=self._mvar(key))
        e.pack(fill="x", pady=(4, 2))
        if hint:
            ttk.Label(box, text=hint, style="CardMuted.TLabel", font=(FONT, 8)).pack(anchor="w")
        self.m_entries[key] = e
        return e

    def build_market(self, f):
        self.mv, self.m_entries = {}, {}
        outer, c = self.card(f, "Режим перебива")
        outer.pack(fill="x")
        ChoiceCards(c, [(1, "1. Кастом", "топ-запрос плюс шаг"),
                        (2, "2. Под фулл", "первый лот минус 0.01"),
                        (3, "3. Кастом под фулл", "первый лот минус отступ")],
                    self._mvar("mode", "int"), bg=PANEL).pack(fill="x", pady=(0, 12))
        row = ttk.Frame(c, style="Card.TFrame")
        row.pack(fill="x")
        self._field(row, 0, "Шаг перебива, G", "step", "num", "режим 1")
        self._field(row, 1, "Отступ от лота, G", "offset", "num", "режим 3")
        self._field(row, 2, "Потолок цены, G", "max_price", "num", "0 отключает потолок")

        outer2, c2 = self.card(f, "Проверка цены на примере")
        outer2.pack(fill="both", expand=True, pady=(12, 0))
        row2 = ttk.Frame(c2, style="Card.TFrame")
        row2.pack(fill="x", pady=(0, 10))
        self._field(row2, 0, "Первый лот, G", "lot", "num")
        self._field(row2, 1, "Топ-запрос, G", "top", "num")
        self.tree_calc = ttk.Treeview(c2, columns=("mode", "price", "res"), show="headings", height=3)
        for cid, t, w, a in (("mode", "Режим", 200, "w"), ("price", "Поставит, G", 120, "e"), ("res", "Итог", 200, "w")):
            self.tree_calc.heading(cid, text=t)
            self.tree_calc.column(cid, width=w, anchor=a)
        self.tree_calc.tag_configure("cur", background=PANEL2, foreground=ACCENT)
        self.tree_calc.tag_configure("warn", foreground=WARN)
        self.tree_calc.pack(fill="x")
        self.lbl_calc = ttk.Label(c2, text="", style="CardMuted.TLabel")
        self.lbl_calc.pack(anchor="w", pady=(8, 0))

    def switch_row(self, parent, title, desc, key):
        row = ttk.Frame(parent, style="Card.TFrame")
        row.pack(fill="x", pady=4)
        txt = ttk.Frame(row, style="Card.TFrame")
        txt.pack(side="left", fill="x", expand=True)
        ttk.Label(txt, text=title, style="Card.TLabel", font=(FONT, 11)).pack(anchor="w")
        ttk.Label(txt, text=desc, style="CardMuted.TLabel", font=(FONT, 9)).pack(anchor="w")
        Switch(row, self._mvar(key, "bool"), bg=PANEL).pack(side="right")

    def build_mods(self, f):
        outer, c = self.card(f, "Моды")
        outer.pack(fill="x")
        self.switch_row(c, "Анти-фулл", "снимает ордер, дошедший до потолка, и не ставит новый под фулл", "antifull")
        tk.Frame(c, bg=LINE, height=1).pack(fill="x", pady=8)
        self.switch_row(c, "Автопродажа", "после покупки выставляет предмет ниже первого лота", "autosell")
        row = ttk.Frame(c, style="Card.TFrame")
        row.pack(fill="x", pady=(6, 0))
        self._field(row, 0, "Ниже первого лота на, G", "undercut", "num")
        tk.Frame(c, bg=LINE, height=1).pack(fill="x", pady=8)
        self.switch_row(c, "Telegram", "сообщения о перебиве, покупке и продаже", "telegram")
        row = ttk.Frame(c, style="Card.TFrame")
        row.pack(fill="x", pady=(6, 0))
        box = ttk.Frame(row, style="Card.TFrame")
        box.grid(row=0, column=0, sticky="we", padx=(0, 14))
        row.columnconfigure(0, weight=1, uniform="tg")
        row.columnconfigure(1, weight=1, uniform="tg")
        ttk.Label(box, text="Токен бота", style="CardMuted.TLabel").pack(anchor="w")
        e = self.entry(box, "text", "Токен бота", show="•", textvariable=self._mvar("tg_token"))
        e.pack(fill="x", pady=(4, 0))
        self.m_entries["tg_token"] = e
        box2 = ttk.Frame(row, style="Card.TFrame")
        box2.grid(row=0, column=1, sticky="we")
        ttk.Label(box2, text="chat_id", style="CardMuted.TLabel").pack(anchor="w")
        e2 = self.entry(box2, "text", "chat_id", textvariable=self._mvar("tg_chat"))
        e2.pack(fill="x", pady=(4, 0))
        self.m_entries["tg_chat"] = e2
        ttk.Label(c, text="Токен хранится в config.json рядом с программой. Не отправляй этот файл другим людям.",
                  style="CardMuted.TLabel", font=(FONT, 9)).pack(anchor="w", pady=(10, 0))

    def market_changed(self):
        if self._building:
            return
        m = self.cfg["market"]
        for k, v in self.mv.items():
            try:
                m[k] = v.get()
            except tk.TclError:
                continue
        save_cfg(self.cfg)
        self.refresh_market_ui()

    def refresh_market_ui(self):
        if not hasattr(self, "tree_calc"):
            return
        m = market.resolved(self.cfg["market"])

        def enable(key, on):
            e = self.m_entries.get(key)
            if e is not None:
                e.state(["!disabled"] if on else ["disabled"])

        enable("step", m["mode"] == 1)
        enable("offset", m["mode"] == 3)
        enable("undercut", m["autosell"])
        enable("tg_token", m["telegram"])
        enable("tg_chat", m["telegram"])
        self.tree_calc.delete(*self.tree_calc.get_children())
        rows, full = market.calc_rows(m)
        for mode, name, price, res, warn in rows:
            tags = ("cur",) if mode == m["mode"] else ("warn",) if warn else ()
            self.tree_calc.insert("", "end", values=(name, price, res), tags=tags)
        self.lbl_calc.config(text=f"Фулл для этого лота: {full} G. Выбранный режим подсвечен.")
        if self.current_page == "home":
            self.refresh_home()

    # ---------- Настройка ----------
    def build_settings(self):
        outer, c = self.card(self.tab_settings, "Клики и сервер")
        outer.pack(fill="x")
        ttk.Label(c, text="Задержка между кликами, мс", style="CardMuted.TLabel").pack(anchor="w")
        self.v_delay = tk.StringVar(value=str(self.cfg["click_delay_ms"]))
        self.entry(c, "int", "Задержка, мс", width=14, textvariable=self.v_delay).pack(anchor="w", pady=(4, 14))
        ttk.Label(c, text="Кнопка мыши", style="CardMuted.TLabel").pack(anchor="w")
        self.v_btn = tk.StringVar(value=self.cfg["click_button"])
        ttk.Combobox(c, textvariable=self.v_btn, values=["left", "right", "middle"], width=10, state="readonly").pack(
            anchor="w", pady=(4, 14))
        ttk.Label(c, text="Обновление галочкой, мс", style="CardMuted.TLabel").pack(anchor="w")
        self.entry(c, "int", "Обновление, мс", width=14, textvariable=self._mvar("refresh_ms")).pack(anchor="w", pady=(4, 14))
        ttk.Label(c, text="Адрес сервера", style="CardMuted.TLabel").pack(anchor="w")
        self.v_server = tk.StringVar(value=self.cfg["server"])
        self.entry(c, "text", "Адрес сервера", width=44, textvariable=self.v_server).pack(anchor="w", pady=(4, 14))
        ttk.Button(c, text="Сохранить", style="Accent.TButton", command=self.save_settings).pack(anchor="w")

    def save_settings(self):
        try:
            d = max(1, int(self.v_delay.get()))
        except ValueError:
            return messagebox.showerror("Настройка", "Задержка должна быть числом")
        self.cfg.update(click_delay_ms=d, click_button=self.v_btn.get(), server=self.v_server.get().strip())
        save_cfg(self.cfg)
        messagebox.showinfo("Настройка", "Сохранено")

    # ---------- Пипетка ----------
    def build_pipette(self):
        f = self.tab_pipette
        top = ttk.Frame(f)
        top.pack(fill="x")
        self.swatch = tk.Canvas(top, width=90, height=90, bg="#000", highlightthickness=1, highlightbackground=MUTED)
        self.swatch.pack(side="left")
        info = ttk.Frame(top)
        info.pack(side="left", padx=16)
        self.lbl_hex = ttk.Label(info, text="#000000", font=(MONO, 18, "bold"))
        self.lbl_hex.pack(anchor="w")
        self.lbl_rgb = ttk.Label(info, text="RGB: 0, 0, 0", style="Muted.TLabel")
        self.lbl_rgb.pack(anchor="w")
        self.lbl_pos = ttk.Label(info, text="XY: 0, 0", style="Muted.TLabel")
        self.lbl_pos.pack(anchor="w")
        ttk.Label(f, text=f"Наведи курсор на пиксель и нажми [{self.cfg['pipette_key'].upper()}], чтобы сохранить цвет",
                  style="Muted.TLabel").pack(anchor="w", pady=10)
        self.tree_colors = ttk.Treeview(f, columns=("hex", "rgb", "xy"), show="headings", height=7)
        for c, t, w in (("hex", "HEX", 120), ("rgb", "RGB", 180), ("xy", "Координаты", 160)):
            self.tree_colors.heading(c, text=t)
            self.tree_colors.column(c, width=w)
        self.tree_colors.pack(fill="both", expand=True)
        bar = ttk.Frame(f)
        bar.pack(fill="x", pady=(8, 0))
        ttk.Button(bar, text="Копировать HEX", command=self.copy_hex).pack(side="left")
        ttk.Button(bar, text="Очистить", command=lambda: self.tree_colors.delete(*self.tree_colors.get_children())).pack(
            side="left", padx=8)
        self.cur_color = (0, 0, 0)
        self.cur_pos = (0, 0)
        self.update_pipette()

    def pixel_under_cursor(self):
        x, y = self.mouse.position
        x, y = int(x), int(y)
        img = ImageGrab.grab(bbox=(x, y, x + 1, y + 1), all_screens=True)
        return (x, y), img.convert("RGB").getpixel((0, 0))

    def update_pipette(self):
        if self.api is None:
            return
        try:
            if self.current_page == "pipette":
                self.cur_pos, self.cur_color = self.pixel_under_cursor()
                r, g, b = self.cur_color
                hx = f"#{r:02x}{g:02x}{b:02x}"
                self.swatch.config(bg=hx)
                self.lbl_hex.config(text=hx.upper())
                self.lbl_rgb.config(text=f"RGB: {r}, {g}, {b}")
                self.lbl_pos.config(text=f"XY: {self.cur_pos[0]}, {self.cur_pos[1]}")
        except Exception:
            pass
        self.root.after(60, self.update_pipette)

    def save_color(self):
        r, g, b = self.cur_color
        self.tree_colors.insert("", 0, values=(f"#{r:02X}{g:02X}{b:02X}", f"{r}, {g}, {b}", f"{self.cur_pos[0]}, {self.cur_pos[1]}"))

    def copy_hex(self):
        sel = self.tree_colors.selection()
        val = self.tree_colors.item(sel[0])["values"][0] if sel else self.lbl_hex.cget("text")
        self.root.clipboard_clear()
        self.root.clipboard_append(val)

    # ---------- Горячие клавиши ----------
    def build_keys(self):
        f = self.tab_keys
        self.key_labels = {}
        for i, (k, title) in enumerate((("start_stop_key", "Старт / стоп скрипта"), ("pipette_key", "Сохранить цвет (пипетка)"))):
            ttk.Label(f, text=title, style="Muted.TLabel").grid(row=i, column=0, sticky="w", pady=8)
            lbl = ttk.Label(f, text=self.cfg[k].upper(), font=(MONO, 12, "bold"), width=10)
            lbl.grid(row=i, column=1, padx=16)
            self.key_labels[k] = lbl
            ttk.Button(f, text="Назначить", command=lambda kk=k: self.begin_capture(kk)).grid(row=i, column=2)
        ttk.Label(f, text="Последняя нажатая клавиша:", style="Muted.TLabel").grid(row=3, column=0, sticky="w", pady=(26, 0))
        self.lbl_last = ttk.Label(f, text="—", font=(MONO, 14, "bold"))
        self.lbl_last.grid(row=3, column=1, pady=(26, 0))
        ttk.Label(f, text="Горячие клавиши работают, даже когда окно свернуто.", style="Muted.TLabel").grid(
            row=4, column=0, columnspan=3, sticky="w", pady=20)

    def begin_capture(self, which):
        self.capture = which
        self.key_labels[which].config(text="нажми…")

    def _on_key(self, key):
        name = key_name(key)
        self.root.after(0, lambda: self._handle_key(name))

    def _handle_key(self, name):
        if self.api is None:
            return
        self.lbl_last.config(text=name.upper())
        if self.capture:
            self.cfg[self.capture] = name
            self.key_labels[self.capture].config(text=name.upper())
            self.capture = None
            save_cfg(self.cfg)
            return
        # во время набора текста в поле буквы не должны запускать горячие клавиши
        if len(name) == 1 and isinstance(self.root.focus_get(), (ttk.Entry, tk.Entry)):
            return
        if name == self.cfg["start_stop_key"]:
            self.toggle_script()
        elif name == self.cfg["pipette_key"]:
            self.save_color()

    # ---------- Админка ----------
    def build_admin(self):
        f = self.tab_admin
        self.tree_users = ttk.Treeview(f, columns=("id", "login", "status", "until", "pc"), show="headings", height=9)
        for c, t, w in (("id", "ID", 40), ("login", "Логин", 160), ("status", "Статус", 110),
                        ("until", "Доступ до", 130), ("pc", "ПК привязан", 100)):
            self.tree_users.heading(c, text=t)
            self.tree_users.column(c, width=w)
        self.tree_users.pack(fill="both", expand=True)
        bar = ttk.Frame(f)
        bar.pack(fill="x", pady=(10, 0))
        for text, cmd, st in (("Создать", self.admin_create, "Accent.TButton"), ("+30 дней", lambda: self.admin_patch(add_days=30), "TButton"),
                              ("Блок/разблок", self.admin_toggle, "TButton"), ("Сброс ПК", lambda: self.admin_patch(reset_hwid=True), "TButton"),
                              ("Новый пароль", self.admin_newpass, "TButton"), ("Удалить", self.admin_delete, "TButton")):
            ttk.Button(bar, text=text, command=cmd, style=st).pack(side="left", padx=(0, 6))
        self.users = {}
        self.admin_refresh()

    def admin_refresh(self):
        try:
            users = self.api.call("GET", "/api/admin/users")
        except ApiError as e:
            return self.handle_error(e)
        self.tree_users.delete(*self.tree_users.get_children())
        self.users = {}
        for u in users:
            if u["is_admin"]:
                status, until = "админ", "—"
            else:
                status = "активен" if u["active"] else "заблокирован"
                until = time.strftime("%d.%m.%Y", time.localtime(u["expires"])) if u["expires"] else "бессрочно"
                if u["expires"] and u["expires"] < time.time():
                    status = "истёк"
            iid = self.tree_users.insert("", "end", values=(u["id"], u["username"], status, until, "да" if u["hwid_bound"] else "нет"))
            self.users[iid] = u

    def selected_user(self):
        sel = self.tree_users.selection()
        if not sel:
            messagebox.showinfo("Аккаунты", "Выбери аккаунт в списке")
            return None
        return self.users[sel[0]]

    def show_credentials(self, username, password):
        text = f"Логин: {username}\nПароль: {password}"
        self.root.clipboard_clear()
        self.root.clipboard_append(text)
        messagebox.showinfo("Данные для входа (скопированы в буфер)", text)

    def admin_create(self):
        name = simpledialog.askstring("Новый аккаунт", "Логин (мин. 3 символа):", parent=self.root)
        if not name:
            return
        days = simpledialog.askinteger("Срок", "Сколько дней доступа? (0 = бессрочно)", parent=self.root, initialvalue=30, minvalue=0)
        if days is None:
            return
        pw = simpledialog.askstring("Пароль", "Пароль (пусто = сгенерировать):", parent=self.root) or ""
        try:
            res = self.api.call("POST", "/api/admin/users", json={"username": name, "password": pw, "days": days})
        except ApiError as e:
            return self.handle_error(e)
        self.show_credentials(res["username"], res["password"])
        self.admin_refresh()

    def admin_patch(self, **body):
        u = self.selected_user()
        if not u:
            return
        try:
            res = self.api.call("PATCH", f"/api/admin/users/{u['id']}", json=body)
        except ApiError as e:
            return self.handle_error(e)
        self.admin_refresh()
        return res

    def admin_toggle(self):
        u = self.selected_user()
        if u:
            self.admin_patch(active=not u["active"])

    def admin_newpass(self):
        u = self.selected_user()
        if not u:
            return
        res = self.admin_patch(new_password="")
        if res and res.get("password"):
            self.show_credentials(u["username"], res["password"])

    def admin_delete(self):
        u = self.selected_user()
        if not u:
            return
        if messagebox.askyesno("Удалить", f"Удалить аккаунт {u['username']}?"):
            try:
                self.api.call("DELETE", f"/api/admin/users/{u['id']}")
            except ApiError as e:
                return self.handle_error(e)
            self.admin_refresh()


if __name__ == "__main__":
    App().run()
