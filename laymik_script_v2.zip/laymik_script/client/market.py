"""Настройки площадки и расчёт цены перебива.

Все деньги считаются в копейках (целые числа), чтобы не ловить ошибки округления.
Скрипты читают настройки так:

    from market import resolved, target_cents
    m = resolved(cfg["market"])
    price = target_cents(m, m["mode"], top_cents, sell_cents)
"""

DEFAULT_MARKET = {
    "mode": 3,             # 1 кастом, 2 под фулл, 3 кастом под фулл
    "step": "0.05",        # режим 1: топ-запрос плюс шаг
    "offset": "0.05",      # режим 3: первый лот минус отступ
    "max_price": "0",      # потолок цены, 0 = без потолка
    "antifull": True,      # мод: снимать ордер на потолке, не ставить новый под фулл
    "autosell": True,      # мод: выставлять купленное на продажу
    "undercut": "0.01",    # автопродажа: на сколько ниже первого лота
    "telegram": False,     # мод: сообщения в Telegram
    "tg_token": "",
    "tg_chat": "",
    "refresh_ms": "600",   # как часто нажимать галочку обновления
    "lot": "23.50",        # пример для проверки цены
    "top": "23.10",
}

MODE_NAMES = {1: "1. Кастом", 2: "2. Под фулл", 3: "3. Кастом под фулл"}


def to_float(value, default, minimum=0.0):
    try:
        n = float(str(value).strip().replace(",", "."))
    except ValueError:
        return default
    return n if n >= minimum else default


def to_int(value, default, minimum=0):
    try:
        n = int(str(value).strip())
    except ValueError:
        return default
    return n if n >= minimum else default


def cents(v):
    return int(round(v * 100))


def fmt(c):
    return f"{c / 100:.2f}"


def resolved(m):
    """Строки из полей ввода превращаются в числа, мусор заменяется значениями по умолчанию."""
    d = DEFAULT_MARKET
    return {
        "mode": to_int(m.get("mode"), d["mode"], 1),
        "step": to_float(m.get("step"), 0.05),
        "offset": to_float(m.get("offset"), 0.05),
        "max_price": to_float(m.get("max_price"), 0.0),
        "antifull": bool(m.get("antifull")),
        "autosell": bool(m.get("autosell")),
        "undercut": to_float(m.get("undercut"), 0.01),
        "telegram": bool(m.get("telegram")),
        "tg_token": str(m.get("tg_token", "")),
        "tg_chat": str(m.get("tg_chat", "")),
        "refresh_ms": to_int(m.get("refresh_ms"), 600, 50),
        "lot": to_float(m.get("lot"), 23.50),
        "top": to_float(m.get("top"), 23.10),
    }


def target_cents(m, mode, top, sell):
    """Какую цену поставить. m = resolved(...), top и sell в копейках."""
    full = sell - 1                      # "под фулл" = первый лот минус 0.01
    if mode == 1:
        t = top + cents(m["step"])
    elif mode == 2:
        t = full
    else:
        t = sell - cents(m["offset"])
    if t > full:
        t = full
    if m["max_price"] > 0 and t > cents(m["max_price"]):
        t = cents(m["max_price"])
    return t


def calc_rows(m):
    """Строки таблицы проверки: (режим, название, цена, итог, предупреждение)."""
    sell, top = cents(m["lot"]), cents(m["top"])
    full = sell - 1
    rows = []
    for mode in (1, 2, 3):
        t = target_cents(m, mode, top, sell)
        if t <= top:
            res, warn = "не перебить", True
        elif m["antifull"] and t >= full:
            res, warn = "анти-фулл: пропуск", True
        else:
            res, warn = "перебьёт", False
        rows.append((mode, MODE_NAMES[mode], fmt(t), res, warn))
    return rows, fmt(full)
