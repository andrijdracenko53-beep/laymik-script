"""Свои элементы интерфейса: переключатель, карточки выбора, иконки плиток."""
import tkinter as tk

from theme import ACCENT, ACCENT_FG, FG, FONT, LINE, MUTED, PANEL, PANEL2


class Switch(tk.Canvas):
    """Переключатель вкл/выкл. Связан с tk.BooleanVar."""

    def __init__(self, parent, var, bg=PANEL):
        super().__init__(parent, width=46, height=26, bg=bg, highlightthickness=0, cursor="hand2", takefocus=0)
        self.var = var
        self.bind("<Button-1>", lambda e: self.var.set(not self.var.get()))
        self._trace = var.trace_add("write", lambda *_: self._draw())
        self._draw()

    def _draw(self):
        if not self.winfo_exists():
            return
        self.delete("all")
        on = bool(self.var.get())
        fill = ACCENT if on else PANEL2
        edge = ACCENT if on else LINE
        self.create_oval(1, 1, 25, 25, fill=fill, outline=edge)
        self.create_oval(21, 1, 45, 25, fill=fill, outline=edge)
        self.create_rectangle(13, 1, 33, 26, fill=fill, outline=fill)
        self.create_line(13, 1, 33, 1, fill=edge)
        self.create_line(13, 25, 33, 25, fill=edge)
        cx = 33 if on else 13
        self.create_oval(cx - 8, 5, cx + 8, 21, fill=ACCENT_FG if on else MUTED, outline="")


class ChoiceCards(tk.Frame):
    """Несколько карточек, выбранная подсвечена жёлтым. Связана с tk.IntVar."""

    def __init__(self, parent, options, var, bg=PANEL, wrap=190):
        super().__init__(parent, bg=bg)
        self.var = var
        self.cards = []
        for i, (value, title, desc) in enumerate(options):
            card = tk.Frame(self, bg=PANEL2, highlightthickness=1, highlightbackground=LINE, cursor="hand2")
            card.grid(row=0, column=i, sticky="nsew", padx=(0 if i == 0 else 8, 0))
            self.columnconfigure(i, weight=1, uniform="cards")
            t = tk.Label(card, text=title, font=(FONT, 11, "bold"), anchor="w", bg=PANEL2, fg=FG, cursor="hand2")
            d = tk.Label(card, text=desc, font=(FONT, 9), anchor="w", justify="left", wraplength=wrap,
                         bg=PANEL2, fg=MUTED, cursor="hand2")
            t.pack(fill="x", padx=12, pady=(10, 0))
            d.pack(fill="x", padx=12, pady=(0, 10))
            for w in (card, t, d):
                w.bind("<Button-1>", lambda e, v=value: self.var.set(v))
            self.cards.append((value, card, t, d))
        self._trace = var.trace_add("write", lambda *_: self._paint())
        self._paint()

    def _paint(self):
        if not self.winfo_exists():
            return
        cur = self.var.get()
        for value, card, t, d in self.cards:
            on = value == cur
            bg = ACCENT if on else PANEL2
            card.config(bg=bg, highlightbackground=ACCENT if on else LINE)
            t.config(bg=bg, fg=ACCENT_FG if on else FG)
            d.config(bg=bg, fg=ACCENT_FG if on else MUTED)


def draw_icon(canvas, name, color):
    """Простые значки для плиток главного меню (рисуются линиями, без картинок)."""
    c, w = canvas, 2.4
    if name == "play":
        c.create_polygon(10, 6, 30, 18, 10, 30, fill=color, outline=color)
    elif name == "sliders":
        for y, x in ((9, 22), (18, 12), (27, 26)):
            c.create_line(5, y, 31, y, fill=color, width=w, capstyle="round")
            c.create_oval(x - 4, y - 4, x + 4, y + 4, fill=color, outline=color)
    elif name == "toggle":
        c.create_arc(4, 10, 20, 26, start=90, extent=180, style="arc", outline=color, width=w)
        c.create_arc(16, 10, 32, 26, start=270, extent=180, style="arc", outline=color, width=w)
        c.create_line(12, 10, 24, 10, fill=color, width=w)
        c.create_line(12, 26, 24, 26, fill=color, width=w)
        c.create_oval(21, 13, 29, 23, fill=color, outline=color)
    elif name == "gear":
        c.create_oval(11, 11, 25, 25, outline=color, width=w)
        for x1, y1, x2, y2 in ((18, 3, 18, 9), (18, 27, 18, 33), (3, 18, 9, 18), (27, 18, 33, 18),
                               (7, 7, 11, 11), (25, 25, 29, 29), (29, 7, 25, 11), (7, 29, 11, 25)):
            c.create_line(x1, y1, x2, y2, fill=color, width=w, capstyle="round")
    elif name == "pipette":
        c.create_line(8, 28, 22, 14, fill=color, width=w + 1, capstyle="round")
        c.create_line(20, 10, 27, 17, fill=color, width=w + 3, capstyle="round")
        c.create_line(24, 6, 30, 12, fill=color, width=w, capstyle="round")
        c.create_oval(5, 26, 11, 32, fill=color, outline=color)
    elif name == "keys":
        c.create_rectangle(3, 8, 33, 28, outline=color, width=w)
        for x in (8, 14, 20, 26):
            c.create_rectangle(x, 12, x + 3, 15, fill=color, outline=color)
        for x in (8, 14, 20, 26):
            c.create_rectangle(x, 18, x + 3, 21, fill=color, outline=color)
        c.create_rectangle(10, 23, 26, 25, fill=color, outline=color)
    elif name == "users":
        c.create_oval(11, 5, 25, 19, outline=color, width=w)
        c.create_arc(5, 21, 31, 45, start=0, extent=180, style="arc", outline=color, width=w)
