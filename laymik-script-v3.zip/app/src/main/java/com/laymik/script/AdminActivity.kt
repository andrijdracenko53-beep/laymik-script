package com.laymik.script

import android.content.Context
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class AdminActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_home)

        val sharedPreferences = getSharedPreferences("AppUsers", Context.MODE_PRIVATE)

        Toast.makeText(this, "Админ-панель: Создание аккаунтов доступно", Toast.LENGTH_SHORT).show()
    }
}