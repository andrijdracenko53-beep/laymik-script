package com.laymik.script

import android.content.Context
import android.graphics.Color
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.widget.FrameLayout

class PickerView(context: Context) : FrameLayout(context) {
    init {
        setBackgroundColor(Color.argb(80, 0, 255, 200)) // Perfect click style color picker overlay
    }
}