"""Сервер авторизации для приложения со скриптами.

Запуск:  python server.py
Первый запуск создаёт админа (логин admin). Пароль берётся из переменной
ADMIN_PASSWORD или генерируется и печатается в консоль один раз.
"""
import os
import secrets
import sqlite3
import time
from functools import wraps

from flask import Flask, g, jsonify, request
from werkzeug.security import check_password_hash, generate_password_hash

DB_PATH = os.environ.get("DB_PATH", os.path.join(os.path.dirname(os.path.abspath(__file__)), "data.db"))
TOKEN_TTL = 12 * 3600
MAX_FAILS = 8          # неудачных попыток
FAIL_WINDOW = 600      # за 10 минут с одного IP

app = Flask(__name__)
_fails = {}


def db():
    if "db" not in g:
        g.db = sqlite3.connect(DB_PATH)
        g.db.row_factory = sqlite3.Row
    return g.db


@app.teardown_appcontext
def close_db(_):
    d = g.pop("db", None)
    if d is not None:
        d.close()


def init_db():
    c = sqlite3.connect(DB_PATH)
    c.executescript(
        """
        CREATE TABLE IF NOT EXISTS users(
            id INTEGER PRIMARY KEY,
            username TEXT UNIQUE NOT NULL,
            pw TEXT NOT NULL,
            is_admin INTEGER DEFAULT 0,
            active INTEGER DEFAULT 1,
            expires INTEGER DEFAULT 0,
            hwid TEXT DEFAULT '',
            created INTEGER
        );
        CREATE TABLE IF NOT EXISTS tokens(
            token TEXT PRIMARY KEY,
            user_id INTEGER NOT NULL,
            expires INTEGER NOT NULL
        );
        CREATE TABLE IF NOT EXISTS scripts(
            id INTEGER PRIMARY KEY,
            key TEXT UNIQUE NOT NULL,
            name TEXT NOT NULL,
            description TEXT DEFAULT '',
            enabled INTEGER DEFAULT 1
        );
        """
    )
    if not c.execute("SELECT 1 FROM users WHERE is_admin=1").fetchone():
        pw = os.environ.get("ADMIN_PASSWORD") or secrets.token_urlsafe(9)
        c.execute(
            "INSERT INTO users(username,pw,is_admin,created) VALUES(?,?,1,?)",
            ("admin", generate_password_hash(pw), int(time.time())),
        )
        print("=" * 50)
        print("Создан админ.  Логин: admin   Пароль:", pw)
        print("Сохрани пароль — повторно он не покажется.")
        print("=" * 50)
    # Скрипт 0.03 — заготовка, сам код добавим позже
    c.execute(
        "INSERT OR IGNORE INTO scripts(key,name,description,enabled) VALUES(?,?,?,0)",
        ("0.03", "Скрипт 0.03", "Скоро будет добавлен"),
    )
    c.commit()
    c.close()


def err(msg, code=400):
    return jsonify({"error": msg}), code


def auth(admin=False):
    def deco(f):
        @wraps(f)
        def wrapper(*a, **kw):
            h = request.headers.get("Authorization", "")
            token = h[7:] if h.startswith("Bearer ") else ""
            row = db().execute(
                "SELECT u.*, t.expires AS t_exp FROM tokens t JOIN users u ON u.id=t.user_id WHERE t.token=?",
                (token,),
            ).fetchone()
            if not row or row["t_exp"] < time.time():
                return err("Сессия истекла, войди заново", 401)
            if not row["active"]:
                return err("Аккаунт заблокирован", 403)
            if row["expires"] and row["expires"] < time.time() and not row["is_admin"]:
                return err("Срок доступа закончился", 403)
            if admin and not row["is_admin"]:
                return err("Нет прав", 403)
            g.user = row
            return f(*a, **kw)
        return wrapper
    return deco


def user_dict(r):
    return {
        "id": r["id"],
        "username": r["username"],
        "is_admin": bool(r["is_admin"]),
        "active": bool(r["active"]),
        "expires": r["expires"],
        "hwid_bound": bool(r["hwid"]),
        "created": r["created"],
    }


@app.post("/api/login")
def login():
    ip = request.remote_addr or "?"
    now = time.time()
    recent = [t for t in _fails.get(ip, []) if now - t < FAIL_WINDOW]
    _fails[ip] = recent
    if len(recent) >= MAX_FAILS:
        return err("Слишком много попыток. Подожди 10 минут", 429)

    d = request.get_json(silent=True) or {}
    username = str(d.get("username", "")).strip()
    password = str(d.get("password", ""))
    hwid = str(d.get("hwid", ""))[:64]

    u = db().execute("SELECT * FROM users WHERE username=?", (username,)).fetchone()
    if not u or not check_password_hash(u["pw"], password):
        _fails[ip].append(now)
        return err("Неверный логин или пароль", 401)
    if not u["active"]:
        return err("Аккаунт заблокирован", 403)
    if u["expires"] and u["expires"] < now and not u["is_admin"]:
        return err("Срок доступа закончился", 403)

    if not u["is_admin"]:
        if not hwid:
            return err("Не удалось определить устройство", 400)
        if not u["hwid"]:
            db().execute("UPDATE users SET hwid=? WHERE id=?", (hwid, u["id"]))
        elif u["hwid"] != hwid:
            return err("Аккаунт привязан к другому ПК. Напиши продавцу", 403)

    token = secrets.token_urlsafe(32)
    db().execute("DELETE FROM tokens WHERE user_id=?", (u["id"],))  # одна сессия на аккаунт
    db().execute("INSERT INTO tokens VALUES(?,?,?)", (token, u["id"], int(now + TOKEN_TTL)))
    db().commit()
    return jsonify({"token": token, "user": user_dict(u)})


@app.post("/api/logout")
@auth()
def logout():
    db().execute("DELETE FROM tokens WHERE user_id=?", (g.user["id"],))
    db().commit()
    return jsonify({"ok": True})


@app.get("/api/me")
@auth()
def me():
    return jsonify(user_dict(g.user))


@app.get("/api/scripts")
@auth()
def scripts():
    rows = db().execute("SELECT key,name,description,enabled FROM scripts ORDER BY id").fetchall()
    return jsonify([dict(r) | {"enabled": bool(r["enabled"])} for r in rows])


# ---------- админка ----------

@app.get("/api/admin/users")
@auth(admin=True)
def admin_list():
    rows = db().execute("SELECT * FROM users ORDER BY id").fetchall()
    return jsonify([user_dict(r) for r in rows])


@app.post("/api/admin/users")
@auth(admin=True)
def admin_create():
    d = request.get_json(silent=True) or {}
    username = str(d.get("username", "")).strip()
    password = str(d.get("password", "")) or secrets.token_urlsafe(7)
    days = int(d.get("days") or 0)
    if len(username) < 3:
        return err("Логин минимум 3 символа")
    if len(password) < 6:
        return err("Пароль минимум 6 символов")
    exp = int(time.time() + days * 86400) if days > 0 else 0
    try:
        db().execute(
            "INSERT INTO users(username,pw,expires,created) VALUES(?,?,?,?)",
            (username, generate_password_hash(password), exp, int(time.time())),
        )
        db().commit()
    except sqlite3.IntegrityError:
        return err("Такой логин уже есть")
    return jsonify({"username": username, "password": password})


@app.patch("/api/admin/users/<int:uid>")
@auth(admin=True)
def admin_patch(uid):
    d = request.get_json(silent=True) or {}
    u = db().execute("SELECT * FROM users WHERE id=?", (uid,)).fetchone()
    if not u:
        return err("Не найден", 404)
    if u["is_admin"] and u["id"] != g.user["id"]:
        return err("Нельзя менять другого админа", 403)
    out = {}
    if "active" in d:
        db().execute("UPDATE users SET active=? WHERE id=?", (1 if d["active"] else 0, uid))
        if not d["active"]:
            db().execute("DELETE FROM tokens WHERE user_id=?", (uid,))
    if d.get("add_days"):
        base = max(u["expires"], int(time.time()))
        db().execute("UPDATE users SET expires=? WHERE id=?", (base + int(d["add_days"]) * 86400, uid))
    if d.get("reset_hwid"):
        db().execute("UPDATE users SET hwid='' WHERE id=?", (uid,))
    if d.get("new_password") is not None:
        pw = str(d["new_password"]) or secrets.token_urlsafe(7)
        if len(pw) < 6:
            return err("Пароль минимум 6 символов")
        db().execute("UPDATE users SET pw=? WHERE id=?", (generate_password_hash(pw), uid))
        db().execute("DELETE FROM tokens WHERE user_id=?", (uid,))
        out["password"] = pw
    db().commit()
    return jsonify({"ok": True} | out)


@app.delete("/api/admin/users/<int:uid>")
@auth(admin=True)
def admin_delete(uid):
    u = db().execute("SELECT * FROM users WHERE id=?", (uid,)).fetchone()
    if not u:
        return err("Не найден", 404)
    if u["is_admin"]:
        return err("Админа удалить нельзя", 403)
    db().execute("DELETE FROM tokens WHERE user_id=?", (uid,))
    db().execute("DELETE FROM users WHERE id=?", (uid,))
    db().commit()
    return jsonify({"ok": True})


init_db()

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=int(os.environ.get("PORT", 5000)))
