"""Реестр скриптов клиента.

Ключ — это key скрипта на сервере. Значение — функция run(stop_event, cfg, log)
или None, если скрипт ещё не добавлен.

Скрипт 0.03 добавим позже: напиши функцию и поставь её сюда.
"""


def run_script_0_03(stop_event, cfg, log):
    # TODO: код скрипта 0.03
    raise NotImplementedError


SCRIPTS = {
    "0.03": None,  # заменить на run_script_0_03, когда будет готов
}
