"""Клиент: вход по логину/паролю, вкладки Скрипты / Настройка / Пипетка / Клавиатура (+ Админ)."""
import ctypes
import hashlib
import json
import os
import platform
import sys
import threading
import time
import tkinter as tk
import uuid
from tkinter import messagebox, simpledialog, ttk

import requests
from PIL import ImageGrab
from pynput import keyboard, mouse

from scripts_impl import SCRIPTS

try:
    ctypes.windll.shcore.SetProcessDpiAwareness(2)  # точные координаты на Windows
except Exception:
    pass

APP_DIR = os.path.dirname(os.path.abspath(sys.argv[0]))
CONFIG_PATH = os.path.join(APP_DIR, "config.json")
DEFAULT_CFG = {
    "server": "http://127.0.0.1:5000",
    "username": "",
    "start_stop_key": "f6",
    "pipette_key": "f8",
    "click_delay_ms": 100,
    "click_button": "left",
}

BG, PANEL, FG, ACCENT, MUTED = "#15171c", "#1e2128", "#e8eaed", "#4f8cff", "#8b93a1"


def load_cfg():
    cfg = dict(DEFAULT_CFG)
    try:
        with open(CONFIG_PATH, encoding="utf-8") as f:
            cfg.update(json.load(f))
    except Exception:
        pass
    return cfg


def save_cfg(cfg):
    try:
        with open(CONFIG_PATH, "w", encoding="utf-8") as f:
            json.dump(cfg, f, ensure_ascii=False, indent=2)
    except Exception:
        pass


def get_hwid():
    raw = f"{uuid.getnode()}|{platform.node()}|{platform.machine()}"
    return hashlib.sha256(raw.encode()).hexdigest()[:32]


def key_name(key):
    if hasattr(key, "char") and key.char:
        return key.char.lower()
    return getattr(key, "name", str(key)).lower()


class ApiError(Exception):
    def __init__(self, msg, status=0):
        super().__init__(msg)
        self.status = status


class Api:
    def __init__(self, base):
        self.base = base.rstrip("/")
        self.token = None

    def call(self, method, path, **kw):
        headers = {"Authorization": f"Bearer {self.token}"} if self.token else {}
        try:
            r = requests.request(method, self.base + path, headers=headers, timeout=10, **kw)
        except requests.RequestException:
            raise ApiError("Нет связи с сервером")
        try:
            data = r.json()
        except ValueError:
            data = {}
        if r.status_code >= 400:
            raise ApiError(data.get("error", f"Ошибка {r.status_code}"), r.status_code)
        return data


def style_app(root):
    root.configure(bg=BG)
    s = ttk.Style(root)
    s.theme_use("clam")
    s.configure(".", background=BG, foreground=FG, fieldbackground=PANEL, bordercolor=PANEL, font=("Segoe UI", 10))
    s.configure("TFrame", background=BG)
    s.configure("TLabel", background=BG, foreground=FG)
    s.configure("Muted.TLabel", foreground=MUTED)
    s.configure("Title.TLabel", font=("Segoe UI", 18, "bold"))
    s.configure("TButton", background=PANEL, foreground=FG, padding=8, borderwidth=0)
    s.map("TButton", background=[("active", "#2a2f39")])
    s.configure("Accent.TButton", background=ACCENT, foreground="white")
    s.map("Accent.TButton", background=[("active", "#6a9dff")])
    s.configure("TEntry", fieldbackground=PANEL, foreground=FG, insertcolor=FG, padding=6)
    s.configure("TNotebook", background=BG, borderwidth=0)
    s.configure("TNotebook.Tab", background=PANEL, foreground=MUTED, padding=(18, 8))
    s.map("TNotebook.Tab", background=[("selected", BG)], foreground=[("selected", FG)])
    s.configure("Treeview", background=PANEL, fieldbackground=PANEL, foreground=FG, rowheight=28, borderwidth=0)
    s.configure("Treeview.Heading", background="#2a2f39", foreground=FG)
    s.map("Treeview", background=[("selected", ACCENT)])


class App:
    def __init__(self):
        self.cfg = load_cfg()
        self.root = tk.Tk()
        self.root.title("laymik_script")
        self.root.geometry("760x520")
        style_app(self.root)
        self.api = None
        self.user = None
        self.runner = None
        self.stop_event = threading.Event()
        self.capture = None  # "start_stop_key" / "pipette_key" при назначении клавиши
        self.mouse = mouse.Controller()
        self.listener = keyboard.Listener(on_press=self._on_key)
        self.listener.daemon = True
        self.listener.start()
        self.show_login()
        self.root.mainloop()

    # ---------- вход ----------
    def clear(self):
        for w in self.root.winfo_children():
            w.destroy()

    def show_login(self):
        self.clear()
        self.root.geometry("380x420")
        f = ttk.Frame(self.root, padding=30)
        f.pack(expand=True)
        ttk.Label(f, text="laymik_script", style="Title.TLabel").pack(pady=(0, 18))
        ttk.Label(f, text="Сервер", style="Muted.TLabel").pack(anchor="w")
        self.e_server = ttk.Entry(f, width=32)
        self.e_server.insert(0, self.cfg["server"])
        self.e_server.pack(pady=(0, 10))
        ttk.Label(f, text="Логин", style="Muted.TLabel").pack(anchor="w")
        self.e_user = ttk.Entry(f, width=32)
        self.e_user.insert(0, self.cfg["username"])
        self.e_user.pack(pady=(0, 10))
        ttk.Label(f, text="Пароль", style="Muted.TLabel").pack(anchor="w")
        self.e_pass = ttk.Entry(f, width=32, show="•")
        self.e_pass.pack(pady=(0, 16))
        self.btn_login = ttk.Button(f, text="Войти", style="Accent.TButton", command=self.do_login)
        self.btn_login.pack(fill="x")
        self.lbl_err = ttk.Label(f, text="", foreground="#ff6b6b", wraplength=300)
        self.lbl_err.pack(pady=10)
        self.root.bind("<Return>", lambda e: self.do_login())
        (self.e_pass if self.cfg["username"] else self.e_user).focus()

    def do_login(self):
        server, username, password = self.e_server.get().strip(), self.e_user.get().strip(), self.e_pass.get()
        if not username or not password:
            self.lbl_err.config(text="Введи логин и пароль")
            return
        self.btn_login.config(state="disabled")
        self.lbl_err.config(text="")
        self.root.update_idletasks()
        api = Api(server)
        try:
            data = api.call("POST", "/api/login", json={"username": username, "password": password, "hwid": get_hwid()})
        except ApiError as e:
            self.lbl_err.config(text=str(e))
            self.btn_login.config(state="normal")
            return
        api.token = data["token"]
        self.api, self.user = api, data["user"]
        self.cfg.update(server=server, username=username)
        save_cfg(self.cfg)
        self.root.unbind("<Return>")
        self.show_main()

    def logout(self):
        self.stop_script()
        try:
            self.api.call("POST", "/api/logout")
        except ApiError:
            pass
        self.api = self.user = None
        self.show_login()

    def handle_error(self, e):
        if e.status in (401, 403):
            messagebox.showwarning("Доступ", str(e))
            self.stop_script()
            self.api = self.user = None
            self.show_login()
        else:
            messagebox.showerror("Ошибка", str(e))

    # ---------- главное окно ----------
    def show_main(self):
        self.clear()
        self.root.geometry("760x520")
        top = ttk.Frame(self.root, padding=(14, 10))
        top.pack(fill="x")
        role = "админ" if self.user["is_admin"] else "пользователь"
        ttk.Label(top, text=f"{self.user['username']} · {role}", style="Muted.TLabel").pack(side="left")
        ttk.Button(top, text="Выйти", command=self.logout).pack(side="right")
        if self.user["expires"] and not self.user["is_admin"]:
            left = max(0, int((self.user["expires"] - time.time()) // 86400))
            ttk.Label(top, text=f"Доступ: ещё {left} дн.", style="Muted.TLabel").pack(side="right", padx=12)

        self.nb = ttk.Notebook(self.root)
        self.nb.pack(fill="both", expand=True, padx=14, pady=(0, 14))
        self.tab_scripts = ttk.Frame(self.nb, padding=14)
        self.tab_settings = ttk.Frame(self.nb, padding=14)
        self.tab_pipette = ttk.Frame(self.nb, padding=14)
        self.tab_keys = ttk.Frame(self.nb, padding=14)
        self.nb.add(self.tab_scripts, text="Скрипты")
        self.nb.add(self.tab_settings, text="Настройка")
        self.nb.add(self.tab_pipette, text="Пипетка")
        self.nb.add(self.tab_keys, text="Клавиатура")
        self.build_scripts()
        self.build_settings()
        self.build_pipette()
        self.build_keys()
        if self.user["is_admin"]:
            self.tab_admin = ttk.Frame(self.nb, padding=14)
            self.nb.add(self.tab_admin, text="Аккаунты")
            self.build_admin()

    # ---------- Скрипты ----------
    def build_scripts(self):
        f = self.tab_scripts
        self.tree_scripts = ttk.Treeview(f, columns=("name", "desc", "status"), show="headings", height=8)
        for c, t, w in (("name", "Скрипт", 180), ("desc", "Описание", 340), ("status", "Статус", 120)):
            self.tree_scripts.heading(c, text=t)
            self.tree_scripts.column(c, width=w)
        self.tree_scripts.pack(fill="both", expand=True)
        bar = ttk.Frame(f)
        bar.pack(fill="x", pady=(10, 0))
        ttk.Button(bar, text="Запустить", style="Accent.TButton", command=self.start_script).pack(side="left")
        ttk.Button(bar, text="Остановить", command=self.stop_script).pack(side="left", padx=8)
        ttk.Button(bar, text="Обновить список", command=self.load_scripts).pack(side="left")
        self.lbl_run = ttk.Label(bar, text="", style="Muted.TLabel")
        self.lbl_run.pack(side="right")
        self.log_box = tk.Text(f, height=6, bg=PANEL, fg=FG, bd=0, state="disabled")
        self.log_box.pack(fill="x", pady=(10, 0))
        self.script_rows = {}
        self.load_scripts()

    def load_scripts(self):
        try:
            items = self.api.call("GET", "/api/scripts")
        except ApiError as e:
            return self.handle_error(e)
        self.tree_scripts.delete(*self.tree_scripts.get_children())
        self.script_rows = {}
        for s in items:
            ready = s["enabled"] and SCRIPTS.get(s["key"]) is not None
            status = "готов" if ready else "скоро"
            iid = self.tree_scripts.insert("", "end", values=(s["name"], s["description"], status))
            self.script_rows[iid] = (s["key"], ready)

    def log(self, text):
        def w():
            self.log_box.config(state="normal")
            self.log_box.insert("end", time.strftime("%H:%M:%S ") + text + "\n")
            self.log_box.see("end")
            self.log_box.config(state="disabled")
        self.root.after(0, w)

    def start_script(self):
        if self.runner and self.runner.is_alive():
            return self.log("Скрипт уже запущен")
        sel = self.tree_scripts.selection()
        if not sel:
            return messagebox.showinfo("Скрипты", "Выбери скрипт в списке")
        key, ready = self.script_rows[sel[0]]
        if not ready:
            return messagebox.showinfo("Скрипты", "Этот скрипт скоро будет добавлен")
        self.stop_event.clear()
        self.current_key = key
        self.runner = threading.Thread(target=self._run, args=(key,), daemon=True)
        self.runner.start()
        self.lbl_run.config(text=f"Работает: {key}")

    def _run(self, key):
        try:
            SCRIPTS[key](self.stop_event, self.cfg, self.log)
        except Exception as e:
            self.log(f"Ошибка скрипта: {e}")
        self.log("Скрипт остановлен")
        self.root.after(0, lambda: self.lbl_run.config(text=""))

    def stop_script(self):
        self.stop_event.set()

    def toggle_script(self):
        if self.runner and self.runner.is_alive():
            self.stop_script()
        elif self.api:
            self.start_script()

    # ---------- Настройка ----------
    def build_settings(self):
        f = self.tab_settings
        ttk.Label(f, text="Задержка между кликами, мс", style="Muted.TLabel").grid(row=0, column=0, sticky="w")
        self.v_delay = tk.StringVar(value=str(self.cfg["click_delay_ms"]))
        ttk.Entry(f, textvariable=self.v_delay, width=12).grid(row=1, column=0, sticky="w", pady=(0, 14))
        ttk.Label(f, text="Кнопка мыши", style="Muted.TLabel").grid(row=2, column=0, sticky="w")
        self.v_btn = tk.StringVar(value=self.cfg["click_button"])
        ttk.Combobox(f, textvariable=self.v_btn, values=["left", "right", "middle"], width=10, state="readonly").grid(
            row=3, column=0, sticky="w", pady=(0, 14))
        ttk.Label(f, text="Адрес сервера", style="Muted.TLabel").grid(row=4, column=0, sticky="w")
        self.v_server = tk.StringVar(value=self.cfg["server"])
        ttk.Entry(f, textvariable=self.v_server, width=40).grid(row=5, column=0, sticky="w", pady=(0, 14))
        ttk.Button(f, text="Сохранить", style="Accent.TButton", command=self.save_settings).grid(row=6, column=0, sticky="w")

    def save_settings(self):
        try:
            d = max(1, int(self.v_delay.get()))
        except ValueError:
            return messagebox.showerror("Настройка", "Задержка должна быть числом")
        self.cfg.update(click_delay_ms=d, click_button=self.v_btn.get(), server=self.v_server.get().strip())
        save_cfg(self.cfg)
        messagebox.showinfo("Настройка", "Сохранено")

    # ---------- Пипетка ----------
    def build_pipette(self):
        f = self.tab_pipette
        top = ttk.Frame(f)
        top.pack(fill="x")
        self.swatch = tk.Canvas(top, width=90, height=90, bg="#000", highlightthickness=1, highlightbackground=MUTED)
        self.swatch.pack(side="left")
        info = ttk.Frame(top)
        info.pack(side="left", padx=16)
        self.lbl_hex = ttk.Label(info, text="#000000", font=("Consolas", 18, "bold"))
        self.lbl_hex.pack(anchor="w")
        self.lbl_rgb = ttk.Label(info, text="RGB: 0, 0, 0", style="Muted.TLabel")
        self.lbl_rgb.pack(anchor="w")
        self.lbl_pos = ttk.Label(info, text="XY: 0, 0", style="Muted.TLabel")
        self.lbl_pos.pack(anchor="w")
        ttk.Label(f, text=f"Наведи курсор на пиксель и нажми [{self.cfg['pipette_key'].upper()}], чтобы сохранить цвет",
                  style="Muted.TLabel").pack(anchor="w", pady=10)
        self.tree_colors = ttk.Treeview(f, columns=("hex", "rgb", "xy"), show="headings", height=7)
        for c, t, w in (("hex", "HEX", 120), ("rgb", "RGB", 180), ("xy", "Координаты", 160)):
            self.tree_colors.heading(c, text=t)
            self.tree_colors.column(c, width=w)
        self.tree_colors.pack(fill="both", expand=True)
        bar = ttk.Frame(f)
        bar.pack(fill="x", pady=(8, 0))
        ttk.Button(bar, text="Копировать HEX", command=self.copy_hex).pack(side="left")
        ttk.Button(bar, text="Очистить", command=lambda: self.tree_colors.delete(*self.tree_colors.get_children())).pack(
            side="left", padx=8)
        self.cur_color = (0, 0, 0)
        self.cur_pos = (0, 0)
        self.update_pipette()

    def pixel_under_cursor(self):
        x, y = self.mouse.position
        x, y = int(x), int(y)
        img = ImageGrab.grab(bbox=(x, y, x + 1, y + 1), all_screens=True)
        return (x, y), img.convert("RGB").getpixel((0, 0))

    def update_pipette(self):
        if self.api is None:
            return
        try:
            if self.nb.index(self.nb.select()) == 2:
                self.cur_pos, self.cur_color = self.pixel_under_cursor()
                r, g, b = self.cur_color
                hx = f"#{r:02x}{g:02x}{b:02x}"
                self.swatch.config(bg=hx)
                self.lbl_hex.config(text=hx.upper())
                self.lbl_rgb.config(text=f"RGB: {r}, {g}, {b}")
                self.lbl_pos.config(text=f"XY: {self.cur_pos[0]}, {self.cur_pos[1]}")
        except Exception:
            pass
        self.root.after(60, self.update_pipette)

    def save_color(self):
        r, g, b = self.cur_color
        self.tree_colors.insert("", 0, values=(f"#{r:02X}{g:02X}{b:02X}", f"{r}, {g}, {b}", f"{self.cur_pos[0]}, {self.cur_pos[1]}"))

    def copy_hex(self):
        sel = self.tree_colors.selection()
        val = self.tree_colors.item(sel[0])["values"][0] if sel else self.lbl_hex.cget("text")
        self.root.clipboard_clear()
        self.root.clipboard_append(val)

    # ---------- Клавиатура ----------
    def build_keys(self):
        f = self.tab_keys
        self.key_labels = {}
        for i, (k, title) in enumerate((("start_stop_key", "Старт / стоп скрипта"), ("pipette_key", "Сохранить цвет (пипетка)"))):
            ttk.Label(f, text=title, style="Muted.TLabel").grid(row=i, column=0, sticky="w", pady=8)
            lbl = ttk.Label(f, text=self.cfg[k].upper(), font=("Consolas", 12, "bold"), width=10)
            lbl.grid(row=i, column=1, padx=16)
            self.key_labels[k] = lbl
            ttk.Button(f, text="Назначить", command=lambda kk=k: self.begin_capture(kk)).grid(row=i, column=2)
        ttk.Label(f, text="Последняя нажатая клавиша:", style="Muted.TLabel").grid(row=3, column=0, sticky="w", pady=(26, 0))
        self.lbl_last = ttk.Label(f, text="—", font=("Consolas", 14, "bold"))
        self.lbl_last.grid(row=3, column=1, pady=(26, 0))
        ttk.Label(f, text="Горячие клавиши работают, даже когда окно свернуто.", style="Muted.TLabel").grid(
            row=4, column=0, columnspan=3, sticky="w", pady=20)

    def begin_capture(self, which):
        self.capture = which
        self.key_labels[which].config(text="нажми…")

    def _on_key(self, key):
        name = key_name(key)
        self.root.after(0, lambda: self._handle_key(name))

    def _handle_key(self, name):
        if self.api is None:
            return
        self.lbl_last.config(text=name.upper())
        if self.capture:
            self.cfg[self.capture] = name
            self.key_labels[self.capture].config(text=name.upper())
            self.capture = None
            save_cfg(self.cfg)
            return
        if name == self.cfg["start_stop_key"]:
            self.toggle_script()
        elif name == self.cfg["pipette_key"]:
            self.save_color()

    # ---------- Админка ----------
    def build_admin(self):
        f = self.tab_admin
        self.tree_users = ttk.Treeview(f, columns=("id", "login", "status", "until", "pc"), show="headings", height=9)
        for c, t, w in (("id", "ID", 40), ("login", "Логин", 160), ("status", "Статус", 110),
                        ("until", "Доступ до", 130), ("pc", "ПК привязан", 100)):
            self.tree_users.heading(c, text=t)
            self.tree_users.column(c, width=w)
        self.tree_users.pack(fill="both", expand=True)
        bar = ttk.Frame(f)
        bar.pack(fill="x", pady=(10, 0))
        for text, cmd, st in (("Создать", self.admin_create, "Accent.TButton"), ("+30 дней", lambda: self.admin_patch(add_days=30), "TButton"),
                              ("Блок/разблок", self.admin_toggle, "TButton"), ("Сброс ПК", lambda: self.admin_patch(reset_hwid=True), "TButton"),
                              ("Новый пароль", self.admin_newpass, "TButton"), ("Удалить", self.admin_delete, "TButton")):
            ttk.Button(bar, text=text, command=cmd, style=st).pack(side="left", padx=(0, 6))
        self.users = {}
        self.admin_refresh()

    def admin_refresh(self):
        try:
            users = self.api.call("GET", "/api/admin/users")
        except ApiError as e:
            return self.handle_error(e)
        self.tree_users.delete(*self.tree_users.get_children())
        self.users = {}
        for u in users:
            if u["is_admin"]:
                status, until = "админ", "—"
            else:
                status = "активен" if u["active"] else "заблокирован"
                until = time.strftime("%d.%m.%Y", time.localtime(u["expires"])) if u["expires"] else "бессрочно"
                if u["expires"] and u["expires"] < time.time():
                    status = "истёк"
            iid = self.tree_users.insert("", "end", values=(u["id"], u["username"], status, until, "да" if u["hwid_bound"] else "нет"))
            self.users[iid] = u

    def selected_user(self):
        sel = self.tree_users.selection()
        if not sel:
            messagebox.showinfo("Аккаунты", "Выбери аккаунт в списке")
            return None
        return self.users[sel[0]]

    def show_credentials(self, username, password):
        text = f"Логин: {username}\nПароль: {password}"
        self.root.clipboard_clear()
        self.root.clipboard_append(text)
        messagebox.showinfo("Данные для входа (скопированы в буфер)", text)

    def admin_create(self):
        name = simpledialog.askstring("Новый аккаунт", "Логин (мин. 3 символа):", parent=self.root)
        if not name:
            return
        days = simpledialog.askinteger("Срок", "Сколько дней доступа? (0 = бессрочно)", parent=self.root, initialvalue=30, minvalue=0)
        if days is None:
            return
        pw = simpledialog.askstring("Пароль", "Пароль (пусто = сгенерировать):", parent=self.root) or ""
        try:
            res = self.api.call("POST", "/api/admin/users", json={"username": name, "password": pw, "days": days})
        except ApiError as e:
            return self.handle_error(e)
        self.show_credentials(res["username"], res["password"])
        self.admin_refresh()

    def admin_patch(self, **body):
        u = self.selected_user()
        if not u:
            return
        try:
            res = self.api.call("PATCH", f"/api/admin/users/{u['id']}", json=body)
        except ApiError as e:
            return self.handle_error(e)
        self.admin_refresh()
        return res

    def admin_toggle(self):
        u = self.selected_user()
        if u:
            self.admin_patch(active=not u["active"])

    def admin_newpass(self):
        u = self.selected_user()
        if not u:
            return
        res = self.admin_patch(new_password="")
        if res and res.get("password"):
            self.show_credentials(u["username"], res["password"])

    def admin_delete(self):
        u = self.selected_user()
        if not u:
            return
        if messagebox.askyesno("Удалить", f"Удалить аккаунт {u['username']}?"):
            try:
                self.api.call("DELETE", f"/api/admin/users/{u['id']}")
            except ApiError as e:
                return self.handle_error(e)
            self.admin_refresh()


if __name__ == "__main__":
    App()
