# ==========================================
# [ LAYMIK DISCORD BOT / SCRIPT ]
# ==========================================
import discord
from discord.ext import commands

print("LAYMIK environment active :)")

# Add your typical get_a_role / remove_role logic here
