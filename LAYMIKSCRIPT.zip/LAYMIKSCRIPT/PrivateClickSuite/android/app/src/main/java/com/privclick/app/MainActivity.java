package com.privclick.app;
import android.app.*; import android.os.*; import android.content.*; import android.graphics.Color; import android.view.*; import android.widget.*;
public class MainActivity extends Activity {
 public void onCreate(Bundle b){super.onCreate(b); LinearLayout l=new LinearLayout(this); l.setOrientation(LinearLayout.VERTICAL); l.setPadding(32,32,32,32); TextView t=new TextView(this); t.setText("LAYMIKSCRIPT\n\nВход пользователя и управление автокликером — подключаются к серверному API.\n\nAccessibility Service: включи её в настройках Android для автоматических нажатий."); t.setTextSize(18); l.addView(t); Button s=new Button(this); s.setText("Открыть настройки специальных возможностей"); s.setOnClickListener(v->startActivity(new Intent("android.settings.ACCESSIBILITY_SETTINGS"))); l.addView(s); setContentView(l); }
}
