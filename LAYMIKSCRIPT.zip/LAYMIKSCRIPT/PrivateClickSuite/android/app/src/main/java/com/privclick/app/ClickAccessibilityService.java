package com.privclick.app;
import android.accessibilityservice.AccessibilityService; import android.view.accessibility.AccessibilityEvent;
public class ClickAccessibilityService extends AccessibilityService { public void onAccessibilityEvent(AccessibilityEvent e){} public void onInterrupt(){} }
