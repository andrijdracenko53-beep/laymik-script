import os, sqlite3, secrets
from datetime import datetime, timezone
from fastapi import FastAPI, HTTPException, Header
from pydantic import BaseModel
from passlib.hash import argon2

DB = os.getenv('PRIVATECLICK_DB', 'privateclick.db')
ADMIN_KEY = os.getenv('PRIVATECLICK_ADMIN_KEY', 'CHANGE_ME_NOW')
app = FastAPI(title='LAYMIKSCRIPT API', version='1.0')

def db():
    c=sqlite3.connect(DB); c.row_factory=sqlite3.Row
    c.execute('''CREATE TABLE IF NOT EXISTS users(id INTEGER PRIMARY KEY AUTOINCREMENT, username TEXT UNIQUE NOT NULL, password_hash TEXT NOT NULL, status TEXT NOT NULL DEFAULT 'active', expires_at TEXT, created_at TEXT NOT NULL)''')
    c.execute('''CREATE TABLE IF NOT EXISTS sessions(token TEXT PRIMARY KEY, user_id INTEGER NOT NULL, created_at TEXT NOT NULL)''')
    c.commit(); return c

def now(): return datetime.now(timezone.utc)
def admin(x_admin_key):
    if not x_admin_key or not secrets.compare_digest(x_admin_key, ADMIN_KEY): raise HTTPException(401,'Admin authentication required')
def refresh_status(row):
    if row['status']=='active' and row['expires_at']:
        try:
            if datetime.fromisoformat(row['expires_at']) <= now():
                with db() as c: c.execute("UPDATE users SET status='frozen' WHERE id=?",(row['id'],)); c.commit()
                return 'frozen'
        except ValueError: pass
    return row['status']
class Login(BaseModel): username:str; password:str
class CreateUser(BaseModel): username:str; password:str; expires_at:str|None=None
class Expire(BaseModel): expires_at:str|None=None

@app.on_event('startup')
def startup(): db().close()
@app.get('/health')
def health(): return {'ok':True}
@app.post('/auth/login')
def login(x:Login):
    with db() as c: r=c.execute('SELECT * FROM users WHERE username=?',(x.username,)).fetchone()
    if not r or not argon2.verify(x.password,r['password_hash']): raise HTTPException(401,'Invalid credentials')
    status=refresh_status(r)
    if status!='active': raise HTTPException(403,f'Account {status}')
    token=secrets.token_urlsafe(32)
    with db() as c: c.execute('INSERT INTO sessions VALUES(?,?,?)',(token,r['id'],now().isoformat())); c.commit()
    return {'token':token,'username':r['username'],'expires_at':r['expires_at']}
@app.get('/me')
def me(authorization:str=Header(default='')):
    token=authorization.removeprefix('Bearer ').strip()
    with db() as c: r=c.execute('SELECT u.* FROM users u JOIN sessions s ON s.user_id=u.id WHERE s.token=?',(token,)).fetchone()
    if not r: raise HTTPException(401,'Invalid session')
    status=refresh_status(r)
    if status!='active': raise HTTPException(403,f'Account {status}')
    return {'username':r['username'],'status':status,'expires_at':r['expires_at']}
@app.get('/admin/users')
def users(x_admin_key:str|None=Header(default=None)):
    admin(x_admin_key)
    with db() as c: rows=c.execute('SELECT id,username,status,expires_at,created_at FROM users ORDER BY id DESC').fetchall()
    return [dict(r, status=refresh_status(r)) for r in rows]
@app.post('/admin/users')
def create(x:CreateUser,x_admin_key:str|None=Header(default=None)):
    admin(x_admin_key)
    try:
        with db() as c:
            c.execute('INSERT INTO users(username,password_hash,expires_at,created_at) VALUES(?,?,?,?)',(x.username,argon2.hash(x.password),x.expires_at,now().isoformat())); c.commit()
    except sqlite3.IntegrityError: raise HTTPException(409,'Username already exists')
    return {'ok':True}
@app.post('/admin/users/{uid}/freeze')
def freeze(uid:int,x_admin_key:str|None=Header(default=None)):
    admin(x_admin_key)
    with db() as c: c.execute("UPDATE users SET status='frozen' WHERE id=?",(uid,)); c.commit()
    return {'ok':True}
@app.post('/admin/users/{uid}/unfreeze')
def unfreeze(uid:int,x_admin_key:str|None=Header(default=None)):
    admin(x_admin_key)
    with db() as c: c.execute("UPDATE users SET status='active' WHERE id=?",(uid,)); c.commit()
    return {'ok':True}
@app.post('/admin/users/{uid}/expire')
def expire(uid:int,x:Expire,x_admin_key:str|None=Header(default=None)):
    admin(x_admin_key)
    with db() as c: c.execute("UPDATE users SET expires_at=?, status='active' WHERE id=?",(x.expires_at,uid)); c.commit()
    return {'ok':True}
@app.delete('/admin/users/{uid}')
def delete(uid:int,x_admin_key:str|None=Header(default=None)):
    admin(x_admin_key)
    with db() as c:
        c.execute('DELETE FROM sessions WHERE user_id=?',(uid,)); c.execute('DELETE FROM users WHERE id=?',(uid,)); c.commit()
    return {'ok':True}
