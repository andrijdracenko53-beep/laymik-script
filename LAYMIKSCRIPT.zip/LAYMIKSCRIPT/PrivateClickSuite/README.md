# LAYMIKSCRIPT Suite

Архитектура приватного Android-автокликера с серверной авторизацией и админ-панелью.

## Состав
- `android/` — Android-клиент (каркас; Accessibility Service подключается здесь).
- `server/` — FastAPI API + SQLite для аккаунтов и сессий.
- `admin/` — простая веб-админка.

## Возможности
- аккаунты создаются администратором;
- вход по логину/паролю;
- блокировка/разблокировка;
- удаление;
- автоматическая блокировка по `expires_at`;
- серверная проверка статуса;
- пароль хранится только в виде Argon2-хеша.

## Запуск сервера
```bash
cd server
python -m venv .venv
# Windows: .venv\\Scripts\\activate
# Android/Termux: source .venv/bin/activate
pip install -r requirements.txt
python -m uvicorn main:app --host 0.0.0.0 --port 8000
```

Админ-API защищён `X-Admin-Key`. Для продакшена заменить на нормальную JWT/OAuth2-аутентификацию и HTTPS.

## Важно
Это стартовый каркас, а не готовый APK. Для автоматических нажатий Android использует AccessibilityService и должен показывать пользователю системное разрешение.
