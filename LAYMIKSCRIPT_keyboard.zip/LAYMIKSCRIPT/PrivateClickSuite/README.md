# LAYMIKSCRIPT v3

Полностью переделанный Android-каркас приложения:

- Главное меню содержит только **Пипетка / Запустить / Клавиатура / Настройки**.
- Пипетка — плавающий draggable-крестик поверх других приложений. Нажатие сохраняет координату.
- Запуск — выполняет сохранённые точки через Android AccessibilityService с заданным интервалом.
- Клавиатура — показывает включённые системные IME и позволяет выбрать одну как клавиатуру приложения; выбор сохраняется.
- Настройки — интервал, очистка точек, Accessibility и разрешение overlay.

Для сборки нужен Android Studio/Gradle с Android SDK 35. На Android сначала нужно вручную разрешить overlay и Accessibility Service.


## Keyboard bridge
The existing keyboard layout is unchanged. LAYMIKSCRIPT now requests Android accessibility key-event filtering and exposes raw KeyEvent data (key code, down/up action, repeat count) to the app via the `com.laymik.script.KEY` broadcast. The service returns `false`, so keys remain pass-through to the foreground application. Physical, USB and Bluetooth keyboards can therefore be consumed by the script without replacing the Android keyboard.
