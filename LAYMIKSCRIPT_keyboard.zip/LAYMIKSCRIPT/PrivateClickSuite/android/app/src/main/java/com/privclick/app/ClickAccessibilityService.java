package com.privclick.app;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.GestureDescription;
import android.graphics.Path;
import android.graphics.Point;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.KeyEvent;
import android.view.accessibility.AccessibilityEvent;
import java.util.ArrayList;

/**
 * Click engine + keyboard bridge. Existing click keys are not remapped.
 * Physical/USB/Bluetooth keyboard events are captured and exposed to the
 * script through the app's local state.
 */
public class ClickAccessibilityService extends AccessibilityService {
    public static ClickAccessibilityService instance;
    private final Handler h = new Handler(Looper.getMainLooper());
    private boolean running = false;
    private ArrayList<Point> points = new ArrayList<>();
    private long interval = 100;

    public void onServiceConnected() {
        instance = this;
    }

    @Override public void onAccessibilityEvent(AccessibilityEvent e) {}
    @Override public void onInterrupt() {}

    /** Keyboard input support for the script; no key remapping is performed. */
    @Override public boolean onKeyEvent(KeyEvent event) {
        if (event == null) return false;
        sendBroadcast(ScriptKeyboard.intent(event));
        // Return false so Android/the foreground app can continue receiving the key.
        return false;
    }

    public void toggle(ArrayList<Point> p, long i) {
        if (running) {
            running = false;
            h.removeCallbacksAndMessages(null);
            return;
        }
        points = p == null ? new ArrayList<>() : new ArrayList<>(p);
        interval = Math.max(1, i);
        running = true;
        runClicks();
    }

    private void runClicks() {
        if (!running) return;
        for (Point pt : points) tap(pt.x, pt.y);
        h.postDelayed(this::runClicks, interval);
    }

    private void tap(int x, int y) {
        Path path = new Path();
        path.moveTo(x, y);
        GestureDescription.StrokeDescription s =
                new GestureDescription.StrokeDescription(path, 0, 30);
        dispatchGesture(new GestureDescription.Builder().addStroke(s).build(), null, null);
    }

    @Override public void onDestroy() {
        running = false;
        h.removeCallbacksAndMessages(null);
        if (instance == this) instance = null;
        super.onDestroy();
    }
}
