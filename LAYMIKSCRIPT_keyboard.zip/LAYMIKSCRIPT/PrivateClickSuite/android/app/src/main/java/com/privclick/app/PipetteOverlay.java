package com.privclick.app;
import android.app.*;import android.content.*;import android.graphics.*;import android.graphics.drawable.*;import android.view.*;import android.widget.*;import java.util.*;
public class PipetteOverlay {
 final Context c; final WindowManager wm; View dot; WindowManager.LayoutParams lp; float downX,downY; boolean moved;
 PipetteOverlay(Context c){this.c=c;wm=(WindowManager)c.getSystemService(Context.WINDOW_SERVICE);}
 void show(){FrameLayout box=new FrameLayout(c);TextView t=new TextView(c);t.setText("✚");t.setTextSize(30);t.setTextColor(Color.WHITE);t.setGravity(Gravity.CENTER);GradientDrawable bg=new GradientDrawable();bg.setColor(0xCC5E5CE6);bg.setShape(GradientDrawable.OVAL);t.setBackground(bg);box.addView(t,new FrameLayout.LayoutParams(64,64));TextView hint=new TextView(c);hint.setText("Перетащи ✚ в нужное место\nНажми для сохранения точки");hint.setTextColor(Color.WHITE);hint.setTextSize(14);hint.setPadding(20,12,20,12);hint.setBackgroundColor(0xDD202026);FrameLayout.LayoutParams hp=new FrameLayout.LayoutParams(-2,-2);hp.leftMargin=10;hp.topMargin=75;box.addView(hint,hp);
 lp=new WindowManager.LayoutParams(64,64,WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,PixelFormat.TRANSLUCENT);lp.gravity=Gravity.TOP|Gravity.LEFT;lp.x=200;lp.y=500;dot=box;wm.addView(dot,lp);
 t.setOnTouchListener((v,e)->{if(e.getAction()==0){downX=e.getRawX();downY=e.getRawY();moved=false;return true;}if(e.getAction()==2){float dx=e.getRawX()-downX,dy=e.getRawY()-downY;if(Math.abs(dx)+Math.abs(dy)>8)moved=true;lp.x+=dx;lp.y+=dy;downX=e.getRawX();downY=e.getRawY();wm.updateViewLayout(dot,lp);return true;}if(e.getAction()==1&&!moved){save(lp.x+32,lp.y+32);Toast.makeText(c,"Точка сохранена: "+(lp.x+32)+", "+(lp.y+32),Toast.LENGTH_SHORT).show();}return true;});
 hint.setOnClickListener(v->{wm.removeView(dot);}); }
 void save(int x,int y){android.content.SharedPreferences p=c.getSharedPreferences("laymikscript",Context.MODE_PRIVATE);int n=p.getInt("point_count",0);p.edit().putInt("x"+n,x).putInt("y"+n,y).putInt("point_count",n+1).apply();}
}
