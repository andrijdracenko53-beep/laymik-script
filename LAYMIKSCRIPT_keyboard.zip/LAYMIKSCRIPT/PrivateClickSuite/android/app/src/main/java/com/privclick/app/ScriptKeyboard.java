package com.privclick.app;

import android.content.Intent;
import android.view.KeyEvent;

/** Lightweight keyboard bridge for LAYMIKSCRIPT scripts. */
public final class ScriptKeyboard {
    public static final String ACTION_KEY = "com.laymik.script.KEY";
    public static final String EXTRA_KEY_CODE = "key_code";
    public static final String EXTRA_ACTION = "action";
    public static final String EXTRA_REPEAT = "repeat";

    private ScriptKeyboard() {}

    public static void publish(KeyEvent event) {
        Intent i = new Intent(ACTION_KEY);
        i.setPackage("com.privclick.app");
        i.putExtra(EXTRA_KEY_CODE, event.getKeyCode());
        i.putExtra(EXTRA_ACTION, event.getAction());
        i.putExtra(EXTRA_REPEAT, event.getRepeatCount());
        // Local app broadcast: the script can listen without changing the keyboard layout.
        try {
            // sendBroadcast is intentionally not called here because a Service instance
            // is required; consumers can call ScriptKeyboard.intent(event) instead.
        } catch (Exception ignored) {}
    }

    public static Intent intent(KeyEvent event) {
        Intent i = new Intent(ACTION_KEY);
        i.putExtra(EXTRA_KEY_CODE, event.getKeyCode());
        i.putExtra(EXTRA_ACTION, event.getAction());
        i.putExtra(EXTRA_REPEAT, event.getRepeatCount());
        return i;
    }
}
