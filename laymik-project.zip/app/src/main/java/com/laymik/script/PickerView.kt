package com.laymik.script

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import android.view.MotionEvent
import android.view.View

// Полноэкранный слой пипетки: перекрестие, лупа с живым цветом и координатами.
class PickerView(
    ctx: Context,
    private val onPick: (Int, Int, Int?) -> Unit,
    private val onCancel: () -> Unit
) : View(ctx) {
    private val d = resources.displayMetrics.density
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val tp = Paint(Paint.ANTI_ALIAS_FLAG)
    private val cancelRect = RectF()

    // 0 ожидание, 1 палец на экране, 2 готово (ничего не рисуем, чтобы цвет был чистым)
    private var state = 0
    private var vx = 0f
    private var vy = 0f
    private var rx = 0
    private var ry = 0
    private var color: Int? = null

    private val poll = object : Runnable {
        override fun run() {
            if (state != 1) return
            color = CaptureService.colorAt(rx, ry)
            invalidate()
            postDelayed(this, 50)
        }
    }

    init {
        tp.textAlign = Paint.Align.CENTER
        tp.typeface = Typeface.DEFAULT_BOLD
    }

    private fun update(e: MotionEvent) {
        vx = e.x
        vy = e.y
        rx = e.rawX.toInt()
        ry = e.rawY.toInt()
        invalidate()
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        if (e.action == MotionEvent.ACTION_DOWN) {
            if (state == 0 && cancelRect.contains(e.x, e.y)) {
                onCancel()
                return true
            }
            state = 1
            update(e)
            post(poll)
        } else if (e.action == MotionEvent.ACTION_MOVE) {
            if (state == 1) update(e)
        } else if (e.action == MotionEvent.ACTION_UP) {
            if (state == 1) {
                state = 2
                invalidate()
                val x = rx
                val y = ry
                postDelayed({ onPick(x, y, CaptureService.colorAt(x, y)) }, 160)
            }
        } else if (e.action == MotionEvent.ACTION_CANCEL) {
            state = 0
            invalidate()
        }
        return true
    }

    private fun pill(c: Canvas, cx: Float, cy: Float, label: String, size: Float, fill: Int, stroke: Int, textColor: Int): RectF {
        tp.textSize = size
        tp.color = textColor
        val tw = tp.measureText(label)
        val h = size + 22f * d
        val rect = RectF(cx - tw / 2 - 18f * d, cy - h / 2, cx + tw / 2 + 18f * d, cy + h / 2)
        paint.style = Paint.Style.FILL
        paint.color = fill
        c.drawRoundRect(rect, h / 2, h / 2, paint)
        paint.style = Paint.Style.STROKE
        paint.strokeWidth = 1.5f * d
        paint.color = stroke
        c.drawRoundRect(rect, h / 2, h / 2, paint)
        c.drawText(label, cx, cy + size * 0.35f, tp)
        return rect
    }

    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        if (state == 0) {
            pill(c, w / 2, 52f * d, "Коснись нужной точки и води пальцем", 14f * d, 0xEE0B111C.toInt(), 0xFF22E3A1.toInt(), Color.WHITE)
            pill(c, w / 2, 100f * d, "Отпусти, и точка сохранится", 12f * d, 0xEE0B111C.toInt(), 0xFF2B3A55.toInt(), 0xFF8A97A8.toInt())
            val r = pill(c, w / 2, 148f * d, "✕  Отмена", 13f * d, 0xEE0B111C.toInt(), 0xFFFF5C7A.toInt(), 0xFFFF8FA3.toInt())
            cancelRect.set(r)
        } else if (state == 1) {
            val gap = 26f * d
            paint.style = Paint.Style.STROKE
            paint.strokeWidth = 1.5f * d
            paint.color = 0xCC22E3A1.toInt()
            c.drawLine(0f, vy, vx - gap, vy, paint)
            c.drawLine(vx + gap, vy, w, vy, paint)
            c.drawLine(vx, 0f, vx, vy - gap, paint)
            c.drawLine(vx, vy + gap, vx, h, paint)
            paint.strokeWidth = 2f * d
            c.drawCircle(vx, vy, 18f * d, paint)

            // лупа с живым цветом
            val r = 40f * d
            var cy = vy - 110f * d
            if (cy < r + 10f * d) cy = vy + 110f * d
            val cx = Math.min(Math.max(vx, r + 8f * d), w - r - 8f * d)
            val col = color
            paint.style = Paint.Style.FILL
            paint.color = if (col == null) 0xFF333B4A.toInt() else (0xFF000000.toInt() or col)
            c.drawCircle(cx, cy, r, paint)
            paint.style = Paint.Style.STROKE
            paint.strokeWidth = 4f * d
            paint.color = Color.WHITE
            c.drawCircle(cx, cy, r, paint)
            paint.strokeWidth = 2f * d
            paint.color = 0xFF0B111C.toInt()
            c.drawCircle(cx, cy, r + 3f * d, paint)

            val hex = if (col == null) "…" else "#" + String.format("%06X", col)
            pill(c, cx, cy + r + 30f * d, hex + "   " + rx + ", " + ry, 13f * d, 0xEE0B111C.toInt(), 0xFF22E3A1.toInt(), Color.WHITE)
        }
    }
}
