package com.laymik.script

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.Image
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.util.DisplayMetrics
import android.view.WindowManager

class CaptureService : Service() {
    companion object {
        // Захват в уменьшенном размере: меньше нагрузка и быстрее кадры
        const val SCALE = 2

        @Volatile
        var instance: CaptureService? = null

        // взять свежий кадр и прочитать пиксель (для пипетки)
        fun colorAt(x: Int, y: Int): Int? {
            val s = instance ?: return null
            s.refresh()
            return s.readPixel(x, y)
        }

        // взять свежий кадр один раз за круг
        fun frame() {
            instance?.refresh()
        }

        // прочитать пиксель из уже взятого кадра
        fun pixel(x: Int, y: Int): Int? = instance?.readPixel(x, y)
    }

    private var projection: MediaProjection? = null
    private var reader: ImageReader? = null
    private var vdisplay: VirtualDisplay? = null
    private var held: Image? = null
    private var listener: DisplayManager.DisplayListener? = null
    private var w = 0
    private var h = 0
    private var dpi = 0

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        startAsForeground()
        val code = intent?.getIntExtra("code", 0) ?: 0
        @Suppress("DEPRECATION")
        val data = intent?.getParcelableExtra<Intent>("data")
        if (data == null) {
            stopSelf()
            return START_NOT_STICKY
        }
        val mpm = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        val proj = mpm.getMediaProjection(code, data)
        projection = proj
        proj.registerCallback(object : MediaProjection.Callback() {
            override fun onStop() {
                stopSelf()
            }
        }, Handler(Looper.getMainLooper()))
        readSize()
        val r = ImageReader.newInstance(w / SCALE, h / SCALE, PixelFormat.RGBA_8888, 3)
        reader = r
        vdisplay = proj.createVirtualDisplay(
            "laymik", w / SCALE, h / SCALE, dpi,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
            r.surface, null, null
        )
        val dm = getSystemService(Context.DISPLAY_SERVICE) as DisplayManager
        val l = object : DisplayManager.DisplayListener {
            override fun onDisplayAdded(displayId: Int) {}
            override fun onDisplayRemoved(displayId: Int) {}
            override fun onDisplayChanged(displayId: Int) {
                rebuild()
            }
        }
        listener = l
        dm.registerDisplayListener(l, Handler(Looper.getMainLooper()))
        instance = this
        return START_NOT_STICKY
    }

    private fun startAsForeground() {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(
            NotificationChannel("laymik", "Laymik", NotificationManager.IMPORTANCE_LOW)
        )
        val n = Notification.Builder(this, "laymik")
            .setContentTitle("Laymik Script")
            .setContentText("Доступ к экрану включён")
            .setSmallIcon(R.drawable.ic_launcher)
            .build()
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
        } else {
            startForeground(1, n)
        }
    }

    @Suppress("DEPRECATION")
    private fun readSize() {
        val wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        val dm = DisplayMetrics()
        wm.defaultDisplay.getRealMetrics(dm)
        w = dm.widthPixels
        h = dm.heightPixels
        dpi = dm.densityDpi
    }

    // экран повернулся: пересоздаём буфер под новый размер
    @Synchronized
    private fun rebuild() {
        val oldW = w
        val oldH = h
        readSize()
        if (w == oldW && h == oldH) return
        val nr = ImageReader.newInstance(w / SCALE, h / SCALE, PixelFormat.RGBA_8888, 3)
        vdisplay?.resize(w / SCALE, h / SCALE, dpi)
        vdisplay?.surface = nr.surface
        held?.close()
        held = null
        reader?.close()
        reader = nr
    }

    @Synchronized
    fun refresh() {
        val r = reader ?: return
        val fresh = try {
            r.acquireLatestImage()
        } catch (e: Exception) {
            null
        }
        if (fresh != null) {
            held?.close()
            held = fresh
        }
    }

    @Synchronized
    fun readPixel(x: Int, y: Int): Int? {
        if (held == null) refresh()
        val img = held ?: return null
        val px = x / SCALE
        val py = y / SCALE
        if (px < 0 || py < 0 || px >= img.width || py >= img.height) return null
        return try {
            val plane = img.planes[0]
            val buf = plane.buffer
            val off = py * plane.rowStride + px * plane.pixelStride
            val rr = buf.get(off).toInt() and 0xFF
            val gg = buf.get(off + 1).toInt() and 0xFF
            val bb = buf.get(off + 2).toInt() and 0xFF
            (rr shl 16) or (gg shl 8) or bb
        } catch (e: Exception) {
            null
        }
    }

    override fun onDestroy() {
        instance = null
        try {
            val dm = getSystemService(Context.DISPLAY_SERVICE) as DisplayManager
            listener?.let { dm.unregisterDisplayListener(it) }
        } catch (e: Exception) {
        }
        held?.close()
        vdisplay?.release()
        reader?.close()
        projection?.stop()
        super.onDestroy()
    }
}
