package com.laymik.script

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class FrozenActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_frozen)
        if (intent.getStringExtra("mode") == "denied") {
            findViewById<TextView>(R.id.frozenIcon).text = "🚫"
            findViewById<TextView>(R.id.frozenTitle).text = "Аккаунт не найден"
            findViewById<TextView>(R.id.frozenBody).text =
                "Этот логин не зарегистрирован в Laymik Script.\n\nЕсли вы купили доступ, напишите в поддержку, и мы всё проверим."
        }
        findViewById<View>(R.id.btnBack).setOnClickListener {
            startActivity(Intent(this, LoginActivity::class.java))
            finish()
        }
    }
}
