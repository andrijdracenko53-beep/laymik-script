package com.laymik.script

import android.content.Context

class PointCfg(val x: Int, val y: Int, val color: Int)

object Cfg {
    const val TARGET = "target"
    const val BUY = "buy"
    const val CONFIRM = "confirm"
    const val CHECK = "check"
    const val CLOSE = "close"
    const val OK = "ok"

    val names = linkedMapOf(
        TARGET to "Метка нужного лота (1-й слот)",
        BUY to "Кнопка «Купить» (1-й слот)",
        CONFIRM to "Кнопка «Подтвердить»",
        CHECK to "Галочка (обновление списка)",
        CLOSE to "Выход из осмотра (необязательно)",
        OK to "Кнопка «ОК» (необязательно)"
    )

    private fun prefs(c: Context) = c.getSharedPreferences("cfg", Context.MODE_PRIVATE)

    fun getPoint(c: Context, k: String): PointCfg? {
        val s = prefs(c)
        if (!s.contains(k + "_x")) return null
        return PointCfg(s.getInt(k + "_x", 0), s.getInt(k + "_y", 0), s.getInt(k + "_c", 0))
    }

    fun setPoint(c: Context, k: String, pt: PointCfg) {
        prefs(c).edit()
            .putInt(k + "_x", pt.x)
            .putInt(k + "_y", pt.y)
            .putInt(k + "_c", pt.color)
            .apply()
    }

    fun getInt(c: Context, k: String, def: Int): Int = prefs(c).getInt(k, def)

    fun setInt(c: Context, k: String, v: Int) {
        prefs(c).edit().putInt(k, v).apply()
    }
}
