package com.laymik.script

import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.View
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.auth.FirebaseAuth

class HomeActivity : AppCompatActivity() {
    private var ready = false
    private val ui = Handler(Looper.getMainLooper())
    private val tick = object : Runnable {
        override fun run() {
            refresh()
            ui.postDelayed(this, 1000)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val user = FirebaseAuth.getInstance().currentUser
        if (user == null) {
            startActivity(Intent(this, LoginActivity::class.java))
            finish()
            return
        }
        setContentView(R.layout.activity_home)
        ready = true
        val email = user.email ?: ""
        var hello = "Привет, " + email.substringBefore("@")
        if (email == CREATOR_EMAIL) hello += " · создатель"
        findViewById<TextView>(R.id.hello).text = hello

        findViewById<View>(R.id.tileScripts).setOnClickListener { launchPanel() }
        findViewById<View>(R.id.tileCreator).setOnClickListener {
            startActivity(Intent(this, ConfigActivity::class.java))
        }
        findViewById<View>(R.id.tileSettings).setOnClickListener {
            startActivity(Intent(this, SetupActivity::class.java))
        }
        findViewById<View>(R.id.tileStop).setOnClickListener {
            Core.stop()
            val i = Intent(this, OverlayService::class.java)
            i.action = "close"
            startService(i)
            toast("Остановлено")
        }
        findViewById<View>(R.id.btnLogout).setOnClickListener {
            Core.stop()
            FirebaseAuth.getInstance().signOut()
            startActivity(Intent(this, LoginActivity::class.java))
            finish()
        }
    }

    override fun onResume() {
        super.onResume()
        if (ready) ui.post(tick)
    }

    override fun onPause() {
        ui.removeCallbacks(tick)
        super.onPause()
    }

    private fun chip(id: Int, ok: Boolean, text: String) {
        val tv = findViewById<TextView>(id)
        tv.text = (if (ok) "● " else "○ ") + text
        tv.setTextColor(if (ok) 0xFF22E3A1.toInt() else 0xFFFF6B6B.toInt())
    }

    private fun refresh() {
        chip(R.id.chipOverlay, Settings.canDrawOverlays(this), "Окна")
        chip(R.id.chipService, TapService.instance != null, "Служба")
        chip(R.id.chipScreen, CaptureService.instance != null, "Экран")
        val st = if (Core.running) "РАБОТАЕТ · покупок: ${Core.buys}" else "Остановлен"
        findViewById<TextView>(R.id.stats).text = st
    }

    private fun launchPanel() {
        val missing = ArrayList<String>()
        if (!Settings.canDrawOverlays(this)) missing.add("поверх окон")
        if (TapService.instance == null) missing.add("служба спец. возможностей")
        if (CaptureService.instance == null) missing.add("доступ к экрану")
        if (missing.isNotEmpty()) {
            toast("Не хватает: " + missing.joinToString(", "))
            startActivity(Intent(this, SetupActivity::class.java))
            return
        }
        val i = Intent(this, OverlayService::class.java)
        i.action = "panel"
        startService(i)
        toast("Панель запущена. Открой игру и нажми «Старт»")
        moveTaskToBack(true)
    }
}
