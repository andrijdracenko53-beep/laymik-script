package com.laymik.script

import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.view.View
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.auth.FirebaseAuth

class HomeActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val user = FirebaseAuth.getInstance().currentUser
        if (user == null) {
            startActivity(Intent(this, LoginActivity::class.java))
            finish()
            return
        }
        setContentView(R.layout.activity_home)
        val email = user.email ?: ""
        var hello = "Привет, " + email.substringBefore("@")
        if (email == CREATOR_EMAIL) hello += " · создатель"
        findViewById<TextView>(R.id.hello).text = hello

        findViewById<View>(R.id.tileScripts).setOnClickListener { launchPanel() }
        findViewById<View>(R.id.tileCreator).setOnClickListener {
            startActivity(Intent(this, ConfigActivity::class.java))
        }
        findViewById<View>(R.id.tileSettings).setOnClickListener {
            startActivity(Intent(this, SetupActivity::class.java))
        }
        findViewById<View>(R.id.tileStop).setOnClickListener {
            Core.stop()
            val i = Intent(this, OverlayService::class.java)
            i.action = "close"
            startService(i)
            toast("Остановлено")
        }
        findViewById<View>(R.id.btnLogout).setOnClickListener {
            Core.stop()
            FirebaseAuth.getInstance().signOut()
            startActivity(Intent(this, LoginActivity::class.java))
            finish()
        }
    }

    private fun launchPanel() {
        val missing = ArrayList<String>()
        if (!Settings.canDrawOverlays(this)) missing.add("поверх окон")
        if (TapService.instance == null) missing.add("служба спец. возможностей")
        if (CaptureService.instance == null) missing.add("доступ к экрану")
        if (missing.isNotEmpty()) {
            toast("Не хватает: " + missing.joinToString(", "))
            startActivity(Intent(this, SetupActivity::class.java))
            return
        }
        val i = Intent(this, OverlayService::class.java)
        i.action = "panel"
        startService(i)
        toast("Панель запущена. Открой игру и нажми «Старт»")
        moveTaskToBack(true)
    }
}
