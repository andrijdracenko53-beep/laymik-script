package com.laymik.script

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.auth.FirebaseAuth

class HomeActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val user = FirebaseAuth.getInstance().currentUser
        if (user == null) {
            startActivity(Intent(this, LoginActivity::class.java))
            finish()
            return
        }
        setContentView(R.layout.activity_home)
        val email = user.email ?: ""
        var hello = "Привет, " + email.substringBefore("@")
        if (email == CREATOR_EMAIL) hello += " · создатель"
        findViewById<TextView>(R.id.hello).text = hello

        val tiles = listOf(R.id.tileScripts, R.id.tileCreator, R.id.tileSettings, R.id.tileStop)
        for (id in tiles) {
            findViewById<View>(id).setOnClickListener {
                Toast.makeText(this, "Скоро будет", Toast.LENGTH_SHORT).show()
            }
        }
        findViewById<View>(R.id.btnLogout).setOnClickListener {
            FirebaseAuth.getInstance().signOut()
            startActivity(Intent(this, LoginActivity::class.java))
            finish()
        }
    }
}
