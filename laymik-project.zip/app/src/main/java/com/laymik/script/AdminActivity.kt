package com.laymik.script

import android.os.Bundle
import android.text.InputType
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.auth.FirebaseAuth

class AdminActivity : AppCompatActivity() {
    private lateinit var input: EditText
    private lateinit var msg: TextView
    private lateinit var listBox: LinearLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val email = FirebaseAuth.getInstance().currentUser?.email
        if (email != CREATOR_EMAIL) {
            finish()
            return
        }
        val frame = FrameLayout(this)
        frame.setBackgroundColor(0xFF060912.toInt())
        frame.addView(
            ParticlesView(this),
            FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT)
        )
        val scroll = ScrollView(this)
        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setPadding(dp(20), dp(44), dp(20), dp(40))
        scroll.addView(root)
        frame.addView(
            scroll,
            FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT)
        )

        root.addView(plain("Админ-панель", 28f, 0xFFFFFFFF.toInt(), true))
        root.addView(plain("Заморозка аккаунтов", 13f, 0xFF8A97A8.toInt()))

        val c = card()
        c.addView(plain("Логин пользователя", 13f, 0xFF8A97A8.toInt()))
        input = EditText(this)
        input.hint = "например: ivan"
        input.setHintTextColor(0xFF8A97A8.toInt())
        input.setTextColor(0xFFFFFFFF.toInt())
        input.setBackgroundResource(R.drawable.bg_input)
        input.setPadding(dp(14), 0, dp(14), 0)
        input.setSingleLine(true)
        input.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS
        val ilp = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(52))
        ilp.topMargin = dp(6)
        c.addView(input, ilp)
        c.addView(button("❄  Заморозить") { askFreeze() })
        c.addView(button("🔓  Разморозить") { unfreeze(readLogin()) })
        msg = plain("", 13f, 0xFF22E3A1.toInt(), true)
        val mlp = LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT)
        mlp.topMargin = dp(10)
        msg.layoutParams = mlp
        c.addView(msg)
        root.addView(c)

        root.addView(section("Замороженные аккаунты"))
        listBox = LinearLayout(this)
        listBox.orientation = LinearLayout.VERTICAL
        root.addView(listBox)
        setContentView(frame)
        reload()
    }

    private fun readLogin(): String = input.text.toString().trim().lowercase()

    private fun say(s: String, bad: Boolean) {
        msg.text = s
        msg.setTextColor(if (bad) 0xFFFF6B6B.toInt() else 0xFF22E3A1.toInt())
    }

    private fun validLogin(login: String): Boolean {
        if (!Regex("^[a-z0-9_.-]{2,32}$").matches(login)) {
            say("Введи логин: латиница, цифры, _ . -", true)
            return false
        }
        if (login + EMAIL_DOMAIN == CREATOR_EMAIL) {
            say("Себя заморозить нельзя", true)
            return false
        }
        return true
    }

    private fun askFreeze() {
        val login = readLogin()
        if (!validLogin(login)) return
        AlertDialog.Builder(this)
            .setTitle("Заморозить аккаунт?")
            .setMessage("Логин: $login\n\nПользователь не сможет войти и увидит сообщение о заморозке.")
            .setPositiveButton("Заморозить") { _, _ -> doFreeze(login) }
            .setNegativeButton("Отмена", null)
            .show()
    }

    private fun doFreeze(login: String) {
        say("Замораживаю…", false)
        Freeze.set(login, true) { err ->
            if (err == null) {
                say("❄ Аккаунт $login заморожен", false)
                reload()
            } else {
                say("Ошибка: $err. Проверь правила Firestore", true)
            }
        }
    }

    private fun unfreeze(login: String) {
        if (!validLogin(login)) return
        say("Размораживаю…", false)
        Freeze.set(login, false) { err ->
            if (err == null) {
                say("🔓 Аккаунт $login разморожен", false)
                reload()
            } else {
                say("Ошибка: $err", true)
            }
        }
    }

    private fun reload() {
        listBox.removeAllViews()
        Freeze.list { names ->
            listBox.removeAllViews()
            if (names == null) {
                listBox.addView(plain("Не удалось загрузить список", 13f, 0xFFFF6B6B.toInt()))
            } else if (names.isEmpty()) {
                listBox.addView(plain("Замороженных аккаунтов нет", 13f, 0xFF8A97A8.toInt()))
            } else {
                for (n in names) {
                    val row = card()
                    row.addView(plain("❄  $n", 16f, 0xFFFFFFFF.toInt(), true))
                    row.addView(button("Разморозить") { unfreeze(n) })
                    listBox.addView(row)
                }
            }
        }
    }
}
