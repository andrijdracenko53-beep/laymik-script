package com.laymik.script

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.os.Bundle
import android.text.InputType
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.FirebaseApp
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseAuthUserCollisionException
import com.google.firebase.auth.FirebaseAuthWeakPasswordException
import java.security.SecureRandom

class AdminActivity : AppCompatActivity() {
    private lateinit var loginInput: EditText
    private lateinit var passInput: EditText
    private lateinit var msg: TextView
    private lateinit var credsCard: LinearLayout
    private lateinit var credsText: TextView
    private lateinit var listBox: LinearLayout
    private var lastCreds = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val email = FirebaseAuth.getInstance().currentUser?.email
        if (email != CREATOR_EMAIL) {
            finish()
            return
        }
        val frame = FrameLayout(this)
        frame.setBackgroundColor(0xFF060912.toInt())
        frame.addView(
            ParticlesView(this),
            FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT)
        )
        val scroll = ScrollView(this)
        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setPadding(dp(20), dp(44), dp(20), dp(40))
        scroll.addView(root)
        frame.addView(
            scroll,
            FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT)
        )

        root.addView(plain("Аккаунты", 28f, 0xFFFFFFFF.toInt(), true))
        root.addView(plain("Создавай аккаунты покупателям и управляй доступом", 13f, 0xFF8A97A8.toInt()))

        // --- создание ---
        val c = card()
        c.addView(plain("Новый аккаунт", 18f, 0xFFFFFFFF.toInt(), true))
        loginInput = field("Логин (латиница, цифры)", false)
        passInput = field("Пароль (минимум 6 символов)", true)
        c.addView(loginInput, fieldLp())
        c.addView(passInput, fieldLp())
        c.addView(button("🎲  Сгенерировать пароль") { passInput.setText(genPassword()) })
        c.addView(button("➕  Создать аккаунт") { createAccount() })
        msg = plain("", 13f, 0xFF22E3A1.toInt(), true)
        val mlp = LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT)
        mlp.topMargin = dp(10)
        msg.layoutParams = mlp
        c.addView(msg)
        root.addView(c)

        // --- данные для отправки покупателю ---
        credsCard = card()
        credsCard.addView(plain("Данные для входа. Отправь покупателю", 13f, 0xFF8A97A8.toInt()))
        credsText = plain("", 17f, 0xFFFFFFFF.toInt(), true)
        credsText.setTextIsSelectable(true)
        credsText.setPadding(0, dp(8), 0, 0)
        credsCard.addView(credsText)
        credsCard.addView(button("📋  Скопировать") { copyCreds() })
        credsCard.visibility = View.GONE
        root.addView(credsCard)

        // --- список ---
        root.addView(section("Все аккаунты"))
        listBox = LinearLayout(this)
        listBox.orientation = LinearLayout.VERTICAL
        root.addView(listBox)
        root.addView(button("↻  Обновить список") { reload() })
        setContentView(frame)
        reload()
    }

    private fun field(hint: String, visiblePassword: Boolean): EditText {
        val et = EditText(this)
        et.hint = hint
        et.setHintTextColor(0xFF8A97A8.toInt())
        et.setTextColor(0xFFFFFFFF.toInt())
        et.setBackgroundResource(R.drawable.bg_input)
        et.setPadding(dp(14), 0, dp(14), 0)
        et.setSingleLine(true)
        var type = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS
        if (visiblePassword) type = type or InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD
        et.inputType = type
        return et
    }

    private fun fieldLp(): LinearLayout.LayoutParams {
        val lp = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(52))
        lp.topMargin = dp(10)
        return lp
    }

    private fun genPassword(): String {
        val chars = "abcdefghijkmnpqrstuvwxyzABCDEFGHJKLMNPQRSTUVWXYZ23456789"
        val rnd = SecureRandom()
        val sb = StringBuilder()
        for (i in 0 until 10) sb.append(chars[rnd.nextInt(chars.length)])
        return sb.toString()
    }

    private fun say(s: String, bad: Boolean) {
        msg.text = s
        msg.setTextColor(if (bad) 0xFFFF6B6B.toInt() else 0xFF22E3A1.toInt())
    }

    private fun validLogin(login: String): Boolean {
        if (!Regex("^[a-z0-9_.-]{2,32}$").matches(login)) {
            say("Логин: латиница, цифры, _ . - (от 2 символов)", true)
            return false
        }
        if (login + EMAIL_DOMAIN == CREATOR_EMAIL) {
            say("Этот логин занят создателем", true)
            return false
        }
        return true
    }

    // второе подключение к Firebase, чтобы создание аккаунта не выкинуло тебя из твоего
    private fun secondaryAuth(): FirebaseAuth {
        val app = try {
            FirebaseApp.getInstance("creator")
        } catch (e: IllegalStateException) {
            FirebaseApp.initializeApp(this, FirebaseApp.getInstance().options, "creator")
        }
        return FirebaseAuth.getInstance(app)
    }

    private fun createAccount() {
        val login = loginInput.text.toString().trim().lowercase()
        val pass = passInput.text.toString()
        if (!validLogin(login)) return
        if (pass.length < 6) {
            say("Пароль: минимум 6 символов", true)
            return
        }
        say("Создаю…", false)
        val a2 = secondaryAuth()
        a2.createUserWithEmailAndPassword(login + EMAIL_DOMAIN, pass).addOnCompleteListener { t ->
            val e = t.exception
            if (t.isSuccessful || e is FirebaseAuthUserCollisionException) {
                a2.signOut()
                val isNew = t.isSuccessful
                Freeze.create(login) { err ->
                    if (err == null) {
                        showCreds(login, if (isNew) pass else null)
                        say(
                            if (isNew) "✓ Аккаунт $login создан" else "Логин уже существовал: добавлен в список, пароль прежний",
                            false
                        )
                        loginInput.setText("")
                        passInput.setText("")
                        reload()
                    } else {
                        say("Аккаунт создан, но не записан: $err. Проверь правила Firestore", true)
                    }
                }
            } else {
                val text = when (e) {
                    is FirebaseAuthWeakPasswordException -> "пароль слишком простой"
                    else -> e?.message ?: "ошибка"
                }
                say("Не удалось: $text", true)
            }
        }
    }

    private fun showCreds(login: String, pass: String?) {
        lastCreds = if (pass == null) "Логин: $login" else "Логин: $login\nПароль: $pass"
        credsText.text = lastCreds
        credsCard.visibility = View.VISIBLE
    }

    private fun copyCreds() {
        val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        cm.setPrimaryClip(ClipData.newPlainText("laymik", lastCreds))
        toast("Скопировано")
    }

    private fun small(text: String, onClick: () -> Unit): Button {
        val b = button(text, onClick)
        val lp = LinearLayout.LayoutParams(0, dp(46), 1f)
        lp.topMargin = dp(10)
        lp.marginEnd = dp(6)
        b.layoutParams = lp
        b.textSize = 13f
        return b
    }

    private fun accountRow(a: Account): LinearLayout {
        val c = card()
        c.addView(plain(a.login, 17f, 0xFFFFFFFF.toInt(), true))
        c.addView(
            plain(
                if (a.frozen) "❄ заморожен" else "● активен",
                12f,
                if (a.frozen) 0xFF7DD3FC.toInt() else 0xFF22E3A1.toInt()
            )
        )
        val btns = LinearLayout(this)
        btns.orientation = LinearLayout.HORIZONTAL
        btns.addView(
            small(if (a.frozen) "🔓 Разморозить" else "❄ Заморозить") {
                if (a.frozen) setFrozen(a.login, false) else askFreeze(a.login)
            }
        )
        val del = small("🗑 Удалить") { askDelete(a.login) }
        del.setBackgroundResource(R.drawable.btn_stop)
        del.setTextColor(0xFFFFFFFF.toInt())
        btns.addView(del)
        c.addView(btns)
        return c
    }

    private fun askFreeze(login: String) {
        AlertDialog.Builder(this)
            .setTitle("Заморозить аккаунт?")
            .setMessage("Логин: $login\n\nПользователь не сможет войти и увидит сообщение о заморозке.")
            .setPositiveButton("Заморозить") { _, _ -> setFrozen(login, true) }
            .setNegativeButton("Отмена", null)
            .show()
    }

    private fun askDelete(login: String) {
        AlertDialog.Builder(this)
            .setTitle("Удалить доступ?")
            .setMessage("Логин: $login\n\nПользователь потеряет доступ к приложению. Сам логин останется занятым в Firebase.")
            .setPositiveButton("Удалить") { _, _ ->
                Freeze.remove(login) { err ->
                    if (err == null) {
                        say("Доступ $login удалён", false)
                        reload()
                    } else {
                        say("Ошибка: $err", true)
                    }
                }
            }
            .setNegativeButton("Отмена", null)
            .show()
    }

    private fun setFrozen(login: String, frozen: Boolean) {
        Freeze.setFrozen(login, frozen) { err ->
            if (err == null) {
                say(if (frozen) "❄ $login заморожен" else "🔓 $login разморожен", false)
                reload()
            } else {
                say("Ошибка: $err. Проверь правила Firestore", true)
            }
        }
    }

    private fun reload() {
        listBox.removeAllViews()
        listBox.addView(plain("Загружаю…", 13f, 0xFF8A97A8.toInt()))
        Freeze.list { items ->
            listBox.removeAllViews()
            if (items == null) {
                listBox.addView(plain("Не удалось загрузить список. Проверь правила Firestore", 13f, 0xFFFF6B6B.toInt()))
            } else if (items.isEmpty()) {
                listBox.addView(plain("Пока нет аккаунтов", 13f, 0xFF8A97A8.toInt()))
            } else {
                for (a in items) listBox.addView(accountRow(a))
            }
        }
    }
}
