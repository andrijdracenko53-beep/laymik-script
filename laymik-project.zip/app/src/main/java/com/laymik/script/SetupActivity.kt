package com.laymik.script

import android.content.Context
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.widget.LinearLayout
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat

class SetupActivity : AppCompatActivity() {
    private lateinit var status: TextView

    private val projLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
            val d = r.data
            if (r.resultCode == RESULT_OK && d != null) {
                val i = Intent(this, CaptureService::class.java)
                i.putExtra("code", r.resultCode)
                i.putExtra("data", d)
                ContextCompat.startForegroundService(this, i)
                Handler(Looper.getMainLooper()).postDelayed({ refresh() }, 1000)
            }
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setBackgroundColor(0xFF0A0E14.toInt())
        root.setPadding(dp(20), dp(40), dp(20), dp(20))

        root.addView(label("Доступы", 22f, 0xFF22E3A1.toInt()))
        root.addView(label("Выдай по порядку. Каждый пункт нужен один раз.", 14f, 0xFF8A97A8.toInt()))
        root.addView(button("1. Поверх других окон") {
            startActivity(
                Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
            )
        })
        root.addView(button("2. Служба спец. возможностей") {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        })
        root.addView(button("3. Доступ к экрану") {
            val mpm = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
            projLauncher.launch(mpm.createScreenCaptureIntent())
        })
        status = label("", 16f)
        root.addView(status)
        setContentView(root)
    }

    override fun onResume() {
        super.onResume()
        refresh()
    }

    private fun refresh() {
        val a = if (Settings.canDrawOverlays(this)) "✅" else "❌"
        val b = if (TapService.instance != null) "✅" else "❌"
        val c = if (CaptureService.instance != null) "✅" else "❌"
        status.text = "$a Поверх окон\n$b Служба спец. возможностей\n$c Доступ к экрану"
    }
}
