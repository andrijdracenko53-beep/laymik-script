package com.laymik.script

import android.content.Context
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat

class SetupActivity : AppCompatActivity() {
    private lateinit var sOverlay: TextView
    private lateinit var sService: TextView
    private lateinit var sScreen: TextView

    private val projLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
            val d = r.data
            if (r.resultCode == RESULT_OK && d != null) {
                val i = Intent(this, CaptureService::class.java)
                i.putExtra("code", r.resultCode)
                i.putExtra("data", d)
                ContextCompat.startForegroundService(this, i)
                Handler(Looper.getMainLooper()).postDelayed({ refresh() }, 1000)
            }
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val frame = FrameLayout(this)
        frame.setBackgroundColor(0xFF060912.toInt())
        frame.addView(
            ParticlesView(this),
            FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT)
        )
        val scroll = ScrollView(this)
        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setPadding(dp(20), dp(44), dp(20), dp(40))
        scroll.addView(root)
        frame.addView(
            scroll,
            FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT)
        )

        root.addView(plain("Доступы", 28f, 0xFFFFFFFF.toInt(), true))
        root.addView(plain("Выдай по порядку. Каждый пункт нужен один раз.", 13f, 0xFF8A97A8.toInt()))

        sOverlay = permCard(root, "1  Поверх других окон", "Нужно для плавающей панели и пипетки") {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        }
        sService = permCard(root, "2  Служба спец. возможностей", "Нужна, чтобы приложение нажимало на экран") {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }
        sScreen = permCard(root, "3  Доступ к экрану", "Нужен, чтобы видеть цвета на экране") {
            val mpm = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
            projLauncher.launch(mpm.createScreenCaptureIntent())
        }
        setContentView(frame)
    }

    private fun permCard(root: LinearLayout, title: String, desc: String, onClick: () -> Unit): TextView {
        val c = card()
        c.addView(plain(title, 16f, 0xFFFFFFFF.toInt(), true))
        c.addView(plain(desc, 12f, 0xFF8A97A8.toInt()))
        val st = plain("", 13f, 0xFFFF6B6B.toInt(), true)
        val lp = LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT)
        lp.topMargin = dp(8)
        st.layoutParams = lp
        c.addView(st)
        c.addView(button("Открыть", onClick))
        root.addView(c)
        return st
    }

    override fun onResume() {
        super.onResume()
        refresh()
    }

    private fun setStatus(t: TextView, ok: Boolean) {
        t.text = if (ok) "● Включено" else "○ Выключено"
        t.setTextColor(if (ok) 0xFF22E3A1.toInt() else 0xFFFF6B6B.toInt())
    }

    private fun refresh() {
        setStatus(sOverlay, Settings.canDrawOverlays(this))
        setStatus(sService, TapService.instance != null)
        setStatus(sScreen, CaptureService.instance != null)
    }
}
