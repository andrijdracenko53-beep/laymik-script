package com.laymik.script

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.util.AttributeSet
import android.view.View
import java.util.Random

class ParticlesView @JvmOverloads constructor(c: Context, a: AttributeSet? = null) : View(c, a) {
    private class Dot(var x: Float, var y: Float, val r: Float, val vx: Float, val vy: Float)

    private val dotPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val linePaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val rnd = Random(11)
    private val dots = ArrayList<Dot>()

    init {
        linePaint.strokeWidth = 1.5f
    }

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        dots.clear()
        for (i in 0 until 38) {
            dots.add(
                Dot(
                    rnd.nextFloat() * w, rnd.nextFloat() * h,
                    2f + rnd.nextFloat() * 3f,
                    (rnd.nextFloat() - 0.5f) * 0.6f,
                    -0.2f - rnd.nextFloat() * 0.6f
                )
            )
        }
    }

    override fun onDraw(canvas: Canvas) {
        val maxD = 190f
        for (i in 0 until dots.size) {
            val a = dots[i]
            for (j in i + 1 until dots.size) {
                val b = dots[j]
                val dx = a.x - b.x
                val dy = a.y - b.y
                val d = Math.sqrt((dx * dx + dy * dy).toDouble()).toFloat()
                if (d < maxD) {
                    val al = ((1f - d / maxD) * 70f).toInt()
                    linePaint.color = 0x22E3A1 or (al shl 24)
                    canvas.drawLine(a.x, a.y, b.x, b.y, linePaint)
                }
            }
        }
        for (d in dots) {
            dotPaint.color = 0x22E3A1 or (120 shl 24)
            canvas.drawCircle(d.x, d.y, d.r, dotPaint)
            d.x += d.vx
            d.y += d.vy
            if (d.y < -10f) {
                d.y = height + 10f
                d.x = rnd.nextFloat() * width
            }
            if (d.x < -10f) d.x = width + 10f
            if (d.x > width + 10f) d.x = -10f
        }
        postInvalidateOnAnimation()
    }
}
