package com.laymik.script

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.util.AttributeSet
import android.view.View
import java.util.Random

class ParticlesView @JvmOverloads constructor(c: Context, a: AttributeSet? = null) : View(c, a) {
    private class Dot(var x: Float, var y: Float, val r: Float, val v: Float, val alpha: Int)

    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val rnd = Random(7)
    private val dots = ArrayList<Dot>()

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        dots.clear()
        for (i in 0 until 45) {
            dots.add(
                Dot(
                    rnd.nextFloat() * w, rnd.nextFloat() * h,
                    2f + rnd.nextFloat() * 4f, 0.3f + rnd.nextFloat() * 0.9f,
                    30 + rnd.nextInt(90)
                )
            )
        }
    }

    override fun onDraw(canvas: Canvas) {
        for (d in dots) {
            paint.color = 0x22E3A1 or (d.alpha shl 24)
            canvas.drawCircle(d.x, d.y, d.r, paint)
            d.y -= d.v
            if (d.y < -10f) {
                d.y = height + 10f
                d.x = rnd.nextFloat() * width
            }
        }
        postInvalidateOnAnimation()
    }
}
