package com.laymik.script

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.auth.FirebaseAuth

const val EMAIL_DOMAIN = "@laymik.app"
const val CREATOR_EMAIL = "laymikscripts@laymik.app"

class LoginActivity : AppCompatActivity() {
    private lateinit var button: Button
    private lateinit var error: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val auth = FirebaseAuth.getInstance()
        setContentView(R.layout.activity_login)
        val box = findViewById<View>(R.id.box)
        box.alpha = 0f
        box.translationY = 60f
        box.animate().alpha(1f).translationY(0f).setDuration(650).start()

        val login = findViewById<EditText>(R.id.login)
        val password = findViewById<EditText>(R.id.password)
        button = findViewById(R.id.btnLogin)
        error = findViewById(R.id.error)

        val current = auth.currentUser
        if (current != null) {
            button.isEnabled = false
            info("Проверяю аккаунт…")
            proceed(current.email ?: "")
        }

        button.setOnClickListener {
            val name = login.text.toString().trim().lowercase()
            val pass = password.text.toString()
            if (name.isEmpty() || pass.isEmpty()) {
                bad("Введите логин и пароль")
                return@setOnClickListener
            }
            button.isEnabled = false
            info("Входим…")
            auth.signInWithEmailAndPassword(name + EMAIL_DOMAIN, pass)
                .addOnCompleteListener { task ->
                    if (task.isSuccessful) {
                        proceed(name + EMAIL_DOMAIN)
                    } else {
                        button.isEnabled = true
                        bad("Неверный логин или пароль")
                    }
                }
        }
    }

    private fun info(s: String) {
        error.setTextColor(0xFF8A97A8.toInt())
        error.text = s
    }

    private fun bad(s: String) {
        error.setTextColor(0xFFFF5C5C.toInt())
        error.text = s
    }

    // перед входом проверяем, что аккаунт есть в списке и не заморожен
    private fun proceed(email: String) {
        val login = email.substringBefore("@")
        Freeze.check(login) { st ->
            if (st == Freeze.State.FROZEN || st == Freeze.State.DENIED) {
                FirebaseAuth.getInstance().signOut()
                val i = Intent(this, FrozenActivity::class.java)
                if (st == Freeze.State.DENIED) i.putExtra("mode", "denied")
                startActivity(i)
            } else {
                startActivity(Intent(this, HomeActivity::class.java))
            }
            finish()
        }
    }
}
