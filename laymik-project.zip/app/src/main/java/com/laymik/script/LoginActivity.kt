package com.laymik.script

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.auth.FirebaseAuth

const val EMAIL_DOMAIN = "@laymik.app"
const val CREATOR_EMAIL = "laymikscripts@laymik.app"

class LoginActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val auth = FirebaseAuth.getInstance()
        if (auth.currentUser != null) {
            openHome()
            return
        }
        setContentView(R.layout.activity_login)
        val login = findViewById<EditText>(R.id.login)
        val password = findViewById<EditText>(R.id.password)
        val button = findViewById<Button>(R.id.btnLogin)
        val error = findViewById<TextView>(R.id.error)

        button.setOnClickListener {
            val name = login.text.toString().trim().lowercase()
            val pass = password.text.toString()
            if (name.isEmpty() || pass.isEmpty()) {
                error.text = "Введите логин и пароль"
                return@setOnClickListener
            }
            error.text = ""
            button.isEnabled = false
            auth.signInWithEmailAndPassword(name + EMAIL_DOMAIN, pass)
                .addOnCompleteListener { task ->
                    button.isEnabled = true
                    if (task.isSuccessful) openHome() else error.text = "Неверный логин или пароль"
                }
        }
    }

    private fun openHome() {
        startActivity(Intent(this, HomeActivity::class.java))
        finish()
    }
}
