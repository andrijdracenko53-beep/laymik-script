package com.laymik.script

import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.SetOptions

class Account(val login: String, val frozen: Boolean)

// Аккаунты хранятся в Firestore: users/{логин} -> { frozen: true/false }.
// Нет записи = доступ закрыт. Создатель проверяется отдельно по адресу.
object Freeze {
    enum class State { OK, FROZEN, DENIED, UNKNOWN }

    private fun col() = FirebaseFirestore.getInstance().collection("users")

    // если проверить не удалось (нет сети, не настроены правила), пускаем: State.UNKNOWN
    fun check(login: String, done: (State) -> Unit) {
        if (login + EMAIL_DOMAIN == CREATOR_EMAIL) {
            done(State.OK)
            return
        }
        col().document(login).get().addOnCompleteListener { t ->
            if (!t.isSuccessful) {
                done(State.UNKNOWN)
                return@addOnCompleteListener
            }
            val d = t.result
            if (d == null || !d.exists()) {
                done(State.DENIED)
            } else if (d.getBoolean("frozen") == true) {
                done(State.FROZEN)
            } else {
                done(State.OK)
            }
        }
    }

    // done(null) = успех, иначе текст ошибки
    fun create(login: String, done: (String?) -> Unit) {
        val data = hashMapOf<String, Any>("frozen" to false, "created" to System.currentTimeMillis())
        col().document(login).set(data, SetOptions.merge()).addOnCompleteListener { t ->
            done(if (t.isSuccessful) null else (t.exception?.message ?: "ошибка"))
        }
    }

    fun setFrozen(login: String, frozen: Boolean, done: (String?) -> Unit) {
        val data = hashMapOf<String, Any>("frozen" to frozen)
        col().document(login).set(data, SetOptions.merge()).addOnCompleteListener { t ->
            done(if (t.isSuccessful) null else (t.exception?.message ?: "ошибка"))
        }
    }

    fun remove(login: String, done: (String?) -> Unit) {
        col().document(login).delete().addOnCompleteListener { t ->
            done(if (t.isSuccessful) null else (t.exception?.message ?: "ошибка"))
        }
    }

    fun list(done: (List<Account>?) -> Unit) {
        col().get().addOnCompleteListener { t ->
            if (!t.isSuccessful) {
                done(null)
                return@addOnCompleteListener
            }
            val out = ArrayList<Account>()
            val res = t.result
            if (res != null) {
                for (d in res.documents) {
                    out.add(Account(d.id, d.getBoolean("frozen") == true))
                }
            }
            out.sortBy { it.login }
            done(out)
        }
    }
}
