package com.laymik.script

import com.google.firebase.firestore.FirebaseFirestore

// Заморозка аккаунтов: документ frozen/{логин} в Firestore.
object Freeze {
    private fun col() = FirebaseFirestore.getInstance().collection("frozen")

    // если проверить не удалось (нет сети, не настроены правила), считаем аккаунт не замороженным
    fun isFrozen(login: String, done: (Boolean) -> Unit) {
        col().document(login).get().addOnCompleteListener { t ->
            if (!t.isSuccessful) {
                done(false)
                return@addOnCompleteListener
            }
            val d = t.result
            done(d != null && d.exists() && d.getBoolean("frozen") == true)
        }
    }

    // done(null) = успех, иначе текст ошибки
    fun set(login: String, frozen: Boolean, done: (String?) -> Unit) {
        val ref = col().document(login)
        val task = if (frozen) {
            ref.set(hashMapOf<String, Any>("frozen" to true, "at" to System.currentTimeMillis()))
        } else {
            ref.delete()
        }
        task.addOnCompleteListener { t ->
            done(if (t.isSuccessful) null else (t.exception?.message ?: "ошибка"))
        }
    }

    fun list(done: (List<String>?) -> Unit) {
        col().get().addOnCompleteListener { t ->
            if (!t.isSuccessful) {
                done(null)
                return@addOnCompleteListener
            }
            val out = ArrayList<String>()
            val res = t.result
            if (res != null) {
                for (d in res.documents) {
                    if (d.getBoolean("frozen") == true) out.add(d.id)
                }
            }
            done(out)
        }
    }
}
