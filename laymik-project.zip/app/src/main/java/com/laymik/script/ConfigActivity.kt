package com.laymik.script

import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.text.InputType
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import androidx.appcompat.app.AppCompatActivity

class ConfigActivity : AppCompatActivity() {
    private lateinit var root: LinearLayout
    private val fields = ArrayList<Pair<String, EditText>>()

    private val numParams = listOf(
        Triple("slots", "Сколько слотов проверять", 10),
        Triple("step", "Шаг между слотами, px", 150),
        Triple("tol", "Допуск цвета (0-255)", 20),
        Triple("delay", "Пауза после «Купить», мс", 10),
        Triple("refresh", "Обновление галочкой, сек", 15)
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val scroll = ScrollView(this)
        scroll.setBackgroundColor(0xFF0A0E14.toInt())
        root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setPadding(dp(20), dp(40), dp(20), dp(40))
        scroll.addView(root)
        setContentView(scroll)
    }

    override fun onResume() {
        super.onResume()
        build()
    }

    override fun onPause() {
        saveNumbers()
        super.onPause()
    }

    private fun build() {
        root.removeAllViews()
        fields.clear()
        root.addView(label("Настройка скрипта", 22f, 0xFF22E3A1.toInt()))
        root.addView(
            label(
                "Для каждой точки нажми «Пипетка», открой игру, нажми «Выбрать точку» и коснись нужного места на экране.",
                14f, 0xFF8A97A8.toInt()
            )
        )
        for ((key, name) in Cfg.names) {
            val pt = Cfg.getPoint(this, key)
            root.addView(label(name))
            val info = if (pt == null) "не задано"
            else "x=${pt.x}  y=${pt.y}  цвет #" + String.format("%06X", pt.color)
            root.addView(label(info, 13f, 0xFF8A97A8.toInt()))
            root.addView(button("🎯 Пипетка") { startPick(key) })
        }
        root.addView(label("Числа", 18f, 0xFF22E3A1.toInt()))
        for ((key, name, def) in numParams) {
            root.addView(label(name, 14f, 0xFF8A97A8.toInt()))
            val et = EditText(this)
            et.setText(Cfg.getInt(this, key, def).toString())
            et.inputType = InputType.TYPE_CLASS_NUMBER
            et.setTextColor(0xFFFFFFFF.toInt())
            et.setBackgroundResource(R.drawable.bg_input)
            et.setPadding(dp(14), 0, dp(14), 0)
            et.layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, dp(48)
            )
            root.addView(et)
            fields.add(Pair(key, et))
        }
        root.addView(button("Сохранить") {
            saveNumbers()
            toast("Сохранено")
        })
    }

    private fun saveNumbers() {
        for ((key, et) in fields) {
            val v = et.text.toString().toIntOrNull()
            if (v != null) Cfg.setInt(this, key, v)
        }
    }

    private fun startPick(key: String) {
        if (!Settings.canDrawOverlays(this)) {
            toast("Сначала дай доступ «Поверх окон» в разделе Доступы")
            return
        }
        if (CaptureService.instance == null) {
            toast("Сначала включи доступ к экрану в разделе Доступы")
            return
        }
        saveNumbers()
        val i = Intent(this, OverlayService::class.java)
        i.action = "pick"
        i.putExtra("key", key)
        startService(i)
        moveTaskToBack(true)
    }
}
