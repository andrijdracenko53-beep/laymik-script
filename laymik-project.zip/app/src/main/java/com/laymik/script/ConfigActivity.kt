package com.laymik.script

import android.content.Intent
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.provider.Settings
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import androidx.appcompat.app.AppCompatActivity

class ConfigActivity : AppCompatActivity() {
    private lateinit var root: LinearLayout
    private val fields = ArrayList<Pair<String, EditText>>()

    private val mainKeys = arrayListOf(Cfg.TARGET, Cfg.BUY, Cfg.CONFIRM, Cfg.CHECK)
    private val extraKeys = arrayListOf(Cfg.PRICE, Cfg.CANCEL, Cfg.CLOSE, Cfg.OK)

    private val numParams = listOf(
        Triple("slots", "Сколько слотов проверять", 10),
        Triple("step", "Шаг между слотами, px", 150),
        Triple("tol", "Допуск цвета (0-255)", 20),
        Triple("delay", "Пауза после «Купить», мс", 10),
        Triple("refresh", "Обновление галочкой, сек", 15),
        Triple("tapms", "Длительность тапа, мс", 10),
        Triple("gap", "Пауза между тапами, мс", 10)
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val frame = FrameLayout(this)
        frame.setBackgroundColor(0xFF060912.toInt())
        frame.addView(
            ParticlesView(this),
            FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT)
        )
        val scroll = ScrollView(this)
        root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setPadding(dp(20), dp(44), dp(20), dp(40))
        scroll.addView(root)
        frame.addView(
            scroll,
            FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT)
        )
        setContentView(frame)
    }

    override fun onResume() {
        super.onResume()
        build()
    }

    override fun onPause() {
        saveNumbers()
        super.onPause()
    }

    private fun build() {
        root.removeAllViews()
        fields.clear()
        root.addView(plain("Настройка", 28f, 0xFFFFFFFF.toInt(), true))
        root.addView(
            plain(
                "Открой игру на нужном экране и касайся того, что скажет подсказка. Цвет запоминается вместе с точкой.",
                13f, 0xFF8A97A8.toInt()
            )
        )

        root.addView(section("Основные точки"))
        root.addView(button("✨ Мастер: 4 основные точки") { startPick(mainKeys) })
        for (k in mainKeys) root.addView(pointCard(k))

        root.addView(section("Цена, отмена и ОК"))
        root.addView(button("✨ Мастер: цена, отмена, выход, ОК") { startPick(extraKeys) })
        for (k in extraKeys) root.addView(pointCard(k))

        root.addView(section("Числа"))
        val numCard = card()
        for ((key, name, def) in numParams) {
            numCard.addView(label(name, 13f, 0xFF8A97A8.toInt()))
            val et = EditText(this)
            et.setText(Cfg.getInt(this, key, def).toString())
            et.inputType = InputType.TYPE_CLASS_NUMBER
            et.setTextColor(0xFFFFFFFF.toInt())
            et.setBackgroundResource(R.drawable.bg_input)
            et.setPadding(dp(14), 0, dp(14), 0)
            et.layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, dp(48)
            )
            numCard.addView(et)
            fields.add(Pair(key, et))
        }
        numCard.addView(button("Сохранить") {
            saveNumbers()
            toast("Сохранено")
        })
        root.addView(numCard)
    }

    private fun pointCard(key: String): LinearLayout {
        val pt = Cfg.getPoint(this, key)
        val c = card()
        val head = LinearLayout(this)
        head.orientation = LinearLayout.HORIZONTAL
        head.gravity = Gravity.CENTER_VERTICAL

        val sw = View(this)
        val g = GradientDrawable()
        g.shape = GradientDrawable.OVAL
        g.setColor(if (pt == null) 0xFF2A3446.toInt() else (0xFF000000.toInt() or pt.color))
        g.setStroke(dp(2), 0x66FFFFFF)
        sw.background = g
        val swLp = LinearLayout.LayoutParams(dp(30), dp(30))
        swLp.marginEnd = dp(14)
        sw.layoutParams = swLp

        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.addView(plain(Cfg.names[key] ?: key, 15f, 0xFFFFFFFF.toInt(), true))
        val info = if (pt == null) "не задано"
        else "x=${pt.x}  y=${pt.y}  #" + String.format("%06X", pt.color)
        col.addView(plain(info, 12f, 0xFF8A97A8.toInt()))

        head.addView(sw)
        head.addView(col)
        c.addView(head)
        c.addView(button("🎯 Пипетка") { startPick(arrayListOf(key)) })
        if (pt != null && key in extraKeys) {
            c.addView(button("Убрать") {
                Cfg.clearPoint(this, key)
                build()
            })
        }
        return c
    }

    private fun saveNumbers() {
        for ((key, et) in fields) {
            val v = et.text.toString().toIntOrNull()
            if (v != null) Cfg.setInt(this, key, v)
        }
    }

    private fun startPick(keys: ArrayList<String>) {
        if (!Settings.canDrawOverlays(this)) {
            toast("Сначала дай доступ «Поверх окон» в разделе Доступы")
            return
        }
        if (CaptureService.instance == null) {
            toast("Сначала включи доступ к экрану в разделе Доступы")
            return
        }
        saveNumbers()
        val i = Intent(this, OverlayService::class.java)
        i.action = "pick"
        i.putStringArrayListExtra("keys", keys)
        startService(i)
        moveTaskToBack(true)
    }
}
