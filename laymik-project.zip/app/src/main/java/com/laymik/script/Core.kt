package com.laymik.script

import android.content.Context
import kotlin.math.abs

// Рабочая часть скрипта. Зашита в приложение: пользователь меняет только
// точки, цвета и числа в разделе «Настройка».
object Core {
    @Volatile
    var running = false

    private fun nap(ms: Long) {
        try {
            Thread.sleep(ms)
        } catch (e: InterruptedException) {
        }
    }

    private fun near(a: Int, b: Int, tol: Int): Boolean =
        abs(((a shr 16) and 255) - ((b shr 16) and 255)) <= tol &&
            abs(((a shr 8) and 255) - ((b shr 8) and 255)) <= tol &&
            abs((a and 255) - (b and 255)) <= tol

    private fun tap(x: Int, y: Int) {
        TapService.tap(x, y)
        nap(60)
    }

    fun stop() {
        running = false
    }

    fun start(ctx: Context): String? {
        if (running) return null
        val c = ctx.applicationContext
        if (TapService.instance == null) return "Включи службу Laymik Script в спец. возможностях (Доступы)"
        if (CaptureService.instance == null) return "Включи доступ к экрану (Доступы)"
        val target = Cfg.getPoint(c, Cfg.TARGET) ?: return "Задай точку: метка лота"
        val buy = Cfg.getPoint(c, Cfg.BUY) ?: return "Задай точку: Купить"
        val confirm = Cfg.getPoint(c, Cfg.CONFIRM) ?: return "Задай точку: Подтвердить"
        val check = Cfg.getPoint(c, Cfg.CHECK) ?: return "Задай точку: Галочка"
        val close = Cfg.getPoint(c, Cfg.CLOSE)
        val ok = Cfg.getPoint(c, Cfg.OK)
        val slots = Cfg.getInt(c, "slots", 10)
        val step = Cfg.getInt(c, "step", 150)
        val tol = Cfg.getInt(c, "tol", 20)
        val delay = Cfg.getInt(c, "delay", 10).toLong()
        val refreshMs = Cfg.getInt(c, "refresh", 15) * 1000L

        running = true
        val t = Thread { loop(target, buy, confirm, check, close, ok, slots, step, tol, delay, refreshMs) }
        t.isDaemon = true
        t.start()
        return null
    }

    private fun loop(
        target: PointCfg, buy: PointCfg, confirm: PointCfg, check: PointCfg,
        close: PointCfg?, ok: PointCfg?,
        slots: Int, step: Int, tol: Int, delay: Long, refreshMs: Long
    ) {
        var last = System.currentTimeMillis()
        try {
            while (running) {
                for (i in 0 until slots) {
                    if (!running) break
                    val dy = i * step
                    val col = CaptureService.colorAt(target.x, target.y + dy) ?: continue
                    if (near(col, target.color, tol)) {
                        tap(buy.x, buy.y + dy)
                        nap(delay)
                        tap(confirm.x, confirm.y)
                        tap(confirm.x, confirm.y)
                        tap(check.x, check.y)
                    }
                }
                if (close != null) {
                    val cc = CaptureService.colorAt(close.x, close.y)
                    if (cc != null && near(cc, close.color, tol)) {
                        tap(close.x, close.y)
                        tap(check.x, check.y)
                        tap(check.x, check.y)
                    }
                }
                if (ok != null) {
                    val oc = CaptureService.colorAt(ok.x, ok.y)
                    if (oc != null && near(oc, ok.color, tol)) {
                        tap(ok.x, ok.y)
                        tap(check.x, check.y)
                        tap(check.x, check.y)
                    }
                }
                val now = System.currentTimeMillis()
                if (now - last > refreshMs) {
                    last = now
                    tap(check.x, check.y)
                }
                nap(5)
            }
        } catch (e: Exception) {
        } finally {
            running = false
        }
    }
}
