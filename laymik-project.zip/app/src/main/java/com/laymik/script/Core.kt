package com.laymik.script

import android.content.Context
import android.os.Process
import kotlin.math.abs

// Рабочая часть скрипта. Зашита в приложение: пользователь меняет только
// точки, цвета и числа в разделе «Настройка».
object Core {
    @Volatile
    var running = false

    @Volatile
    var buys = 0

    private var tapMs = 10L
    private var gap = 10L

    private class Run(
        val target: PointCfg, val price: PointCfg?, val buy: PointCfg,
        val confirm: PointCfg, val check: PointCfg,
        val cancel: PointCfg?, val close: PointCfg?, val ok: PointCfg?,
        val slots: Int, val step: Int, val tol: Int, val delay: Long, val refreshMs: Long
    )

    private fun nap(ms: Long) {
        if (ms <= 0) return
        try {
            Thread.sleep(ms)
        } catch (e: InterruptedException) {
        }
    }

    private fun near(a: Int, b: Int, tol: Int): Boolean =
        abs(((a shr 16) and 255) - ((b shr 16) and 255)) <= tol &&
            abs(((a shr 8) and 255) - ((b shr 8) and 255)) <= tol &&
            abs((a and 255) - (b and 255)) <= tol

    private fun tap(x: Int, y: Int) {
        TapService.tap(x, y, tapMs)
        nap(gap)
    }

    private fun hit(p: PointCfg?, tol: Int): Boolean {
        if (p == null) return false
        val c = CaptureService.pixel(p.x, p.y) ?: return false
        return near(c, p.color, tol)
    }

    // лот подходит: совпала метка и (если задан) цвет цены
    private fun lotMatches(target: PointCfg, price: PointCfg?, tol: Int, dy: Int): Boolean {
        val col = CaptureService.pixel(target.x, target.y + dy) ?: return false
        if (!near(col, target.color, tol)) return false
        if (price == null) return true
        val pc = CaptureService.pixel(price.x, price.y + dy) ?: return false
        return near(pc, price.color, tol)
    }

    fun stop() {
        running = false
    }

    // Проверка без нажатий
    fun test(ctx: Context): String {
        val c = ctx.applicationContext
        if (CaptureService.instance == null) return "Включи доступ к экрану (Доступы)"
        val target = Cfg.getPoint(c, Cfg.TARGET) ?: return "Задай точку: метка лота"
        val price = Cfg.getPoint(c, Cfg.PRICE)
        val slots = Cfg.getInt(c, "slots", 10)
        val step = Cfg.getInt(c, "step", 150)
        val tol = Cfg.getInt(c, "tol", 20)
        CaptureService.frame()
        var found = 0
        for (i in 0 until slots) {
            if (lotMatches(target, price, tol, i * step)) found++
        }
        val first = CaptureService.pixel(target.x, target.y)
        val firstText = if (first == null) "нет данных" else "#" + String.format("%06X", first)
        val withPrice = if (price != null) " (с учётом цены)" else ""
        return "Подходящих лотов: $found из $slots$withPrice. Цвет метки в 1-м слоте: $firstText"
    }

    fun start(ctx: Context): String? {
        if (running) return null
        val c = ctx.applicationContext
        if (TapService.instance == null) return "Включи службу Laymik Script в спец. возможностях (Доступы)"
        if (CaptureService.instance == null) return "Включи доступ к экрану (Доступы)"
        val target = Cfg.getPoint(c, Cfg.TARGET) ?: return "Задай точку: метка лота"
        val buy = Cfg.getPoint(c, Cfg.BUY) ?: return "Задай точку: Купить"
        val confirm = Cfg.getPoint(c, Cfg.CONFIRM) ?: return "Задай точку: Подтвердить"
        val check = Cfg.getPoint(c, Cfg.CHECK) ?: return "Задай точку: Галочка"
        val run = Run(
            target, Cfg.getPoint(c, Cfg.PRICE), buy, confirm, check,
            Cfg.getPoint(c, Cfg.CANCEL), Cfg.getPoint(c, Cfg.CLOSE), Cfg.getPoint(c, Cfg.OK),
            Cfg.getInt(c, "slots", 10), Cfg.getInt(c, "step", 150), Cfg.getInt(c, "tol", 20),
            Cfg.getInt(c, "delay", 10).toLong(), Cfg.getInt(c, "refresh", 15) * 1000L
        )
        tapMs = Cfg.getInt(c, "tapms", 10).toLong().coerceAtLeast(1L)
        gap = Cfg.getInt(c, "gap", 10).toLong()

        buys = 0
        running = true
        val t = Thread { loop(run) }
        t.isDaemon = true
        t.priority = Thread.MAX_PRIORITY
        t.start()
        return null
    }

    private fun loop(r: Run) {
        var last = System.currentTimeMillis()
        try {
            Process.setThreadPriority(Process.THREAD_PRIORITY_URGENT_DISPLAY)
            while (running) {
                CaptureService.frame()
                for (i in 0 until r.slots) {
                    if (!running) break
                    val dy = i * r.step
                    if (lotMatches(r.target, r.price, r.tol, dy)) {
                        buys++
                        tap(r.buy.x, r.buy.y + dy)
                        nap(r.delay)
                        tap(r.confirm.x, r.confirm.y)
                        tap(r.confirm.x, r.confirm.y)
                        tap(r.check.x, r.check.y)
                    }
                }
                val cn = r.cancel
                val cl = r.close
                val ok = r.ok
                if (cn != null || cl != null || ok != null) {
                    CaptureService.frame()
                    if (cn != null && hit(cn, r.tol)) {
                        tap(cn.x, cn.y)
                    }
                    if (cl != null && hit(cl, r.tol)) {
                        tap(cl.x, cl.y)
                        tap(r.check.x, r.check.y)
                        tap(r.check.x, r.check.y)
                    }
                    if (ok != null && hit(ok, r.tol)) {
                        tap(ok.x, ok.y)
                        tap(r.check.x, r.check.y)
                        tap(r.check.x, r.check.y)
                    }
                }
                val now = System.currentTimeMillis()
                if (now - last > r.refreshMs) {
                    last = now
                    tap(r.check.x, r.check.y)
                }
                nap(2)
            }
        } catch (e: Exception) {
        } finally {
            running = false
        }
    }
}
