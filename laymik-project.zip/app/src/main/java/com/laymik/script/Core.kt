package com.laymik.script

import android.content.Context
import android.os.Process
import kotlin.math.abs

// Рабочая часть скрипта. Зашита в приложение: пользователь меняет только
// точки, цвета и числа в разделе «Настройка».
object Core {
    @Volatile
    var running = false

    @Volatile
    var buys = 0

    private var tapMs = 10L
    private var gap = 10L

    private fun nap(ms: Long) {
        if (ms <= 0) return
        try {
            Thread.sleep(ms)
        } catch (e: InterruptedException) {
        }
    }

    private fun near(a: Int, b: Int, tol: Int): Boolean =
        abs(((a shr 16) and 255) - ((b shr 16) and 255)) <= tol &&
            abs(((a shr 8) and 255) - ((b shr 8) and 255)) <= tol &&
            abs((a and 255) - (b and 255)) <= tol

    private fun tap(x: Int, y: Int) {
        TapService.tap(x, y, tapMs)
        nap(gap)
    }

    fun stop() {
        running = false
    }

    // Проверка без нажатий: сколько слотов совпало с меткой
    fun test(ctx: Context): String {
        val c = ctx.applicationContext
        if (CaptureService.instance == null) return "Включи доступ к экрану (Доступы)"
        val target = Cfg.getPoint(c, Cfg.TARGET) ?: return "Задай точку: метка лота"
        val slots = Cfg.getInt(c, "slots", 10)
        val step = Cfg.getInt(c, "step", 150)
        val tol = Cfg.getInt(c, "tol", 20)
        CaptureService.frame()
        var hit = 0
        for (i in 0 until slots) {
            val col = CaptureService.pixel(target.x, target.y + i * step) ?: continue
            if (near(col, target.color, tol)) hit++
        }
        val first = CaptureService.pixel(target.x, target.y)
        val firstText = if (first == null) "нет данных" else "#" + String.format("%06X", first)
        return "Совпадений: $hit из $slots. Цвет 1-го слота: $firstText"
    }

    fun start(ctx: Context): String? {
        if (running) return null
        val c = ctx.applicationContext
        if (TapService.instance == null) return "Включи службу Laymik Script в спец. возможностях (Доступы)"
        if (CaptureService.instance == null) return "Включи доступ к экрану (Доступы)"
        val target = Cfg.getPoint(c, Cfg.TARGET) ?: return "Задай точку: метка лота"
        val buy = Cfg.getPoint(c, Cfg.BUY) ?: return "Задай точку: Купить"
        val confirm = Cfg.getPoint(c, Cfg.CONFIRM) ?: return "Задай точку: Подтвердить"
        val check = Cfg.getPoint(c, Cfg.CHECK) ?: return "Задай точку: Галочка"
        val close = Cfg.getPoint(c, Cfg.CLOSE)
        val ok = Cfg.getPoint(c, Cfg.OK)
        val slots = Cfg.getInt(c, "slots", 10)
        val step = Cfg.getInt(c, "step", 150)
        val tol = Cfg.getInt(c, "tol", 20)
        val delay = Cfg.getInt(c, "delay", 10).toLong()
        val refreshMs = Cfg.getInt(c, "refresh", 15) * 1000L
        tapMs = Cfg.getInt(c, "tapms", 10).toLong().coerceAtLeast(1L)
        gap = Cfg.getInt(c, "gap", 10).toLong()

        buys = 0
        running = true
        val t = Thread { loop(target, buy, confirm, check, close, ok, slots, step, tol, delay, refreshMs) }
        t.isDaemon = true
        t.priority = Thread.MAX_PRIORITY
        t.start()
        return null
    }

    private fun loop(
        target: PointCfg, buy: PointCfg, confirm: PointCfg, check: PointCfg,
        close: PointCfg?, ok: PointCfg?,
        slots: Int, step: Int, tol: Int, delay: Long, refreshMs: Long
    ) {
        var last = System.currentTimeMillis()
        try {
            Process.setThreadPriority(Process.THREAD_PRIORITY_URGENT_DISPLAY)
            while (running) {
                // один свежий кадр на весь круг по слотам
                CaptureService.frame()
                for (i in 0 until slots) {
                    if (!running) break
                    val dy = i * step
                    val col = CaptureService.pixel(target.x, target.y + dy) ?: continue
                    if (near(col, target.color, tol)) {
                        buys++
                        tap(buy.x, buy.y + dy)
                        nap(delay)
                        tap(confirm.x, confirm.y)
                        tap(confirm.x, confirm.y)
                        tap(check.x, check.y)
                    }
                }
                if (close != null || ok != null) {
                    CaptureService.frame()
                    if (close != null) {
                        val cc = CaptureService.pixel(close.x, close.y)
                        if (cc != null && near(cc, close.color, tol)) {
                            tap(close.x, close.y)
                            tap(check.x, check.y)
                            tap(check.x, check.y)
                        }
                    }
                    if (ok != null) {
                        val oc = CaptureService.pixel(ok.x, ok.y)
                        if (oc != null && near(oc, ok.color, tol)) {
                            tap(ok.x, ok.y)
                            tap(check.x, check.y)
                            tap(check.x, check.y)
                        }
                    }
                }
                val now = System.currentTimeMillis()
                if (now - last > refreshMs) {
                    last = now
                    tap(check.x, check.y)
                }
                nap(2)
            }
        } catch (e: Exception) {
        } finally {
            running = false
        }
    }
}
