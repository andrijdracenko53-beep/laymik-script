package com.laymik.script

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.Typeface
import android.view.MotionEvent
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

fun Context.dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

fun Context.toast(s: String) {
    Toast.makeText(this, s, Toast.LENGTH_LONG).show()
}

@SuppressLint("ClickableViewAccessibility")
fun View.pressable() {
    setOnTouchListener { v, e ->
        if (e.action == MotionEvent.ACTION_DOWN) {
            v.animate().scaleX(0.96f).scaleY(0.96f).setDuration(80).start()
        } else if (e.action == MotionEvent.ACTION_UP || e.action == MotionEvent.ACTION_CANCEL) {
            v.animate().scaleX(1f).scaleY(1f).setDuration(120).start()
        }
        false
    }
}

fun Context.label(text: String, size: Float = 16f, color: Int = 0xFFFFFFFF.toInt()): TextView {
    val t = TextView(this)
    t.text = text
    t.textSize = size
    t.setTextColor(color)
    val lp = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
    lp.topMargin = dp(12)
    t.layoutParams = lp
    return t
}

fun Context.section(text: String): TextView {
    val t = label(text.uppercase(), 12f, 0xFF22E3A1.toInt())
    t.letterSpacing = 0.15f
    t.setTypeface(t.typeface, Typeface.BOLD)
    (t.layoutParams as LinearLayout.LayoutParams).topMargin = dp(22)
    return t
}

fun Context.plain(text: String, size: Float, color: Int, bold: Boolean = false): TextView {
    val t = TextView(this)
    t.text = text
    t.textSize = size
    t.setTextColor(color)
    if (bold) t.setTypeface(t.typeface, Typeface.BOLD)
    return t
}

fun Context.card(): LinearLayout {
    val c = LinearLayout(this)
    c.orientation = LinearLayout.VERTICAL
    c.setBackgroundResource(R.drawable.tile_bg)
    c.setPadding(dp(16), dp(14), dp(16), dp(14))
    val lp = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
    lp.topMargin = dp(12)
    c.layoutParams = lp
    return c
}

fun Context.button(text: String, onClick: () -> Unit): Button {
    val b = Button(this)
    b.text = text
    b.setTextColor(0xFF060912.toInt())
    b.setTypeface(b.typeface, Typeface.BOLD)
    b.setBackgroundResource(R.drawable.bg_button)
    val lp = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(52))
    lp.topMargin = dp(10)
    b.layoutParams = lp
    b.pressable()
    b.setOnClickListener { onClick() }
    return b
}
