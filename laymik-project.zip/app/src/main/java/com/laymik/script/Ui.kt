package com.laymik.script

import android.content.Context
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

fun Context.dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

fun Context.toast(s: String) {
    Toast.makeText(this, s, Toast.LENGTH_LONG).show()
}

fun Context.label(text: String, size: Float = 16f, color: Int = 0xFFFFFFFF.toInt()): TextView {
    val t = TextView(this)
    t.text = text
    t.textSize = size
    t.setTextColor(color)
    val lp = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
    lp.topMargin = dp(12)
    t.layoutParams = lp
    return t
}

fun Context.button(text: String, onClick: () -> Unit): Button {
    val b = Button(this)
    b.text = text
    b.setTextColor(0xFF0A0E14.toInt())
    b.setBackgroundResource(R.drawable.bg_button)
    val lp = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(52))
    lp.topMargin = dp(10)
    b.layoutParams = lp
    b.setOnClickListener { onClick() }
    return b
}
