package com.laymik.script

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Intent
import android.graphics.Path
import android.view.accessibility.AccessibilityEvent

class TapService : AccessibilityService() {
    companion object {
        @Volatile
        var instance: TapService? = null

        fun tap(x: Int, y: Int): Boolean {
            val s = instance ?: return false
            val path = Path()
            path.moveTo(x.toFloat(), y.toFloat())
            val g = GestureDescription.Builder()
                .addStroke(GestureDescription.StrokeDescription(path, 0, 40))
                .build()
            return s.dispatchGesture(g, null, null)
        }
    }

    override fun onServiceConnected() {
        instance = this
    }

    override fun onUnbind(intent: Intent?): Boolean {
        instance = null
        return super.onUnbind(intent)
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}

    override fun onInterrupt() {}
}
