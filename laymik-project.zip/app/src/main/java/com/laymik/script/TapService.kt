package com.laymik.script

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Intent
import android.graphics.Path
import android.view.accessibility.AccessibilityEvent
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit

class TapService : AccessibilityService() {
    companion object {
        @Volatile
        var instance: TapService? = null

        // Тап и ожидание его завершения: следующий тап идёт сразу после предыдущего
        fun tap(x: Int, y: Int, dur: Long = 10): Boolean {
            val s = instance ?: return false
            val path = Path()
            path.moveTo(x.toFloat(), y.toFloat())
            val g = GestureDescription.Builder()
                .addStroke(GestureDescription.StrokeDescription(path, 0, dur))
                .build()
            val latch = CountDownLatch(1)
            val cb = object : AccessibilityService.GestureResultCallback() {
                override fun onCompleted(gestureDescription: GestureDescription?) {
                    latch.countDown()
                }

                override fun onCancelled(gestureDescription: GestureDescription?) {
                    latch.countDown()
                }
            }
            val ok = s.dispatchGesture(g, cb, null)
            if (ok) {
                try {
                    latch.await(200, TimeUnit.MILLISECONDS)
                } catch (e: InterruptedException) {
                }
            }
            return ok
        }
    }

    override fun onServiceConnected() {
        instance = this
    }

    override fun onUnbind(intent: Intent?): Boolean {
        instance = null
        return super.onUnbind(intent)
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}

    override fun onInterrupt() {}
}
