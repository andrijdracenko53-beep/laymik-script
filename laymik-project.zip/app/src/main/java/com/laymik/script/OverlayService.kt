package com.laymik.script

import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.TextView

class OverlayService : Service() {
    private lateinit var wm: WindowManager
    private var panel: View? = null
    private var banner: View? = null
    private var catcher: View? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            "panel" -> showPanel()
            "pick" -> showBanner(intent.getStringExtra("key") ?: "")
            "close" -> {
                removePanel()
                removeBanner()
                removeCatcher()
                stopSelf()
            }
        }
        return START_NOT_STICKY
    }

    private fun lp(w: Int, h: Int, flags: Int): WindowManager.LayoutParams =
        WindowManager.LayoutParams(
            w, h,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            flags,
            PixelFormat.TRANSLUCENT
        )

    private fun tv(text: String, size: Float, color: Int): TextView {
        val t = TextView(this)
        t.text = text
        t.textSize = size
        t.setTextColor(color)
        t.setPadding(24, 12, 24, 12)
        return t
    }

    private fun showPanel() {
        if (panel != null) return
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL
        row.setBackgroundColor(0xDD121923.toInt())
        val handle = tv("☰", 22f, 0xFF22E3A1.toInt())
        val toggle = tv(if (Core.running) "■ Стоп" else "▶ Старт", 16f, Color.WHITE)
        val close = tv("✕", 18f, 0xFF8A97A8.toInt())
        row.addView(handle)
        row.addView(toggle)
        row.addView(close)

        val params = lp(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
        )
        params.gravity = Gravity.TOP or Gravity.START
        params.x = 40
        params.y = 40

        var sx = 0
        var sy = 0
        var tx = 0f
        var ty = 0f
        handle.setOnTouchListener { _, e ->
            if (e.action == MotionEvent.ACTION_DOWN) {
                sx = params.x
                sy = params.y
                tx = e.rawX
                ty = e.rawY
            } else if (e.action == MotionEvent.ACTION_MOVE) {
                params.x = sx + (e.rawX - tx).toInt()
                params.y = sy + (e.rawY - ty).toInt()
                wm.updateViewLayout(row, params)
            }
            true
        }
        toggle.setOnClickListener {
            if (Core.running) {
                Core.stop()
                toggle.text = "▶ Старт"
            } else {
                val err = Core.start(this)
                if (err != null) toast(err) else toggle.text = "■ Стоп"
            }
        }
        close.setOnClickListener {
            Core.stop()
            removePanel()
        }
        wm.addView(row, params)
        panel = row
    }

    private fun showBanner(key: String) {
        removeBanner()
        removeCatcher()
        val name = Cfg.names[key] ?: key
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL
        row.setBackgroundColor(0xEE121923.toInt())
        val info = tv("Пипетка: $name", 14f, Color.WHITE)
        val go = tv("🎯 Выбрать точку", 16f, 0xFF22E3A1.toInt())
        val cancel = tv("✕", 18f, 0xFF8A97A8.toInt())
        row.addView(info)
        row.addView(go)
        row.addView(cancel)

        val params = lp(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
        )
        params.gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
        params.y = 20

        go.setOnClickListener { startCatcher(key) }
        cancel.setOnClickListener {
            removeBanner()
            removeCatcher()
        }
        wm.addView(row, params)
        banner = row
    }

    private fun startCatcher(key: String) {
        removeCatcher()
        val v = View(this)
        v.setOnTouchListener { _, e ->
            if (e.action == MotionEvent.ACTION_UP) {
                val x = e.rawX.toInt()
                val y = e.rawY.toInt()
                removeCatcher()
                removeBanner()
                CaptureService.colorAt(x, y)
                Handler(Looper.getMainLooper()).postDelayed({
                    val c = CaptureService.colorAt(x, y)
                    if (c == null) {
                        toast("Нет доступа к экрану")
                    } else {
                        Cfg.setPoint(this, key, PointCfg(x, y, c))
                        toast("Сохранено: $x, $y  #" + String.format("%06X", c))
                    }
                }, 250)
            }
            true
        }
        val params = lp(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS
        )
        wm.addView(v, params)
        catcher = v
    }

    private fun removeView(v: View?) {
        if (v == null) return
        try {
            wm.removeView(v)
        } catch (e: Exception) {
        }
    }

    private fun removePanel() {
        removeView(panel)
        panel = null
    }

    private fun removeBanner() {
        removeView(banner)
        banner = null
    }

    private fun removeCatcher() {
        removeView(catcher)
        catcher = null
    }

    override fun onDestroy() {
        removePanel()
        removeBanner()
        removeCatcher()
        super.onDestroy()
    }
}
