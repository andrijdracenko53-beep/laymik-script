package com.laymik.script

import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.TextView

class OverlayService : Service() {
    private lateinit var wm: WindowManager
    private val ui = Handler(Looper.getMainLooper())
    private var panel: View? = null
    private var banner: View? = null
    private var catcher: View? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val i = intent ?: return START_NOT_STICKY
        when (i.action) {
            "panel" -> showPanel()
            "pick" -> {
                val keys = i.getStringArrayListExtra("keys") ?: ArrayList<String>()
                if (keys.isNotEmpty()) showBanner(keys, 0)
            }
            "close" -> {
                removePanel()
                removeBanner()
                removeCatcher()
                stopSelf()
            }
        }
        return START_NOT_STICKY
    }

    private fun lp(w: Int, h: Int, flags: Int): WindowManager.LayoutParams =
        WindowManager.LayoutParams(
            w, h,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            flags,
            PixelFormat.TRANSLUCENT
        )

    private fun tv(text: String, size: Float, color: Int): TextView {
        val t = TextView(this)
        t.text = text
        t.textSize = size
        t.setTextColor(color)
        t.setPadding(24, 12, 24, 12)
        return t
    }

    private fun showPanel() {
        if (panel != null) return
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL
        row.setBackgroundColor(0xEE0F1722.toInt())
        val handle = tv("☰", 22f, 0xFF22E3A1.toInt())
        val toggle = tv("▶ Старт", 16f, Color.WHITE)
        val test = tv("🔍", 18f, Color.WHITE)
        val close = tv("✕", 18f, 0xFF8A97A8.toInt())
        row.addView(handle)
        row.addView(toggle)
        row.addView(test)
        row.addView(close)

        val params = lp(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
        )
        params.gravity = Gravity.TOP or Gravity.START
        params.x = 40
        params.y = 40

        var sx = 0
        var sy = 0
        var tx = 0f
        var ty = 0f
        handle.setOnTouchListener { _, e ->
            if (e.action == MotionEvent.ACTION_DOWN) {
                sx = params.x
                sy = params.y
                tx = e.rawX
                ty = e.rawY
            } else if (e.action == MotionEvent.ACTION_MOVE) {
                params.x = sx + (e.rawX - tx).toInt()
                params.y = sy + (e.rawY - ty).toInt()
                wm.updateViewLayout(row, params)
            }
            true
        }
        toggle.setOnClickListener {
            if (Core.running) {
                Core.stop()
            } else {
                val err = Core.start(this)
                if (err != null) toast(err)
            }
        }
        test.setOnClickListener {
            toast(Core.test(this))
        }
        close.setOnClickListener {
            Core.stop()
            removePanel()
        }
        wm.addView(row, params)
        panel = row

        val tick = object : Runnable {
            override fun run() {
                if (panel == null) return
                toggle.text = if (Core.running) "■ Стоп · ${Core.buys}" else "▶ Старт"
                ui.postDelayed(this, 400)
            }
        }
        ui.post(tick)
    }

    private fun showBanner(keys: ArrayList<String>, idx: Int) {
        removeBanner()
        removeCatcher()
        val key = keys[idx]
        val name = Cfg.names[key] ?: key
        val hint = Cfg.hints[key] ?: ""
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.setBackgroundColor(0xEE0F1722.toInt())
        col.setPadding(12, 8, 12, 8)
        val info = tv("Шаг ${idx + 1}/${keys.size}: $name\n$hint", 13f, Color.WHITE)
        info.maxWidth = (resources.displayMetrics.widthPixels * 0.6f).toInt()
        val buttons = LinearLayout(this)
        buttons.orientation = LinearLayout.HORIZONTAL
        buttons.gravity = Gravity.CENTER_HORIZONTAL
        val go = tv("🎯 Выбрать точку", 16f, 0xFF22E3A1.toInt())
        val cancel = tv("✕ Отмена", 14f, 0xFF8A97A8.toInt())
        buttons.addView(go)
        buttons.addView(cancel)
        col.addView(info)
        col.addView(buttons)

        val params = lp(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
        )
        params.gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
        params.y = 20

        go.setOnClickListener { startCatcher(keys, idx) }
        cancel.setOnClickListener {
            removeBanner()
            removeCatcher()
        }
        wm.addView(col, params)
        banner = col
    }

    private fun startCatcher(keys: ArrayList<String>, idx: Int) {
        removeCatcher()
        val key = keys[idx]
        val v = View(this)
        v.setOnTouchListener { _, e ->
            if (e.action == MotionEvent.ACTION_UP) {
                val x = e.rawX.toInt()
                val y = e.rawY.toInt()
                removeCatcher()
                removeBanner()
                CaptureService.colorAt(x, y)
                ui.postDelayed({
                    val c = CaptureService.colorAt(x, y)
                    if (c == null) {
                        toast("Нет доступа к экрану")
                    } else {
                        Cfg.setPoint(this, key, PointCfg(x, y, c))
                        toast("Сохранено: $x, $y  #" + String.format("%06X", c))
                        if (idx + 1 < keys.size) showBanner(keys, idx + 1)
                    }
                }, 250)
            }
            true
        }
        val params = lp(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS
        )
        wm.addView(v, params)
        catcher = v
    }

    private fun removeView(v: View?) {
        if (v == null) return
        try {
            wm.removeView(v)
        } catch (e: Exception) {
        }
    }

    private fun removePanel() {
        removeView(panel)
        panel = null
    }

    private fun removeBanner() {
        removeView(banner)
        banner = null
    }

    private fun removeCatcher() {
        removeView(catcher)
        catcher = null
    }

    override fun onDestroy() {
        removePanel()
        removeBanner()
        removeCatcher()
        super.onDestroy()
    }
}
