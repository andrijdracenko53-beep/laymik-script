package com.laymik.script

import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.TextView
import com.google.firebase.auth.FirebaseAuth

private val MINT = 0xFF22E3A1.toInt()
private val DIM = 0xFF8A97A8.toInt()
private val DARK = 0xFF060912.toInt()
private val RED = 0xFFFF6B6B.toInt()

class OverlayService : Service() {
    private lateinit var wm: WindowManager
    private val ui = Handler(Looper.getMainLooper())
    private var panel: View? = null
    private var banner: View? = null
    private var picker: View? = null
    private var flashView: View? = null
    private var note: String? = null
    private var noteBad = false
    private var noteUntil = 0L

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val i = intent ?: return START_NOT_STICKY
        when (i.action) {
            "panel" -> showPanel()
            "pick" -> {
                val keys = i.getStringArrayListExtra("keys") ?: ArrayList<String>()
                if (keys.isNotEmpty()) showBanner(keys, 0)
            }
            "close" -> {
                removePanel()
                removeBanner()
                removePicker()
                removeFlash()
                stopSelf()
            }
        }
        return START_NOT_STICKY
    }

    private fun lp(w: Int, h: Int, flags: Int): WindowManager.LayoutParams =
        WindowManager.LayoutParams(
            w, h,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            flags,
            PixelFormat.TRANSLUCENT
        )

    private fun tv(text: String, size: Float, color: Int, bold: Boolean = false): TextView {
        val t = TextView(this)
        t.text = text
        t.textSize = size
        t.setTextColor(color)
        t.setPadding(dp(10), dp(8), dp(10), dp(8))
        if (bold) t.setTypeface(t.typeface, Typeface.BOLD)
        return t
    }

    private fun makeDraggable(handle: View, target: View, params: WindowManager.LayoutParams, bottom: Boolean) {
        var sx = 0
        var sy = 0
        var tx = 0f
        var ty = 0f
        handle.setOnTouchListener { _, e ->
            if (e.action == MotionEvent.ACTION_DOWN) {
                sx = params.x
                sy = params.y
                tx = e.rawX
                ty = e.rawY
            } else if (e.action == MotionEvent.ACTION_MOVE) {
                params.x = sx + (e.rawX - tx).toInt()
                val dy = (e.rawY - ty).toInt()
                params.y = if (bottom) sy - dy else sy + dy
                try {
                    wm.updateViewLayout(target, params)
                } catch (ex: Exception) {
                }
            }
            true
        }
    }

    private fun setNote(text: String, bad: Boolean, ms: Long = 7000) {
        note = text
        noteBad = bad
        noteUntil = System.currentTimeMillis() + ms
    }

    // ---------- панель запуска ----------
    private fun seg(text: String, size: Float, color: Int): TextView {
        val t = TextView(this)
        t.text = text
        t.textSize = size
        t.setTextColor(color)
        t.gravity = Gravity.CENTER
        t.minimumWidth = dp(58)
        t.minimumHeight = dp(52)
        t.setPadding(dp(6), dp(4), dp(6), dp(4))
        t.pressable()
        return t
    }

    private fun divider(): View {
        val v = View(this)
        v.setBackgroundColor(0x33FFFFFF)
        v.layoutParams = LinearLayout.LayoutParams(dp(1), dp(26))
        return v
    }

    private fun checkFrozen() {
        val u = FirebaseAuth.getInstance().currentUser ?: return
        Freeze.isFrozen((u.email ?: "").substringBefore("@")) { frozen ->
            if (frozen) {
                Core.stop()
                FirebaseAuth.getInstance().signOut()
                setNote("❄ Аккаунт заморожен. Напиши в поддержку", true, 3600000)
            }
        }
    }

    private fun showPanel() {
        if (panel != null) return
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.setBackgroundResource(R.drawable.glass_bg)
        box.setPadding(dp(6), dp(4), dp(10), dp(6))

        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL
        val grip = TextView(this)
        grip.text = "⋮"
        grip.textSize = 22f
        grip.setTextColor(DIM)
        grip.gravity = Gravity.CENTER
        grip.minimumWidth = dp(30)
        grip.minimumHeight = dp(52)
        val start = seg("▶", 24f, MINT)
        val test = seg("🔍", 20f, Color.WHITE)
        val gear = seg("⚙", 22f, Color.WHITE)
        val close = seg("✕", 20f, DIM)
        row.addView(grip)
        row.addView(start)
        row.addView(divider())
        row.addView(test)
        row.addView(divider())
        row.addView(gear)
        row.addView(divider())
        row.addView(close)

        val status = tv("Готов к запуску", 11f, DIM)
        status.setPadding(dp(10), dp(2), dp(4), dp(2))
        status.maxWidth = dp(300)
        box.addView(row)
        box.addView(status)

        val params = lp(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
        )
        params.gravity = Gravity.TOP or Gravity.START
        params.x = dp(16)
        params.y = dp(16)
        makeDraggable(grip, box, params, false)

        start.setOnClickListener {
            if (Core.running) {
                Core.stop()
                setNote("Остановлено", false, 3000)
            } else {
                val err = Core.start(this)
                if (err != null) setNote("⚠ $err", true) else setNote("Запущено", false, 2000)
            }
        }
        test.setOnClickListener {
            setNote(Core.test(this), false, 9000)
        }
        gear.setOnClickListener {
            val go = Intent(this, ConfigActivity::class.java)
            go.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            startActivity(go)
        }
        close.setOnClickListener {
            Core.stop()
            removePanel()
        }
        wm.addView(box, params)
        panel = box

        val tick = object : Runnable {
            var lastRunning = false
            var first = true
            var lastCheck = 0L
            override fun run() {
                if (panel == null) return
                val running = Core.running
                if (first || running != lastRunning) {
                    first = false
                    lastRunning = running
                    box.setBackgroundResource(if (running) R.drawable.glass_run else R.drawable.glass_bg)
                    start.setTextColor(if (running) 0xFFFF6B7A.toInt() else MINT)
                }
                start.text = if (running) "■ ${Core.buys}" else "▶"
                val now = System.currentTimeMillis()
                val n = note
                if (n != null && now < noteUntil) {
                    status.text = n
                    status.setTextColor(if (noteBad) RED else MINT)
                } else {
                    status.text = Core.status
                    status.setTextColor(DIM)
                }
                if (now - lastCheck > 60000L) {
                    lastCheck = now
                    checkFrozen()
                }
                ui.postDelayed(this, 300)
            }
        }
        ui.post(tick)
    }

    // ---------- карточка шага пипетки ----------
    private fun showBanner(keys: ArrayList<String>, idx: Int) {
        removeBanner()
        removePicker()
        val key = keys[idx]
        val card = LinearLayout(this)
        card.orientation = LinearLayout.VERTICAL
        card.setBackgroundResource(R.drawable.panel_card)
        card.setPadding(dp(18), dp(12), dp(18), dp(14))

        val top = LinearLayout(this)
        top.orientation = LinearLayout.HORIZONTAL
        top.gravity = Gravity.CENTER_VERTICAL
        for (n in keys.indices) {
            val dot = View(this)
            dot.setBackgroundResource(if (n <= idx) R.drawable.dot_on else R.drawable.dot_off)
            val dlp = LinearLayout.LayoutParams(dp(10), dp(10))
            dlp.marginEnd = dp(6)
            top.addView(dot, dlp)
        }
        top.addView(View(this), LinearLayout.LayoutParams(0, 1, 1f))
        top.addView(tv("Шаг ${idx + 1} из ${keys.size}   ☰", 12f, DIM))
        card.addView(top)

        card.addView(tv(Cfg.names[key] ?: key, 17f, Color.WHITE, true))
        card.addView(tv(Cfg.hints[key] ?: "", 13f, DIM))

        val go = tv("🎯  Выбрать точку", 16f, DARK, true)
        go.gravity = Gravity.CENTER
        go.setBackgroundResource(R.drawable.bg_button)
        go.setPadding(dp(12), dp(14), dp(12), dp(14))
        val glp = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
        glp.topMargin = dp(10)
        card.addView(go, glp)
        go.setOnClickListener { startPicker(keys, idx) }

        val links = LinearLayout(this)
        links.orientation = LinearLayout.HORIZONTAL
        links.gravity = Gravity.CENTER_HORIZONTAL
        if (idx + 1 < keys.size) {
            val skip = tv("Пропустить →", 13f, DIM)
            skip.setOnClickListener { showBanner(keys, idx + 1) }
            links.addView(skip)
        }
        val cancel = tv("Отмена", 13f, DIM)
        cancel.setOnClickListener { removeBanner() }
        links.addView(cancel)
        card.addView(links)

        val params = lp(
            dp(340),
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
        )
        params.gravity = Gravity.BOTTOM or Gravity.START
        params.x = dp(16)
        params.y = dp(16)
        makeDraggable(top, card, params, true)
        wm.addView(card, params)
        banner = card
    }

    // ---------- сама пипетка ----------
    private fun startPicker(keys: ArrayList<String>, idx: Int) {
        removePicker()
        removeBanner()
        val v = PickerView(
            this,
            { x, y, c -> onPicked(keys, idx, x, y, c) },
            {
                removePicker()
                showBanner(keys, idx)
            }
        )
        wm.addView(
            v,
            lp(
                WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                    WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS
            )
        )
        picker = v
    }

    private fun onPicked(keys: ArrayList<String>, idx: Int, x: Int, y: Int, c: Int?) {
        removePicker()
        if (c == null) {
            flash("Нет доступа к экрану. Включи его в Доступах", null, 2500)
            showBanner(keys, idx)
            return
        }
        Cfg.setPoint(this, keys[idx], PointCfg(x, y, c))
        flash("Сохранено · $x, $y · #" + String.format("%06X", c), c, 1600)
        ui.postDelayed({
            if (idx + 1 < keys.size) {
                showBanner(keys, idx + 1)
            } else {
                flash("Готово ✓ Все точки заданы", null, 2200)
            }
        }, 1100)
    }

    private fun flash(text: String, color: Int?, ms: Long) {
        removeFlash()
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL
        row.setBackgroundResource(R.drawable.panel_card)
        row.setPadding(dp(16), dp(8), dp(18), dp(8))
        if (color != null) {
            val sw = View(this)
            val g = GradientDrawable()
            g.shape = GradientDrawable.OVAL
            g.setColor(0xFF000000.toInt() or color)
            g.setStroke(dp(2), Color.WHITE)
            sw.background = g
            val slp = LinearLayout.LayoutParams(dp(26), dp(26))
            slp.marginEnd = dp(8)
            row.addView(sw, slp)
        }
        row.addView(tv(text, 15f, Color.WHITE, true))
        val params = lp(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
        )
        params.gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
        params.y = dp(40)
        wm.addView(row, params)
        flashView = row
        ui.postDelayed({
            if (flashView === row) removeFlash()
        }, ms)
    }

    private fun removeView(v: View?) {
        if (v == null) return
        try {
            wm.removeView(v)
        } catch (e: Exception) {
        }
    }

    private fun removePanel() {
        removeView(panel)
        panel = null
    }

    private fun removeBanner() {
        removeView(banner)
        banner = null
    }

    private fun removePicker() {
        removeView(picker)
        picker = null
    }

    private fun removeFlash() {
        removeView(flashView)
        flashView = null
    }

    override fun onDestroy() {
        removePanel()
        removeBanner()
        removePicker()
        removeFlash()
        super.onDestroy()
    }
}
